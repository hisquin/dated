/* Dogoma service worker. Caches the app shell (the five player routes) and static assets only. Cleanup touches only caches whose names start with dogoma-. It never touches Supabase (cross-origin), /admin or /api, so unpublished or admin data is never cached. Bump VERSION on each release to purge old caches. */
const VERSION='v3',SHELL='dogoma-shell-'+VERSION,STATIC='dogoma-static-'+VERSION,ROUTES=['/','/learn','/daily','/leaderboard','/profile'],PRE=[...ROUTES,'/offline.html','/manifest.webmanifest','/icons/icon-192.png','/icons/icon-512.png'];
self.addEventListener('install',e=>e.waitUntil(caches.open(SHELL).then(c=>c.addAll(PRE)))); // no skipWaiting: an update must never reload a game in progress
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x.startsWith('dogoma-')&&x!==SHELL&&x!==STATIC).map(x=>caches.delete(x)))).then(()=>self.clients.claim())));
self.addEventListener('message',e=>{const d=e.data||{};if(d.type==='SKIP_WAITING')self.skipWaiting();
 if(d.type==='CACHE_URLS')e.waitUntil(caches.open(STATIC).then(c=>Promise.all((d.urls||[]).filter(u=>{try{const x=new URL(u);return x.origin===location.origin&&x.pathname.startsWith('/_next/static/')}catch{return false}}).map(u=>c.add(u).catch(()=>{})))))});
const timeout=(ms)=>new Promise((_,j)=>setTimeout(j,ms));
self.addEventListener('fetch',e=>{const r=e.request;if(r.method!=='GET')return;const u=new URL(r.url);
 if(u.origin!==location.origin||u.pathname.startsWith('/admin')||u.pathname.startsWith('/api'))return;
 if(r.mode==='navigate'){const key=ROUTES.includes(u.pathname)?u.pathname:null;e.respondWith(Promise.race([fetch(r),timeout(4000)]).then(res=>{if(res.ok&&key){const cp=res.clone();caches.open(SHELL).then(c=>c.put(key,cp))}return res}).catch(()=>key?caches.match(key).then(h=>h||caches.match('/offline.html')):caches.match('/offline.html')));return}
 if(u.pathname.startsWith('/_next/static/')||u.pathname.startsWith('/icons/')||u.pathname==='/manifest.webmanifest')e.respondWith(caches.match(r).then(h=>h||fetch(r).then(res=>{if(res.ok){const cp=res.clone();caches.open(STATIC).then(c=>c.put(r,cp))}return res})))});
/* Background Sync (Chromium only): replays the IndexedDB outbox over REST when connectivity returns. Foreground sync in the page is the fallback. Mirrors classify() in src/lib/sync-core.ts. */
const idb=()=>new Promise((res,rej)=>{const r=indexedDB.open('dogoma-offline');r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)});
const rq=(d,s,m,f)=>new Promise((res,rej)=>{const r=f(d.transaction(s,m).objectStore(s));r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)});
async function bgSync(){const d=await idb(),cfg=await rq(d,'meta','readonly',s=>s.get('cfg'));if(!cfg||!cfg.url||!cfg.key)return;let retry=false;
 for(const r of await rq(d,'outbox','readonly',s=>s.getAll())){if(r.state==='synced'||r.state==='rejected'||r.tries>=8)continue;let st;
  try{st=(await fetch(cfg.url+'/rest/v1/game_sessions',{method:'POST',headers:{apikey:cfg.key,Authorization:'Bearer '+cfg.key,'Content-Type':'application/json',Prefer:'return=minimal'},body:JSON.stringify({id:r.id,guest_id:r.guestId,mode:r.mode,started_at:new Date(r.startedAt).toISOString(),ended_at:new Date(r.endedAt).toISOString(),score:r.score,attempted:r.attempted,correct:r.correct,offline:r.offline})})).status}catch{retry=true;continue}
  const put=v=>rq(d,'outbox','readwrite',s=>s.put(v));
  if(st===201||st===409)await put({...r,state:'synced',syncedAt:Date.now()});else if(st===401){retry=true;break}else if(st>=400&&st<500&&st!==408&&st!==429)await put({...r,state:'rejected',lastError:'HTTP '+st});else{retry=true;await put({...r,state:'failed',tries:r.tries+1,lastError:'HTTP '+st})}}
 if(retry)throw new Error('retry later')}
self.addEventListener('sync',e=>{if(e.tag==='dogoma-sync')e.waitUntil(bgSync())});
