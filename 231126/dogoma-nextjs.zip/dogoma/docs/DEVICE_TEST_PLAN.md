# Real-device test plan (not yet executed)
Build with `npm run build && npm start` over HTTPS (or a deployed preview). Record pass/fail and device/browser for each step.
1. First online visit (Android Chrome): app loads; DevTools Application shows service worker activated, cache `dogoma-shell-v2` and `dogoma-static-v2` populated, IndexedDB `dogoma-offline` has `questions.current`.
2. Install: Chrome menu or in-app button; app opens standalone. iOS Safari: Share, Add to Home Screen; the hint disappears when launched from the icon.
3. Offline refresh: airplane mode, refresh. App loads and the banner says saved questions are ready.
4. Offline game: finish a 5-question game, including a typed answer and a timeout. Result appears; banner shows 1 result not yet synced.
5. Interruption: start a game, kill the app mid-question, reopen after 10s. Resume is offered, the deadline has not moved. Repeat with the app closed past the deadline (question unanswered) and past a timed session's end.
6. Close and reopen offline: result still queued (IndexedDB), history intact.
7. Reconnect: result syncs within a minute or via Sync now; row appears in `game_sessions` with `verified=false`, `offline=true`. Re-sync causes no duplicate.
8. Failure cases: block `*.supabase.co` and confirm failing state and retries; sign out/expire (when accounts exist); stale deploy: publish a new build and confirm "Update available" appears and does not reload mid-game.
9. Lighthouse PWA audit and storage-full behaviour (DevTools quota override).
## Added in the experience pass (not yet executed)
10. Feedback: correct answer turns accent with a small +points chip; wrong answer shakes and turns red while the right option turns accent; no text blocks; next question after ~1.4s; typed, ordering and matching show only the correct answer line after a miss. Repeat with "reduce motion" on (no animation) and a screen reader (hears "Correct, N points").
11. Results: topic and difficulty bars, learn CTA only for topics under 60% with at least 2 answers; Explore Learning opens `/learn?topic=…` and shows the empty state; Review answers is collapsed.
12. Layout at 360x640, 390x844, 768x1024, 1280x800: bottom nav on phones (hidden during a game), sidebar on desktop, no horizontal scroll, safe areas on a notched phone.
13. Install: Android Chrome (invitation then native prompt only after tapping Install; dismiss; reload within 30 min shows nothing; Profile still installs); iOS Safari and iOS Chrome (steps, no dead button); installed launch shows no invitation; desktop shows the QR, scanning opens the public URL (set `NEXT_PUBLIC_APP_URL`; localhost must show the warning instead of a QR).
14. Profile and Leaderboard show guest/local labels and no official ranking.
## Expected offline support (after one online visit; not yet verified)
| Route | Offline behaviour |
|---|---|
| `/` | Loads from cache; play from the saved question set; results queue for sync |
| `/learn`, `/daily`, `/leaderboard`, `/profile` | Cached page loads; Leaderboard and Profile read local storage; `/learn?topic=x` serves the plain `/learn` page |
| Any other route, `/admin`, API calls | Not cached; offline page or a network error |
| First visit while offline | Not supported |
Test each row in airplane mode, plus: another app's cache on the same origin survives an update; a new deploy shows "Update available" and does not reload mid-game; Profile's Install button still shows the native prompt after the invitation was dismissed; on an Android browser with no native prompt the menu instructions appear after about 1.5s; a blocked QR library shows the URL text.
