# Weekly growth report (copy each week)
Week of: ____   Prepared by: ____
| Metric | This week | Last week | Note |
|---|---|---|---|
| Landing visitors (Umami) | | | |
| play_click | | | |
| game_start | | | |
| game_complete | | | |
| Activated players (new devices with a game_complete) | | | |
| Returning players (app_open returning=true) | | | |
| result_share / challenge_share | | | |
| install_click / install_accepted | | | |
Channels (clicks, game_start, game_complete, spend RWF, cost per game_complete): ____
Top 3 learnings: ____  Bugs found: ____  Feedback themes: ____
Decisions for next week (start, stop, keep): ____
