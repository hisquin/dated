# Outreach templates (English; have a native speaker adapt for Kinyarwanda or French)
Rules: personalise the first line, disclose what Dogoma is (free, early, small question bank), never imply a partnership exists, never ask anyone to post fake reactions, offer a unique tracking link.
## Creator (micro-influencer)
Hi [Name], I like your [specific video/post about X]. I'm building Dogoma, a free Rwanda knowledge game: timed questions on history, geography and culture where faster correct answers earn more. It's early and the question bank is small, so I'd value your honest reaction more than a promo. Would you try the 60-second challenge and, if you like it, share your score in whatever way suits your audience? I'll make you a tracking link so you can see how many people played. No obligation, and no scripted wording. [Link]  Thank you, [Your name]
## University or college student association
Hello [Name], I'm [Your name], building a free Rwanda quiz game called Dogoma. Could we run a 10-minute challenge at your next meeting or in your group chat, with a campus score thread? I can bring a QR poster and a short demo, and your members get a free game with no sign-up. Would [date] suit you? [Link]
## Teacher or school club
Dear [Name], Dogoma is a free game with questions on Rwanda's history, geography, places and culture, each with a source. It is new and small, and I would value a teacher's view on accuracy and difficulty. Could you try 15 questions and tell me what to fix? I will credit anyone who helps with content review.
## WhatsApp or Facebook group admin
Hi [Name], I'd like your permission before posting in [group]. Dogoma is a free Rwanda quiz game. May I share a 60-second challenge link once, and answer questions from members? If you'd rather I didn't, no problem.
## Content reviewer (historian, geographer, teacher)
Hello [Name], Dogoma needs questions checked against reliable sources before they go live. Would you review a set of 20 in your area and flag anything inaccurate or disputed? I will credit you if you wish. Questions on sensitive history are reviewed with extra care.
## Local business or community venue (poster)
Hello [Name], would you display a small QR poster for a free Rwanda quiz game in your space? It costs nothing and there is no advertising of other products. I can bring it printed.
## Blog or media
Hello [Name], Dogoma is a free, mobile-first Rwanda knowledge game built by [Your name]. If it fits [outlet], I can share what we learned in our first weeks, with real numbers only.
