# Creative briefs
Common rules: only the three brand colours (charcoal #171A19, ivory #F5F2EA, terracotta #D97745); no invented numbers, reviews or partnerships; never use the genocide for engagement or shock; credit sources for facts.
1. **QR poster (A4/A3).** Headline: Know where you come from. Sub: Free Rwanda quiz. Scan to play. Big QR (quiet zone, tested from 1.5 m), short URL in text. Link to landing page 02 with utm_source=qr&utm_medium=poster&utm_campaign=[location].
2. **WhatsApp Status card (1080x1920).** One question and four options; the last line is the link. Reuse for 7 questions.
3. **60-second challenge video (9:16, 15-25 s).** Hook in 2 s (countdown on screen), five fast answers, score reveal, CTA text.
4. **Campus table or meeting activation.** Phone on a stand showing the challenge, a score thread, a printed sheet of the scoring rule. No prizes.
5. **Creator brief.** Goal: honest first reaction. Must disclose if provided with anything of value. No scripted claims, no promise of rankings or rewards, say it is early. Deliver one post, share the link, report clicks after 7 days.
