// Usage: node marketing/check.mjs  . Checks both landing pages: syntax, metadata, local files, alt text, placeholders.
import fs from 'node:fs';import path from 'node:path';import {execSync} from 'node:child_process';
const here=path.dirname(new URL(import.meta.url).pathname);let fail=0,warn=0;const bad=m=>{fail++;console.log('FAIL',m)},w=m=>{warn++;console.log('WARN',m)};
for(const d of ['landing-page-01','landing-page-02']){const dir=path.join(here,d),html=fs.readFileSync(path.join(dir,'index.html'),'utf8');console.log('\n'+d);
 try{execSync(`node --check "${path.join(dir,'script.js')}"`);console.log('ok   script.js parses')}catch{bad(d+' script.js has a syntax error')}
 for(const re of [/<html lang="/,/<title>[^<]{10,}/,/name="description" content="[^"]{50,160}"/,/rel="canonical"/,/property="og:title"/,/property="og:description"/,/property="og:image"/,/property="og:url"/,/name="twitter:card"/,/name="viewport"/])if(!re.test(html))bad(d+' missing '+re);
 if((html.match(/<h1[ >]/g)||[]).length!==1)bad(d+' needs exactly one h1');
 for(const m of html.matchAll(/<img\b[^>]*>/g))if(!/alt="/.test(m[0]))bad(d+' image without alt');
 for(const m of html.matchAll(/(?:href|src)="([^"#][^"]*)"/g)){const u=m[1];if(/^(https?:|mailto:|tel:)/.test(u))continue;if(u.startsWith('/')){console.log('note app route (verify after deploy):',u);continue}if(!fs.existsSync(path.join(dir,u)))bad(d+' missing file '+u)}
 for(const f of ['assets/og.png','assets/favicon.png','styles.css','script.js'])if(!fs.existsSync(path.join(dir,f)))bad(d+' missing '+f);
 const left=(html.match(/REPLACE-WITH-YOUR-DOMAIN/g)||[]).length;if(left)w(`${d}: ${left} placeholder(s) REPLACE-WITH-YOUR-DOMAIN must be replaced before publishing`);}
console.log(`\n${fail} failure(s), ${warn} warning(s)`);process.exit(fail?1:0);
