# Landing pages: strategy and deployment
## Strategy
| | Landing page 01 | Landing page 02 |
|---|---|---|
| Audience | Curious Rwandans, students, people arriving from search or a link | Friends sharing in chat, social scrollers, QR scanners |
| Traffic | Search, bio links, partner links, ads that explain the product | WhatsApp, TikTok, Instagram, Facebook, posters, creators |
| Primary CTA | Play free (to the app) | Start the clock, then Play the full game |
| Conversion event | `play_click` then `game_start` in the app | `challenge_complete`, then `play_click`; share rate |
| Indexing | Indexable | `noindex` (campaign page, avoids duplicate content) |
A/B test: split the same traffic source (for example two link-in-bio variants or two ad creatives) between pages for at least 7 days and compare visitor to `game_start`. Change one thing at a time afterwards (headline, button text, mockup versus real screenshot). Improve by replacing the illustration with a real screenshot, adding a real player quote only if one is given with permission, and shortening copy.
## Deploy (Cloudflare Pages is one free option; its free plan documents unlimited static bandwidth and 500 builds a month: https://developers.cloudflare.com/pages/platform/limits/)
1. Replace the placeholder: `sed -i 's#https://REPLACE-WITH-YOUR-DOMAIN#https://yourdomain.com#g' marketing/landing-page-0*/index.html`
2. Edit `CONFIG` at the top of each `script.js`: `appUrl` (full URL of the app if hosted separately), optional `umami`, and for page 02 `shareUrl`.
3. Run `node marketing/check.mjs` until it reports no placeholder warnings.
4. Create a Pages project, upload each folder (or point two projects at the two folders), add your domain, open both pages on a phone.
5. Replace the CSS illustration on page 01 with real screenshots after device testing.
Before publishing check every claim against the working app. The pages do not claim offline play, install, rankings or learning content, because none is verified or live.
