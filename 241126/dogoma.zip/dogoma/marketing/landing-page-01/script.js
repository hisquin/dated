/* Dogoma landing page 01. Plain JavaScript, no dependencies. Edit CONFIG before deploying. */
const CONFIG={
  appUrl:'/',            // Where "Play" goes. Same-origin default; use the full app URL if the page is hosted separately.
  privacyUrl:'/privacy', termsUrl:'/terms',
  umami:{src:'',websiteId:''}  // Optional privacy-friendly analytics (Umami). Leave empty for no tracking.
};
const dnt=navigator.doNotTrack==='1';
function track(name,props){try{if(!dnt&&window.umami)window.umami.track(name,props)}catch(e){/* never break the page */}}
function withUtm(url){try{const u=new URL(url,location.href),p=new URLSearchParams(location.search);['utm_source','utm_medium','utm_campaign','utm_content'].forEach(k=>{if(p.get(k))u.searchParams.set(k,p.get(k))});if(!u.searchParams.has('utm_source')){u.searchParams.set('utm_source','landing01');u.searchParams.set('utm_medium','landing')}return u.pathname+u.search+u.hash===url?url:(u.origin===location.origin?u.pathname+u.search:u.href)}catch(e){return url}}
document.querySelectorAll('[data-app]').forEach(a=>{a.href=withUtm(CONFIG.appUrl);a.addEventListener('click',()=>track('play_click',{page:'landing01',placement:a.dataset.cta||'unknown'}))});
document.querySelectorAll('[data-privacy]').forEach(a=>a.href=CONFIG.privacyUrl);document.querySelectorAll('[data-terms]').forEach(a=>a.href=CONFIG.termsUrl);
document.querySelectorAll('#faq details').forEach(d=>d.addEventListener('toggle',()=>{if(d.open)track('faq_open',{question:d.querySelector('summary').textContent.trim().slice(0,60)})}));
if(!dnt&&CONFIG.umami.src&&CONFIG.umami.websiteId){const s=document.createElement('script');s.defer=true;s.src=CONFIG.umami.src;s.dataset.websiteId=CONFIG.umami.websiteId;s.dataset.doNotTrack='true';s.onload=()=>track('landing_page_view',{page:'landing01'});document.head.appendChild(s)}
