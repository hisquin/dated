/* Dogoma landing page 02: a 60-second, five-question teaser. Plain JavaScript, no dependencies. Edit CONFIG before deploying.
   The questions are copied from the Dogoma Rwanda question bank (src/data/seed.json). Keep them in sync and re-check facts before changing. */
const CONFIG={appUrl:'/',privacyUrl:'/privacy',termsUrl:'/terms',shareUrl:'',umami:{src:'',websiteId:''}}; // shareUrl: the public URL of THIS page. Empty uses the current address.
const QUESTIONS=[
 {q:'What is the capital of Rwanda?',a:'Kigali',o:['Kigali','Kampala','Gitega','Goma']},
 {q:'How many provinces does Rwanda have?',a:'5',o:['3','4','5','6']},
 {q:'Which lake forms much of Rwanda’s western border?',a:'Lake Kivu',o:['Lake Victoria','Lake Tanganyika','Lake Kivu','Lake Albert']},
 {q:'In which year did Rwanda become independent from Belgium?',a:'1962',o:['1959','1960','1962','1963']},
 {q:'Which national park is best known for mountain gorilla trekking?',a:'Volcanoes National Park',o:['Akagera National Park','Nyungwe National Park','Volcanoes National Park','Gishwati-Mukura National Park']}];
const TOTAL_MS=60000,$=id=>document.getElementById(id),dnt=navigator.doNotTrack==='1';
function track(n,p){try{if(!dnt&&window.umami)window.umami.track(n,p)}catch(e){/* ignore */}}
const shuffle=a=>{a=a.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
let endAt=0,i=0,score=0,locked=false,timer=null;
const url=(base,src)=>{try{const u=new URL(base||location.href,location.href);u.searchParams.set('utm_source',src);u.searchParams.set('utm_medium','share');u.searchParams.set('utm_campaign','challenge60');return u.href}catch(e){return base}};
function show(id){['intro','play','done'].forEach(x=>{$(x).hidden=x!==id})}
function start(){i=0;score=0;endAt=Date.now()+TOTAL_MS;show('play');track('challenge_start');render();clearInterval(timer);timer=setInterval(tick,100);tick()}
function tick(){const left=Math.max(0,endAt-Date.now());$('count').textContent=Math.ceil(left/1000);$('bar').style.width=left/TOTAL_MS*100+'%';if(left<=0)finish()}
function render(){locked=false;const q=QUESTIONS[i];$('q').textContent=q.q;$('prog').textContent=(i+1)+' / '+QUESTIONS.length;const box=$('opts');box.textContent='';
 shuffle(q.o).forEach(t=>{const b=document.createElement('button');b.type='button';b.textContent=t;b.addEventListener('click',()=>answer(b,t));box.appendChild(b)})}
function answer(btn,t){if(locked||Date.now()>=endAt)return;locked=true;const q=QUESTIONS[i],ok=t===q.a;if(ok)score++;btn.classList.add(ok?'ok':'bad');
 document.querySelectorAll('#opts button').forEach(b=>{b.disabled=true;if(b.textContent===q.a)b.classList.add('ok')});
 setTimeout(()=>{i++;if(i>=QUESTIONS.length)finish();else if(Date.now()<endAt)render()},700)}
function finish(){if(!timer)return;clearInterval(timer);timer=null;const left=Math.max(0,endAt-Date.now()),secs=Math.round((TOTAL_MS-left)/1000);show('done');$('score').textContent=score;
 $('tier').textContent=score===5?'Perfect score':score>=3?'Strong showing':'Room to grow';
 $('detail').textContent=i>=QUESTIONS.length?`You finished in ${secs} seconds.`:'Time ran out before the last question.';
 const text=`I got ${score}/5 in the Dogoma 60-second Rwanda challenge. Can you beat me?`,link=url(CONFIG.shareUrl,'share');
 $('wa').href='https://wa.me/?text='+encodeURIComponent(text+' '+link);$('native').hidden=!navigator.share;
 $('native').onclick=()=>navigator.share({text,url:link}).then(()=>track('challenge_share',{method:'native'})).catch(()=>{});
 $('wa').onclick=()=>track('challenge_share',{method:'whatsapp'});
 $('copy').onclick=()=>{(navigator.clipboard?navigator.clipboard.writeText(text+' '+link):Promise.reject()).then(()=>{$('copied').textContent='Link copied.';track('challenge_share',{method:'copy'})}).catch(()=>{$('copied').textContent='Copy failed. Long-press the WhatsApp button or copy the address bar.'})};
 track('challenge_complete',{score})}
$('start').addEventListener('click',start);$('again').addEventListener('click',()=>{show('intro')});
document.querySelectorAll('[data-app]').forEach(a=>{a.href=url(CONFIG.appUrl,'landing02').replace(location.origin,'');a.addEventListener('click',()=>track('play_click',{page:'landing02',placement:a.dataset.cta||'unknown'}))});
document.querySelectorAll('[data-privacy]').forEach(a=>a.href=CONFIG.privacyUrl);document.querySelectorAll('[data-terms]').forEach(a=>a.href=CONFIG.termsUrl);
if(!dnt&&CONFIG.umami.src&&CONFIG.umami.websiteId){const s=document.createElement('script');s.defer=true;s.src=CONFIG.umami.src;s.dataset.websiteId=CONFIG.umami.websiteId;s.dataset.doNotTrack='true';s.onload=()=>track('landing_page_view',{page:'landing02'});document.head.appendChild(s)}
