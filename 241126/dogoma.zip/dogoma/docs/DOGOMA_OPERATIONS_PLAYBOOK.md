# Operations playbook (one founder, part time)
## Cadence
Daily (30 min): check errors and messages, reply to feedback, post the scheduled item, note anything odd. Weekly (2 h): fill the weekly report, review the funnel, choose one experiment, write next week's posts. Monthly (3 h): review channel results, decide spend, refresh questions, backup check, privacy check.
## Responsibilities
Founder: product, content, community, outreach, analytics. Reviewer(s) (volunteer or paid): fact-check questions. Automate: scheduled posts, uptime monitoring, weekly report data export. Keep manual: replying to people, partner outreach, question review, anything sensitive.
## Support and feedback
One contact address and a free form. Reply within 2 days (target). Tag each message: bug, content error, idea, praise. Content errors are fixed first and logged.
## Bug report template
What happened / what you expected / steps / device and browser / screenshot / time.
## Incident response
1. Confirm (is the site down, or one device). 2. Roll back to the last good deploy on the host. 3. Post a short note if it lasted over an hour. 4. Write what failed and what changes. Never edit production data by hand without a copy.
## Backup
Source and questions live in git: keep a private remote plus a second copy. No server-side player data exists until Supabase is added; players' progress is on their own devices.
## Privacy and security duties
Keep the privacy page true to what the app does. Never put a service-role key in a public variable (the app refuses). Collect no personal data in analytics. Answer deletion requests (clearing browser data is the player's control today).
## Templates
Feedback and bug forms: use a free form tool. Trackers: `marketing/assets/*.csv`. Outreach: `outreach_templates.md`. Reports: `weekly_report_template.md`. Calendar: `content_calendar_30day.csv`. Launch checklist: `DOGOMA_LAUNCH_CHECKLIST.md`.
