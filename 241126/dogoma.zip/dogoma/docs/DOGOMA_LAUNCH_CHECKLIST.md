# Launch checklist
## Before anyone outside the team plays
- [ ] `npm install` works; lockfile committed
- [ ] `npm test`, `typecheck`, `lint`, `build` pass
- [ ] Device test plan run on Android, iOS and desktop; bugs logged
- [ ] At least 100 reviewed, sourced questions (300 before a public push)
- [ ] Domain, HTTPS, `NEXT_PUBLIC_APP_URL` set, QR opens the live site
- [ ] Privacy and Terms reviewed by counsel; support contact added; NCSA position documented
- [ ] Analytics provider configured and one test event seen
- [ ] Landing pages: domain placeholders replaced, `node marketing/check.mjs` clean, tested on a phone
- [ ] Google Search Console and Bing Webmaster verified; sitemap submitted
- [ ] Social profiles created with consistent name, bio and link
## Soft launch (week 1)
- [ ] 10-20 people watched playing on their own phones; notes taken
- [ ] First bugs fixed; feedback form live
## Public push
- [ ] Content calendar scheduled for 7 days
- [ ] Outreach messages sent (personalised)
- [ ] Weekly report scheduled
- [ ] Incident plan and rollback known
