# Product audit (stabilization pass)
Statuses: COMPLETE, PARTIAL, MISSING, BROKEN, UNVERIFIED (code exists; cannot be verified in this environment).
## Verification results (what was actually run)
| Check | Result |
|---|---|
| `npm install` | **BLOCKED**: no network (`npm install` timed out, registry unreachable). No `node_modules`, no `package-lock.json`. Commit the lockfile that your first `npm install` creates |
| `npm test` | **PASS** here (TypeScript 6.0.3, Node 22): compiles core, storage, sync, install, env and repository modules with `tsc -p tsconfig.test.json`, then runs 6 Node test files (pwa, idb, session, sync, product, repo). Not run on your TypeScript 5.8.3, but the script now uses only `-p` with plain options (the old `--ignoreConfig` flag exists only in newer TypeScript) |
| `npm run typecheck` | **NOT RUN** (needs React, Next and Supabase types) |
| `npm run lint` | **NOT RUN**. Config (`.eslintrc.json`, `next lint`, eslint 8 + eslint-config-next 15) was added but not installed or tested |
| `npm run build`, `npm start` | **NOT RUN** |
| Browser, mobile and desktop viewports, install, offline | **NOT RUN**: Playwright CLI exists but no browser is installed and it cannot download one. Source files were only parsed for syntax (37 files, 0 errors) and import paths checked (0 unresolved) |
## Status by area
| Area | Status | Notes |
|---|---|---|
| Gameplay rules: scoring, three timers, auto-submit, answer matching, recovery, no duplicate points | COMPLETE (logic, Node tests) / UI UNVERIFIED | Pure session module is tested, including recovery and double submits |
| Minimal feedback (accent / red shake / +pts / no text / auto-advance) | UNVERIFIED | Implemented; never seen rendered |
| Results analytics dashboard | COMPLETE (maths tested) / UI UNVERIFIED | Review answers is collapsed and secondary |
| Routes `/`, `/learn`, `/daily`, `/leaderboard`, `/profile` | UNVERIFIED | Never compiled or rendered |
| Learn, Daily content | MISSING content by design | Honest empty states; no invented content |
| Learning progress, bookmarks | MISSING | Nothing to attach them to until learning content exists |
| Skip and practice modes | MISSING | They change scoring and session rules (skip penalty, practice points); needs a product decision, not a guess |
| Repositories | PARTIAL / UNVERIFIED | Sessions, results, player, learning, daily and questions are implemented and used by the UI (tested at the Node level). Admin is interface-only on purpose |
| Env validation | COMPLETE (tested) | |
| PWA worker: shell, per-route offline fallback, Dogoma-only cache cleanup, Background Sync, outbox | COMPLETE (Node tests with a mocked Cache API) / browser UNVERIFIED | |
| Install: native prompt kept for reopen, Android fallback, iOS steps, QR with failure fallback | COMPLETE (state logic tested) / UI UNVERIFIED | QR needs the `qrcode` package installed |
| Mobile vs desktop composition | PARTIAL / UNVERIFIED | Bottom nav vs sidebar; two-column results on desktop. Home and profile are still single-column |
| Accounts, admin, official ranking, server verification, push, achievements, registration prompts | MISSING | Backend-dependent; deferred by decision |
| Security: unverified scores never labelled verified; env refuses secrets | COMPLETE (static) | SQL never run |
## Bugs found and fixed this pass
1. `npm test` failed: `--ignoreConfig` is not a TypeScript 5.8 option, and process typings were missing without `@types/node`. Fixed with `tsconfig.test.json`.
2. Service worker deleted every cache except its own two, including other apps' caches. Now only `dogoma-*` caches.
3. Offline navigation to any route served the home page. Now each of the five player routes is precached and served by path; unknown routes get the offline page.
4. Profile's install button recomputed availability without the stored native prompt, so the prompt was lost. The prompt now lives in a ref.
5. Android users without an immediate `beforeinstallprompt` got no invitation. They now get menu instructions after a 1.5s grace period, upgraded to the native button if the event arrives.
6. QR failure silently showed nothing; it now shows the URL as text.
7. UI components touched storage modules directly while repository interfaces had no wiring; sessions, results and player adapters now exist and are used.
8. Daily Knowledge was only reachable from the empty Learn page; added a home link.
