# Dogoma product launch audit
Date: 23 Nov 2026. Reinspected from the repository, not from earlier reports.
## What Dogoma is today (verified in code)
A free, guest-first Rwanda knowledge game (Next.js, TypeScript). Topics come from the question bank: history, geography, places, culture. Two formats: 5/10/15/20 questions, or 1/2/3/5 minutes against the clock. Five question types (multiple choice, true/false, typed with typo tolerance, ordering, matching). Faster correct answers earn more points, wrong answers earn zero. Minimal feedback, then a results dashboard (accuracy, time, topic and difficulty breakdown, learn recommendations). Session recovery, offline question storage, result queue, install invitation, desktop QR, share-result button. Learn, Daily Knowledge, Leaderboard and Profile pages exist but Learn and Daily have no content and the leaderboard is local only. No accounts, admin, server scoring or push.
## Verification status (what has actually been run)
| Check | Result |
|---|---|
| `npm test` (7 Node test files, TypeScript 6.0.3, Node 22) | PASS (re-run this pass) |
| `npm install`, `typecheck`, `lint`, `build` | NOT RUN (no network). Lockfile does not exist |
| Browser, Android, iOS, PWA install, offline on a device | NOT RUN |
| Landing pages: `node marketing/check.mjs` (syntax, metadata, local files) | PASS with 2 warnings (domain placeholders). Pages never opened in a browser |
Changes made this pass: SEO metadata and JSON-LD, `robots.txt` and sitemap generation, noindex on empty pages, draft Privacy and Terms pages, error and not-found pages, share-result button, privacy-first event hooks (`game_start`, `game_complete`, `result_share`, `install_click`, `install_accepted`, `app_open`), two landing pages. **Not production-ready.**
## Issue tracker
Effort: S under 1 day, M 1-3 days, L 1-2 weeks, XL several weeks (planning assumptions). All "Acceptance" lines are tests a person can perform.
| ID | Pri | Issue | Why it matters | Fix | Depends | Effort | Acceptance |
|---|---|---|---|---|---|---|---|
| L01 | P0 | Never installed, type-checked, linted or built; no lockfile | Unknown compile errors; builds not reproducible | `npm install`, `npm run typecheck`, `npm run lint`, `npm run build`, fix errors, commit `package-lock.json` | Network | S-M | All four commands exit 0 |
| L02 | P0 | No browser or device testing | Typing, timers, layout, install and offline are unproven | Run `docs/DEVICE_TEST_PLAN.md` on a low-end Android, an iPhone and a desktop | L01 | M | Every plan row marked pass or logged as a bug |
| L03 | P0 | Question bank has 15 Rwanda questions | One session exhausts it; no replay, no retention, nothing to share | Write and source at least 100 questions for a soft launch and 300 for a public push (target is a judgment, not a measurement) | Reviewers | L-XL | N reviewed, sourced questions load; a 15-question game rarely repeats |
| L04 | P0 | Starter questions are not editorially reviewed (they are marked published locally) | Factual errors damage trust; sensitive history needs care | Review each against its source; add a reviewer for history | L03 | M | Every published question has a reviewed source |
| L05 | P0 | No domain or hosting decision | Nothing to publish; QR and SEO need a real URL | Pick a host that runs Next.js 15 (verify free tiers) or make `/learn` static and export; buy a domain; set `NEXT_PUBLIC_APP_URL` | L01 | S-M | HTTPS URL serves the app; QR on desktop opens it |
| L06 | P0 | Privacy and Terms are drafts; Rwanda data-protection duties unchecked | Law No 058/2021 regulates personal data; controllers must register with the supervisory authority (NCSA) and cross-border transfers are restricted (verify with counsel) | Lawyer review; register if required; if analytics or storage leave Rwanda, check transfer rules; confirm rules for children's data | Counsel | M | Written advice; pages updated; registration done or documented as not required |
| L07 | P0 | No support contact | Players cannot report bugs or errors | Add an email or WhatsApp business number to Privacy, footer and landing pages | - | S | Contact is visible and answered |
| L08 | P0 | Landing pages contain `REPLACE-WITH-YOUR-DOMAIN` | Broken canonical and social previews | Replace with the real domain, set CONFIG | L05 | S | `node marketing/check.mjs` reports no placeholder warnings |
| L09 | P1 | Service worker and PWA untested on devices | Offline and install are headline features | Device plan sections 1-9 | L02 | M | Offline game completes and syncs result queue locally |
| L10 | P1 | Accessibility not audited | Contrast of terracotta text, keyboard, screen reader | Manual audit with a screen reader and Lighthouse | L02 | M | No blocking issues in the audit |
| L11 | P1 | Performance unmeasured | Low-end phones and costly data | Lighthouse mobile, check font loading and bundle size | L01 | S-M | Lighthouse results recorded and acted on |
| L12 | P1 | No analytics provider configured | Cannot measure the funnel | Self-host or sign up for Umami, set `NEXT_PUBLIC_UMAMI_SRC` and `NEXT_PUBLIC_UMAMI_WEBSITE_ID` | L06 | S | Events appear in the dashboard |
| L13 | P1 | No security headers beyond nosniff and referrer policy | Hardening | Add a Content-Security-Policy and frame protections, test | L02 | M | Headers present; app still works |
| L14 | P1 | Adding questions needs a developer (edit JSON, redeploy) | Content is the bottleneck | Keep JSON for launch; plan admin after accounts exist | Backend | M now, L later | A new question goes live in under 15 minutes |
| L15 | P1 | Viral loop is thin: share text only, no same-questions challenge | Referral growth limited | Seeded challenge link (same question set via a URL seed, no backend) | L01 | M | Two phones with one link get the same questions |
| L16 | P1 | UI is English only | Likely limits reach (hypothesis; validate with users) | Add Kinyarwanda and French UI and content through a native speaker | L03 | L | Language switch works across screens |
| L17 | P1 | Backup and recovery undocumented | Content lives only in git | Private repo plus a second remote; document rollback on the host | L05 | S | Restore drill completed once |
| L18 | P2 | Skip and practice modes | Wanted features that change scoring rules | Decide rules first (skip penalty, practice points) | Product decision | M | Rules documented, tests added |
| L19 | P2 | Learning progress, bookmarks | Need learning content | Build after content exists | Content | M | - |
| L20 | P2 | Desktop layout for home and profile | Desktop is secondary | Two-column layouts | - | S | - |
| L21 | P3 | Accounts, official leaderboards, server score verification, admin, push, tournaments | Needed to compete credibly | Supabase phase (see `SUPABASE_INTEGRATION.md`) | Backend | XL | Out of scope until launch metrics justify it |
## Launch gate
Do not run paid ads or ask influencers to post until L01-L08 are closed. Friends-and-family testing can start as soon as L01-L02 pass.
