# Analytics and KPI framework
## Principle
Count genuine players, not visits or installs. Collect no personal data. Tool: Umami (cookieless; verify current plan limits at umami.is/pricing: sources disagree on the number of sites; the free Hobby tier is reported at about 100,000 events a month; self-hosting is free). Alternative: Cloudflare Web Analytics for page views only. Hooks respect Do Not Track.
## Events that are implemented (and only those)
| Event | Where | Meaning |
|---|---|---|
| `landing_page_view` | landing pages | Visit (needs Umami configured) |
| `play_click` (page, placement) | landing pages | Intent to play |
| `challenge_start`, `challenge_complete` (score), `challenge_share` (method) | landing page 02 | Teaser funnel |
| `app_open` (returning true/false) | app | Session start; returning = this device has a completed game saved |
| `game_start` (mode, topic) | app | Started a game |
| `game_complete` (mode, questions, correct) | app | Finished a game: the activation event |
| `result_share` (method) | app | Shared a result |
| `install_click`, `install_accepted` | app | Install intent and acceptance |
Not measurable today: true retention cohorts by person, referral attribution, signups (no accounts), notification engagement. Cookieless tools identify devices, not people.
## Definitions
- **Genuine user (milestone count):** a distinct device with at least one `game_complete`. Page views, installs and `game_start` alone do not count. Report as "activated devices" and expect small over- and under-counts (shared phones, cleared storage).
- **Returning player:** `app_open` with returning=true on a later day.
- **North Star:** weekly players who complete 2 or more games.
## Funnel
Awareness (impressions, platform data) → landing visitors → `play_click` → `game_start` → `game_complete` → `app_open` returning → `result_share`/`challenge_share` → repeat.
## Metrics
Acquisition: visitors by source (UTM), cost per `game_complete`. Activation: `game_complete` / `game_start`, `game_start` / visitors. Engagement: games per player per week, mode and topic mix. Retention: returning share at day 7 (approximate). Referral: share events per 100 completed games, visits with `utm_source=share`. Conversion: visitor to activated device.
## Dashboard spec (Umami plus one sheet)
One page: this week vs last week for visitors, `play_click`, `game_start`, `game_complete`, activated devices, returning, shares, installs; table by `utm_source`/`utm_campaign`; list of top topics. Weekly copy into `marketing/assets/weekly_report_template.md`. UTM scheme: `utm_source` = channel (tiktok, instagram, facebook, whatsapp, qr, creator-name), `utm_medium` (social, poster, share, creator), `utm_campaign` (challenge60, campus-[name]).
## Validation
Every month, sample 10 players by message or call and compare what they say with the numbers.
