# Marketing strategy
Labels: **Verified** (sourced), **Assumption** (to test), **Recommendation**.
## 1. Market facts
Source: DataReportal, Digital 2027: Rwanda (published 5 Nov 2026): https://datareportal.com/reports/digital-2027-rwanda . Figures are platform and survey estimates, not exact counts of people.
| Fact | Value |
|---|---|
| Population | about 15.0 million (**Verified**) |
| Median age | about 20.2 (**Verified**) |
| Mobile connections | about 13.6 million, about 90.6% of population (**Verified**; connections are not unique people) |
| Internet users | about 4.74 million, about 31.7% of population (**Verified**) |
| Social media user identities | about 1.40 million, about 9.4% (**Verified**) |
| Platform ad reach | Facebook about 1.40M, Instagram about 660K, LinkedIn about 740K members, X about 271K (**Verified**, ad-audience estimates) |
| Age 13-17, 18-24, 25-34 shares | 10.8%, 14.3%, 14.6% (**Verified**) |
WhatsApp and TikTok audience sizes were not found in this source: **unverified**. Treat WhatsApp as the likely sharing channel and TikTok as a test (**Assumption**) until your own link data says otherwise. Implication (**Recommendation**): the online audience is a minority of the population and mostly young, so 1,000 players is a small slice of roughly 4.7 million internet users; data cost and phone quality matter, so keep the app light.
## 2. First niche (**Recommendation**, to be tested)
Rwandan university and upper-secondary students about 16-24 with a smartphone and mobile data, reachable through WhatsApp groups, campus clubs and Instagram/Facebook/TikTok. Why: competitive, short sessions fit study breaks and group chats; a young median age. Not verified: curriculum fit (do not claim alignment with school syllabi without Rwanda Education Board confirmation). Second niche, later: Rwandans abroad (no data gathered).
## 3. Competitors (manual search, not exhaustive)
Found: a free "Quiz Rwanda" mobile app listing (https://skich.app/games/quiz-rwanda ), and general quiz sites with Rwanda quizzes (ProProfs, Sporcle, JetPunk, FunTrivia). None found that combines Rwanda focus, speed-scored mobile play, no sign-up and topic insights; this is an observation, not proof. Check Google Play and the App Store directly. Dogoma's weaknesses today: tiny question bank, English only, no accounts or official rankings, unverified PWA.
## 4. Positioning
For Rwandans curious about their country, Dogoma is the free knowledge game where speed and accuracy both count, with no sign-up. Promise: Know where you come from. Pillars: (1) Free and instant, (2) Fast and fair (speed only pays when you are right), (3) Know your country, (4) See where to improve. Differentiation: scoring, minimal gameplay, results insight, built for phones. Tone: confident, curious, warm; short sentences; never lecturing; respectful and factual on sensitive history; no memes about tragedy. Key messages: "Know where you come from." "60 seconds. Five questions. How many do you know?" "Free, no account."
## 5. Viral campaign concepts
| # | Concept | Audience / trigger | Participation and sharing | Steps | Cost (RWF) | Metrics | Risks |
|---|---|---|---|---|---|---|---|
| 1 | **The 60-Second Challenge** | Friends; competition, curiosity | Play the page 02 teaser, send score on WhatsApp | Launch page, seed with 20 contacts, creators post their scores | 0 | challenge_complete, challenge_share, game_start | Only 5 questions: repeat play is weak |
| 2 | **Know-It-All Friend** | Pairs; social proof, banter | "Send this to the friend who thinks they know Rwanda" status/DM | Status cards, reaction videos | 0 | shares, `utm_source=share` visits | Low novelty after week 2 |
| 3 | **Campus Face-Off** | Student clubs; belonging | Departments or clubs post best scores in a thread, shout-outs only | Ask 3 clubs, QR poster, weekly thread | 10,000-30,000 printing | scans, game_complete from campus UTMs | Manual score tallying; no verified ranking, so call it a friendly thread |
| 4 | **Province Pride** | Anyone; identity | Players say their province and post their score | Facebook thread by province | 0 | comments, shares | Could feel divisive: keep it light and avoid ethnicity or politics |
| 5 | **Teacher's 10 Minutes** | Teachers, clubs | Whole room plays the same round | Teacher outreach, printable instructions | 0-5,000 | classroom visits | Needs seeded challenge link (L15) and reviewed content |
| 6 | **Question of the Week** | Fact lovers; contribution | Players suggest a question with a source, best one is reviewed and credited | Weekly post, review process | 0 | submissions, accepted questions | Review workload; credit only with permission |
## 6. Influencer strategy
Categories: student creators, comedy and skit creators, history and education pages, travel and culture accounts, quiz and gaming creators, community group admins. Find them by searching hashtags and following who your target audience engages with; judge by engagement quality (real comments from Rwandan accounts), audience location (ask for their insights screenshot), content fit and past disclosure habits, not follower count. Approach: personalised message (templates in `marketing/assets/outreach_templates.md`), honest about Dogoma being early. Offer: early access, credit, co-created question sets, shout-outs, and a small fixed fee only when budget exists. Track with a unique `utm_content` link per creator in `influencer_tracker.csv`. Pay only for delivered posts, never for guaranteed results. No creator has agreed to anything yet.
## 7. Referral and ambassadors
Now (no backend): UTM-tagged links per ambassador, recognition (credit, early access to features), shared score threads, no cash. Needs development: same-question challenge links (L15, no backend), referral attribution per player and idempotent reward ledger (needs accounts and server). Avoid cash rewards until verified scoring exists, to prevent gaming.
## 8. Product-led growth
| Idea | Status |
|---|---|
| Share result | Implemented, untested on devices |
| QR poster and desktop QR | Implemented, QR library not yet installed or tested |
| Daily engagement loop (Daily Knowledge) | Page exists; needs sourced items and notifications (backend) |
| Group and community leaderboards | Needs accounts and verified scores |
| Challenge a friend with the same questions | Needs a seed feature (L15) |
Content rule for all marketing: facts only from the reviewed question bank; never use the genocide for engagement.
