# 90-day roadmap: zero to 1,000+ activated devices
Targets are milestones, not predictions. "Users" means activated devices (at least one completed game). Founder owns every item unless stated. Budgets in RWF.
| Phase | Objectives | Key activities | Deliverables | KPIs | Budget | Exit criteria | Risks |
|---|---|---|---|---|---|---|---|
| 0. Readiness (weeks 1-3) | Make the product safe to show | Close L01-L08; write and review questions; set up analytics, Search Console, support contact | Built app, 100+ reviewed questions, live domain, tracked landing pages | Build passes; device plan complete | 0 (domain cost separate) | Launch gate closed | Question writing slower than planned |
| 1. First 50 (weeks 3-4) | Validate with real people | Watch 15-20 people play; fix top 10 problems; daily WhatsApp invites to own network; start calendar | Feedback log, bug fixes | 50 activated devices; game_complete / game_start | 0 | Most testers finish a game unaided | Friends being polite: ask for specifics |
| 2. 50-100 (weeks 5-6) | Fix onboarding and activation | Improve first screen and wording from feedback; test the two landing pages on different traffic | Improved landing, weekly report | Visitor to game_start; game_complete rate | 0-10,000 | Activation steady for 2 weeks | Thin content causes churn |
| 3. 100-250 (weeks 7-9) | Community distribution | 3 student groups, 1 creator trial per week, QR posters, question-of-the-week | Partner tracker, poster set | Activated devices by source; returning share | 20,000-50,000 | Two sources repeatedly deliver | Overreliance on one group |
| 4. 250-500 (weeks 10-11) | Partnerships, referrals | Teacher and club rounds, seeded challenge links (L15), 6+ creator posts, small paid test (scenario B or C) | Seeded challenge feature, results by source | Share rate; cost per game_complete | 50,000-100,000 | Positive trend in returning and shares | Paid spend before content depth |
| 5. 500-1,000+ (weeks 12-13) | Scale what works | Increase the best two channels, publish search pages, run a Province Pride thread | Monthly review | Weekly 2-game players; retention proxy | up to 250,000 only if guardrails pass | 1,000 activated devices or a documented learning plan | Fatigue, content repeats |
Daily: post, reply, check errors. Weekly: report, one experiment, outreach batch. Tools: Umami, Search Console, free form tool, spreadsheet trackers.
## If growth is slower
Hold spend at 0, run 10 in-person sessions, rewrite the first screen, add more questions, and prefer depth with 100 returning players over 1,000 one-time visits.
## Diagnosis
- **Visit but no play:** the first screen is unclear or slow: test headline, shorten the path, check mobile speed, check traffic quality.
- **Play but no return:** too little content or no reason to come back: add questions and Daily Knowledge items with sources, review the results page, send a message to players who agreed to hear from you (none exists yet).
- **Return but no share:** make sharing the next step on results, add the seeded challenge link, and ask players who finished what would make them send it.
