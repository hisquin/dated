# Paid campaign plan (planning scenarios, not commitments)
Do not start until launch gate L01-L08 is closed. No benchmark costs were found for Rwanda, so none are claimed. Before spending, check in each ads account that RWF billing, the Rwanda location and a suitable objective are available (not verified here).
## Test method
Spend a small amount, measure cost per `game_complete` (see analytics framework), keep what works, stop what does not. Always tag with UTMs. Guardrails below are **starting assumptions** to revise after the first 7 days of real data.
## Scenarios
| | A. RWF 0 | B. RWF 50,000 | C. RWF 100,000 | D. RWF 250,000 |
|---|---|---|---|---|
| Platform | Organic only | Facebook/Instagram ads, posters | Facebook/Instagram, posters, micro-creators | Facebook/Instagram, TikTok ads if available, creators, campus |
| Allocation (RWF) | 0 | ads 30,000; posters 10,000; reserve 10,000 | ads 50,000; posters 15,000; creators 25,000; reserve 10,000 | ads 100,000; TikTok test 40,000; creators 60,000; campus and printing 40,000; reserve 10,000 |
| Audience | Own network, groups, clubs | Rwanda, ages 16-24, interests tied to quizzes, education, history, culture (verify options) | Same plus lookalike from `game_complete` audiences only if tracking allows | Same, split by city and by language |
| Objective | Activated devices | Traffic to landing 02, optimise later for `game_start` | Same | Same |
| Creative | Calendar content | Two versions of the 60-second challenge video and one static | Add creator versions | Add campus content |
| Duration | 30 days | 10 days | 14 days | 21 days |
| Measured outcome | Cost of 0, time cost per activated device | Cost per `game_complete`, visitors to `game_start` rate | Same plus creator-attributed starts | Same plus by-channel comparison |
| Tracking | UTMs, trackers | UTMs, Umami | UTMs, unique creator links | UTMs, unique links per venue |
| Optimisation | Double what works | Pause the weakest creative after day 3 | Move budget weekly to the best source | Review daily for 3 days, then weekly |
## Increase, pause, stop (starting guardrails)
Increase budget by at most 50% when cost per `game_complete` is stable for 3 days and returning players appear. Pause a creative when it has spent about RWF 5,000 with no `game_start`. Stop all paid spend if landing visitors play rarely (fix the page or the product first), or if the app errors, or if cost per `game_complete` is not improving after two optimisation rounds. Never scale before L03 (enough questions): paid users who run out of questions are wasted spend.
## Other paid items
Printing posters (price locally), a small creator fee for a delivered post, and a data allowance for a phone if needed. No subscriptions.
