# Search, GEO and AEO guide
Honest scope: no keyword volumes were collected in this pass (no keyword tool access). `marketing/assets/seo_keyword_map.csv` lists candidate keywords with qualitative notes; validate in Search Console, Google Keyword Planner (free with an account) and Bing Webmaster. Nobody can guarantee rankings or inclusion in AI answers.
## A. SEO
Already done in the app: unique title and description, canonical, Open Graph, Twitter card, JSON-LD (WebApplication, free offer), `robots.txt` and sitemap generation (when `NEXT_PUBLIC_APP_URL` is set), noindex on empty pages (`/learn`, `/daily`, `/leaderboard`, `/profile`). Do next: set the domain; verify Search Console and Bing; submit the sitemap; optimise images and fonts (Lighthouse mobile); add internal links from content pages to Play; earn links by honest outreach (schools, clubs, local tech and education sites, startup newsletters, contributors you credit).
Titles and descriptions (ready to use):
| Page | Title | Meta description |
|---|---|---|
| Home `/` | Dogoma: Know Rwanda. A free knowledge game | Dogoma is a free Rwanda knowledge game. Answer history, geography and culture questions against the clock. No account needed. |
| Landing 01 | Dogoma \| Know Rwanda: a free history and geography quiz game | Test what you know about Rwanda’s history, geography and culture. Free to play, no account needed. Answer fast, earn more and see where to improve. |
| Landing 02 | Dogoma \| The 60-second Rwanda challenge (noindex) | Five questions about Rwanda. Sixty seconds. How many can you get right? |
| Privacy / Terms | Privacy \| Dogoma / Terms \| Dogoma | Plain-language policy pages. |
Do not create hundreds of thin pages. Publish a few useful sourced pages (see `content_plan_90day.csv`), each reusing reviewed questions with a clear source, and link them to Play.
## B. GEO (generative engines)
Make Dogoma easy to describe and cite: one clear sentence about what it is, used identically everywhere ("Dogoma is a free Rwanda knowledge game"); an About page with the founder, contact and date; consistent name and link on every profile; crawlable pages (no blocking in `robots.txt`; SSR is on); useful original content with sources; honest mentions from credible sites; keep facts consistent across pages. Optional: a plain-text summary page. No file or markup guarantees inclusion.
## C. AEO (answers)
Write direct answers first, then detail, under question headings, with a source. Candidate questions: What is Dogoma? Is Dogoma free? Do I need an account to play? How is the score calculated? How many provinces does Rwanda have? What are the official languages of Rwanda? When did Rwanda become independent? What is the capital of Rwanda? Which lake forms Rwanda's western border? Which national park is known for mountain gorillas? Use FAQPage markup only if it is allowed for your site type under current Google guidance (rich results for it are now limited): the on-page answers matter more.
## D. Rwanda strategy
English first (the product is English only). French and Kinyarwanda queries are candidates, but wording and demand must be validated with a native speaker and your own Search Console data. Do not target locations for their own sake.
## E. Structured data
Implemented in `src/app/layout.tsx` (WebApplication with `offers.price` 0). Add Organization and WebSite JSON-LD on the About page once it exists. Never add ratings or reviews that do not exist. VideoObject only for real hosted videos; Article for real articles.
## F. Monitoring and monthly report
Search Console (impressions, clicks, position, indexed pages, branded vs non-branded), Bing Webmaster, Umami for landing conversion. Monthly template: date range; indexed pages; impressions; clicks; top 10 queries; branded clicks; new links; pages published; landing visitor to `game_start` rate; next month's three actions.
## G. 90-day content
See `marketing/assets/content_plan_90day.csv`. Publish priority P0/P1 first.
