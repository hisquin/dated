# Free growth opportunities
Tool pricing changes. "Verified" means checked in this pass with a source; the rest must be checked on the vendor's page before you rely on it.
## Tools
| Tool | Use | Free-tier facts | Status |
|---|---|---|---|
| Cloudflare Pages | Host landing pages (static) | Unlimited static bandwidth and requests, 500 builds a month, per Cloudflare docs https://developers.cloudflare.com/pages/platform/limits/ | **Verified** |
| Umami (self-hosted or Cloud) | Cookieless analytics and events | Self-hosting free; Cloud free tier reported at about 100,000 events a month but sources differ on site limits: confirm at umami.is | Partly verified |
| Cloudflare Web Analytics | Page-view stats | Free | Not re-verified |
| Google Search Console, Bing Webmaster Tools | Indexing, queries, clicks | Free | Not re-verified |
| Google Analytics 4 | Web analytics | Free, but cookies and data leave Rwanda: check law first (see L06) | Not re-verified |
| Canva or similar, CapCut or similar | Graphics, video | Free tiers exist; limits not verified | Not verified |
| A free form tool | Feedback and bug reports | Choose after checking limits | Not verified |
| Free QR generators | Poster QR | The app draws its own QR (needs `npm install`); a free generator also works: always scan-test | Not verified |
## Channels (ranked, with evidence)
1. **WhatsApp status and groups** (likely best for sharing; audience size unverified). Always ask group admins first.
2. **Facebook posts and groups** (about 1.40M ad reach, Digital 2027).
3. **Instagram Reels and Stories** (about 660K).
4. **TikTok and YouTube Shorts** (no verified Rwanda figures; test with the calendar).
5. **Campus and club distribution**: student associations, clubs, lecturers; QR posters. Do not claim any institution is a partner until it agrees.
6. **Creators**: micro-creators for free access and credit.
7. **Search**: sitemap, Search Console, a few useful pages; slow but compounding (see the search guide).
8. **LinkedIn and X** (about 740K and 271K): founder story and press, not the main audience.
9. **Directories and launch sites**: product directories, startup newsletters and local tech communities: check which are active before pitching.
Not eligible: Google Business Profile (it needs a physical business location).
## Overlooked but legitimate ideas
Ask reviewers (teachers, historians) to check questions and credit them: they become advocates. A public "help us check these questions" post. A weekly "question from a player". WhatsApp Channels (check availability in Rwanda). Printed QR posters in cafes and campus notice boards with permission. A founder's honest build-in-public thread. Sponsored challenges later (requires verified scoring).
## Quick wins vs development
Quick (no code): calendar posts, status cards, outreach, posters, Search Console. Needs development: seeded challenge links, referral attribution, Kinyarwanda/French, accounts, leaderboards, push.
## Never do
Fake reviews, bots, engagement pods, buying followers, spam messaging, misleading giveaways, posting in groups without permission.
