# Dogoma (Next.js)

`npm install && npm run dev`. 

With no Supabase variables it plays from `src/data/seed.json` (Supabase is not integrated yet). 

Copy `.env.example` and set `NEXT_PUBLIC_APP_URL` for the desktop QR code.

Layout: 
- `src/core` (scoring, session, analytics, points, daily), 
- `src/services` (repositories and local adapters), 
- `src/lib` (storage, sync, install, env), 
- `src/components`, 
- `src/app` (routes: `/`, `/learn`, `/daily`, `/leaderboard`, `/profile`), 
- `public` (PWA), 
- `supabase` (migrations, never executed), 
- `docs`.

Status: never compiled or run in a browser. 
Read `docs/PRODUCT_AUDIT.md` first, then `docs/DEVICE_TEST_PLAN.md`. 

`npm test` runs the Node tests.
