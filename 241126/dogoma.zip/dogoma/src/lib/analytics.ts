/** Privacy-conscious events. Sends only if Umami is configured and Do Not Track is off. Never sends answers, names or guest ids; only mode, topic and aggregate counts. */
type Props=Record<string,string|number|boolean>;
export function track(name:string,props?:Props){try{if(typeof window==='undefined'||navigator.doNotTrack==='1')return;(window as unknown as {umami?:{track:(n:string,p?:Props)=>void}}).umami?.track(name,props)}catch{/* analytics must never break the game */}}
