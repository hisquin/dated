'use client';
import {useEffect,useState} from 'react';
import {addGame,readGuest,type Guest} from './guest-store';
export type {GameRec} from './guest-store';
export function useGuest(){const [d,setD]=useState<Guest>({id:'',games:[],xp:0});useEffect(()=>{setD(readGuest())},[]);
 return{d,record:(g:import('./guest-store').GameRec)=>setD(p=>addGame(p,g))}}
export const shuf=<T,>(a:T[])=>{a=[...a];for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
