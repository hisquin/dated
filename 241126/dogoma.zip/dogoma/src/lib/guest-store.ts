export interface GameRec{sid?:string;cat?:Record<string,[number,number]>;t:number;mode:'count'|'time';score:number;ok:number;n:number}
export interface Guest{id:string;games:GameRec[];xp:number}
export const GUEST_KEY='dogoma.guest';
/** Reads (and on first use creates) the local guest record. Browser storage only; nothing here is server-synchronised. */
export function readGuest():Guest{try{const r=JSON.parse(localStorage.getItem(GUEST_KEY)||'null');if(r&&Array.isArray(r.games))return r}catch{/* fall through */}
 const g:Guest={id:typeof crypto!=='undefined'&&crypto.randomUUID?crypto.randomUUID():'g'+Date.now(),games:[],xp:0};try{localStorage.setItem(GUEST_KEY,JSON.stringify(g))}catch{/* private mode */}return g}
export function addGame(prev:Guest,g:GameRec):Guest{if(g.sid&&prev.games.some(x=>x.sid===g.sid))return prev;const n={...prev,games:[...prev.games,g].slice(-50),xp:prev.xp+g.score};try{localStorage.setItem(GUEST_KEY,JSON.stringify(n))}catch{/* private mode */}return n}
