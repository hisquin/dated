import Link from 'next/link';
export default function NotFound(){return <section className="hero"><h1>Page not found.</h1><p className="mu">That page does not exist.</p><Link className="btn" href="/">Back to Play</Link></section>}
