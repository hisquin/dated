export const metadata={robots:{index:false}};
import Link from 'next/link';
import {getLearning} from '@/services/local';
export default async function Learn({searchParams}:{searchParams:Promise<{topic?:string}>}){const {topic}=await searchParams,r=getLearning(),[subjects,topics]=await Promise.all([r.getSubjects(),r.getTopics()]),match=topic?topics.filter(t=>t.quizCategory===topic||t.id===topic):[];
 return <><section className="hero"><p className="kick">Learn</p><h1>Know more.</h1><p className="mu">Structured topics that build the knowledge you test in Play.</p></section>
 {topic&&<p role="status">{match.length?`Learning material for “${topic}”:`:`There is no learning material for “${topic}” yet.`}</p>}
 {subjects.length===0?<div className="fb"><b>No learning content published yet</b><p>Topics and articles will appear here once they are published. Meanwhile you can keep playing or read Daily Knowledge.</p><div className="row"><Link className="btn" href="/">Play a quiz</Link><Link className="chip" href="/daily">Daily Knowledge</Link></div></div>
 :subjects.map(s=><section key={s.id}><h2>{s.name}</h2><p>{s.description}</p><ul>{topics.filter(t=>t.subjectId===s.id).map(t=><li key={t.id}>{t.name}: {t.summary} {t.quizCategory&&<Link href="/">Test yourself</Link>}</li>)}</ul></section>)}</>}
