import {LeaderboardView} from '@/components/Views';
export const metadata={robots:{index:false}};
export default function Page(){return <LeaderboardView/>}
