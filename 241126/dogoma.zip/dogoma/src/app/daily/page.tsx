export const metadata={robots:{index:false}};
import {DailyView} from '@/components/Views';
import {getDaily} from '@/services/local';
export default async function Daily(){return <DailyView items={await getDaily().getAll()}/>}
