import type {MetadataRoute} from 'next';
import {ENV} from '@/lib/env';
/** Only pages with real content. /learn, /daily, /leaderboard and /profile are noindex until they have content. */
export default function sitemap():MetadataRoute.Sitemap{if(!ENV.appUrl)return[];const b=ENV.appUrl.replace(/\/$/,'');return['','/welcome','/privacy','/terms'].map(p=>({url:b+p||b+'/'}))}
