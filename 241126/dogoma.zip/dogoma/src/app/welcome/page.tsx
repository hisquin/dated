import Link from 'next/link';
import PlayLink from '@/components/PlayLink';
import {autostartHref} from '@/core/autostart';
import {ACTIVE_COUNTRY} from '@/core/config';
import {getRepository} from '@/services/content';
export const revalidate=60;
const DESC='Dogoma is a free Rwanda knowledge game. Tap Start playing and a game begins right away. No account needed.';
export const metadata={title:'Start playing free',description:DESC,alternates:{canonical:'/welcome'},openGraph:{title:'Dogoma: Know Rwanda. Start playing free.',description:DESC,url:'/welcome',images:[{url:'/og.png',width:1200,height:630,alt:'Dogoma: know where you come from'}]},twitter:{title:'Dogoma: Know Rwanda. Start playing free.',description:DESC}};
const cap=(s:string)=>s[0].toUpperCase()+s.slice(1);
export default async function Welcome(){
 let cats:[string,number][]=[];
 try{const m=new Map<string,number>();(await getRepository().listPublished({country:ACTIVE_COUNTRY})).forEach(q=>m.set(q.category,(m.get(q.category)??0)+1));cats=[...m]}catch{/* topic shortcuts are optional */}
 return <div className="welcome">
  <section className="hero"><p className="kick">Know Rwanda</p><h1>Know where you come from.</h1>
   <p className="lead">A free Rwanda knowledge game. Race the clock, earn more for faster correct answers and see what to improve.</p>
   <div className="cta-row"><PlayLink href={autostartHref()} placement="hero" className="btn big">Start playing</PlayLink><PlayLink href={autostartHref({mode:'time',dur:60})} placement="hero-60s" className="chip big">60-second challenge</PlayLink></div>
   <p className="mu">Starts right away: 15 mixed questions, or one minute against the clock. Free, no account.</p>
   <p><Link className="lnk" href="/">Choose a topic and format instead</Link></p></section>
  <section><h2>How it works</h2><ol className="wsteps"><li><b>1</b><h3>Answer</h3><p>Pick the right option, or type, order or match. Every question has its own time limit.</p></li><li><b>2</b><h3>Be quick</h3><p>Faster correct answers earn more points. Wrong answers earn nothing.</p></li><li><b>3</b><h3>Improve</h3><p>Your results show accuracy, speed and which topics need work.</p></li></ol></section>
  {cats.length>0&&<section><h2>Jump straight into a topic</h2><div className="topics">{cats.map(([c,n])=><PlayLink key={c} href={autostartHref({topic:c})} placement={'topic-'+c} className="chip big">{cap(c)} <small>({n})</small></PlayLink>)}</div></section>}
  <section><h2>Good to know</h2><ul className="wlist"><li>Free to play. No sign-up. Your progress is saved on your device.</li><li>Choose 5 to 20 questions, or play against the clock for 1 to 5 minutes.</li><li>Dogoma is new, so the question bank is still small and grows as questions are checked against sources.</li><li>Learning topics, Daily Knowledge and leaderboards are on the way.</li></ul>
   <div className="cta-row"><PlayLink href={autostartHref()} placement="footer" className="btn big">Start playing</PlayLink></div>
   <p className="mu"><Link href="/privacy">Privacy</Link> · <Link href="/terms">Terms</Link></p></section></div>}
