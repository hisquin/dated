import type {Metadata,Viewport} from 'next';
import {Bricolage_Grotesque,Instrument_Sans} from 'next/font/google';
import Script from 'next/script';
import {ENV} from '@/lib/env';
import Pwa from '@/components/Pwa';
import Nav from '@/components/Nav';
import InstallCard from '@/components/InstallCard';
import './globals.css';
const display=Bricolage_Grotesque({subsets:['latin'],axes:['opsz','wdth'],variable:'--font-display',display:'swap'});
const body=Instrument_Sans({subsets:['latin'],variable:'--font-body',display:'swap'});
const TITLE='Dogoma: Know Rwanda. A free knowledge game',DESC='Dogoma is a free Rwanda knowledge game. Answer history, geography and culture questions against the clock. No account needed.';
export const metadata:Metadata={metadataBase:new URL(ENV.appUrl??'http://localhost:3000'),title:{default:TITLE,template:'%s | Dogoma'},description:DESC,applicationName:'Dogoma',manifest:'/manifest.webmanifest',alternates:{canonical:'/'},appleWebApp:{capable:true,title:'Dogoma',statusBarStyle:'black-translucent'},icons:{icon:'/icons/icon-192.png',apple:'/icons/icon-192.png'},openGraph:{type:'website',siteName:'Dogoma',title:TITLE,description:DESC,images:[{url:'/og.png',width:1200,height:630,alt:'Dogoma: know where you come from'}]},twitter:{card:'summary_large_image',title:TITLE,description:DESC,images:['/og.png']}};
const LD={'@context':'https://schema.org','@type':'WebApplication',name:'Dogoma',description:DESC,applicationCategory:'GameApplication',operatingSystem:'Any',browserRequirements:'Requires JavaScript',inLanguage:'en',offers:{'@type':'Offer',price:'0',priceCurrency:'RWF'},...(ENV.appUrl?{url:ENV.appUrl}:{})};
const UMAMI={src:process.env.NEXT_PUBLIC_UMAMI_SRC,id:process.env.NEXT_PUBLIC_UMAMI_WEBSITE_ID};
export const viewport:Viewport={themeColor:'#171A19',width:'device-width',initialScale:1,viewportFit:'cover'};
export default function RootLayout({children}:{children:React.ReactNode}){
 return <html lang="en" className={`${display.variable} ${body.variable}`}><body><script type="application/ld+json" dangerouslySetInnerHTML={{__html:JSON.stringify(LD)}}/>{UMAMI.src&&UMAMI.id&&<Script defer src={UMAMI.src} data-website-id={UMAMI.id} data-do-not-track="true" strategy="afterInteractive"/>}<Pwa/><header><svg className="logo" viewBox="0 0 100 112" fill="none" stroke="currentColor" strokeWidth="11" strokeLinecap="round" aria-hidden="true"><circle cx="50" cy="14" r="10" fill="currentColor" stroke="none"/><path d="M16 46C2 74 22 98 42 104 68 110 90 90 90 58 90 44 82 34 76 30"/><path d="M26 82C48 92 68 80 64 62 62 50 44 50 34 60"/></svg><span className="brand">DOGOMA</span></header><InstallCard/><main id="app">{children}</main><Nav/></body></html>}
