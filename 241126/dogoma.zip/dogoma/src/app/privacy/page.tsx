export const metadata={title:'Privacy'};
/** DRAFT. Reflects what the app does today. Have a Rwandan lawyer review it, and check NCSA registration duties, before launch. */
export default function Privacy(){return <article><section className="hero"><p className="kick">Privacy</p><h1>What Dogoma keeps.</h1><p className="mu">Draft, last updated for the current version of the app.</p></section>
 <h2>On your device</h2><p>Dogoma saves your game history, scores and a random guest ID in your browser (local storage and IndexedDB) so you can resume and see your progress. This data stays on your device. There are no accounts yet.</p>
 <h2>Measurement</h2><p>If analytics is switched on, Dogoma counts anonymous events such as a game starting or finishing, the game mode and the topic. It does not record your answers, name, phone number or guest ID, and it respects your browser’s Do Not Track setting. It does not use advertising cookies.</p>
 <h2>Sharing</h2><p>If you tap Share result, your device shares a message with your score and a link. Nothing is sent unless you choose to share.</p>
 <h2>Your choices</h2><p>Clear your browser data to delete everything Dogoma keeps on your device. Contact: add your support email here before launch.</p></article>}
