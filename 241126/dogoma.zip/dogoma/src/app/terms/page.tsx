export const metadata={title:'Terms'};
/** DRAFT. Have a Rwandan lawyer review before launch. */
export default function Terms(){return <article><section className="hero"><p className="kick">Terms</p><h1>Playing fair.</h1><p className="mu">Draft.</p></section>
 <h2>Free to use</h2><p>Dogoma is free. There are no purchases or subscriptions.</p>
 <h2>Scores</h2><p>Scores shown on your device are for your own enjoyment. They are not verified rankings.</p>
 <h2>Content</h2><p>Questions are written and checked with care, but mistakes can happen. If you spot one, tell us using the contact on the Privacy page.</p>
 <h2>Fair use</h2><p>Do not try to disrupt the service or tamper with scores.</p></article>}
