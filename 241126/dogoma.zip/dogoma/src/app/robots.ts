import type {MetadataRoute} from 'next';
import {ENV} from '@/lib/env';
export default function robots():MetadataRoute.Robots{return{rules:[{userAgent:'*',allow:'/'}],...(ENV.appUrl?{sitemap:ENV.appUrl.replace(/\/$/,'')+'/sitemap.xml'}:{})}}
