'use client';
export default function Error({reset}:{error:Error;reset:()=>void}){return <section className="hero" role="alert"><h1>Something went wrong.</h1><p className="mu">Your saved progress is safe on this device.</p><button type="button" className="btn" onClick={reset}>Try again</button></section>}
