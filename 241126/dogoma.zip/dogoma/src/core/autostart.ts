import {CFG} from './config';
export interface Autostart{mode:'count'|'time';n:number;dur:number;topic:string}
/** Reads a launch request such as ?autostart=1&mode=time&dur=60&topic=history. Unknown or invalid values fall back to safe defaults. */
export function parseAutostart(search:string):Autostart|null{const p=new URLSearchParams(search);if(p.get('autostart')!=='1')return null;const n=Number(p.get('n')),d=Number(p.get('dur')),t=p.get('topic')||'all';
 return{mode:p.get('mode')==='time'?'time':'count',n:CFG.counts.includes(n)?n:15,dur:CFG.durations.includes(d)?d:60,topic:/^[a-z-]{1,30}$/.test(t)?t:'all'}}
export function autostartHref(o:Partial<Autostart>={}){const p=new URLSearchParams({autostart:'1'});if(o.mode==='time'){p.set('mode','time');p.set('dur',String(o.dur??60))}else if(o.n)p.set('n',String(o.n));if(o.topic&&o.topic!=='all')p.set('topic',o.topic);return '/?'+p.toString()}
