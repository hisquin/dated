'use client';
import Link from 'next/link';
import {track} from '@/lib/analytics';
export default function PlayLink({href,placement,className,children}:{href:string;placement:string;className?:string;children:React.ReactNode}){
 return <Link href={href} className={className} onClick={()=>track('play_click',{page:'welcome',placement})}>{children}</Link>}
