'use client';
import Link from 'next/link';
import {useEffect,useState} from 'react';
import {aggregate,insights} from '@/core/analytics';
import {itemFor,type DailyItem} from '@/core/daily';
import type {GameRec} from '@/lib/guest-store';
import {getPlayer,getResults} from '@/services/browser';
import {InstallRow} from './InstallCard';
function useLocal(){const [g,setG]=useState<GameRec[]|null>(null),[pts,setPts]=useState(0);useEffect(()=>{void getResults().getPlayerResults().then(setG);void getPlayer().getPlayer().then(p=>setPts(p.lifetimePoints))},[]);return{games:g,pts}}
const cap=(s:string)=>s[0].toUpperCase()+s.slice(1);
export function DailyView({items}:{items:DailyItem[]}){const [now,setNow]=useState<number|null>(null);useEffect(()=>setNow(Date.now()),[]);
 const it=now===null?undefined:itemFor(items,now,Intl.DateTimeFormat().resolvedOptions().timeZone);
 return <><section className="hero"><p className="kick">Daily Knowledge</p><h1>One thing worth knowing.</h1></section>
 {now===null?<p role="status">Loading…</p>:it?<article><p className="kick">{cap(it.category)}</p><h2>{it.title}</h2><p>{it.body}</p><small>Sources: {it.sources.join('; ')}</small><div className="row">{it.learnTopic&&<Link className="chip" href={`/learn?topic=${encodeURIComponent(it.learnTopic)}`}>Learn more</Link>}{it.quizCategory&&<Link className="chip" href="/">Test yourself</Link>}</div></article>
 :<div className="fb"><b>Nothing published for today</b><p>Daily items appear here once they are published with a source. Reminders need an account and a notification service, which are not available yet.</p><div className="row"><Link className="btn" href="/">Play a quiz</Link></div></div>}</>}
export function LeaderboardView(){const {games}=useLocal(),top=[...(games??[])].sort((a,b)=>b.score-a.score).slice(0,10);
 return <><section className="hero"><p className="kick">Leaderboard</p><h1>Where you stand.</h1></section>
 <div className="fb"><b>Official rankings: not available yet</b><p>Official rankings need registered players and scores verified by a server. Neither exists yet, and Dogoma will not present unverified scores as rankings.</p></div>
 <h2>Your best scores on this device</h2><p className="mu">Local and unverified. Only you can see these.</p>
 {games===null?<p role="status">Loading…</p>:top.length===0?<p>No games yet. <Link href="/">Play a quiz</Link> to set a score.</p>:<table className="tbl"><tbody>{top.map((g,i)=><tr key={g.sid??g.t}><td className="num">{i+1}</td><td className="num">{g.score} pts</td><td>{g.mode==='time'?'Against the clock':'Quiz'}</td><td>{new Date(g.t).toLocaleDateString()}</td></tr>)}</tbody></table>}</>}
export function ProfileView(){const {games,pts}=useLocal(),g=games??[],ok=g.reduce((a,x)=>a+x.ok,0),n=g.reduce((a,x)=>a+x.n,0),ins=insights(aggregate(g),3),best=g.reduce((m,x)=>Math.max(m,x.score),0);
 const st=(v:string|number,l:string)=><div><b className="num">{v}</b><small>{l}</small></div>;
 return <><section className="hero"><p className="kick">Profile</p><h1>Guest player</h1><p className="mu">Your progress is saved on this device only. Accounts, cross-device progress and leaderboard entry are not available yet.</p></section>
 <div className="sg">{st(g.length,'games played')}{st(pts,'points on this device')}{st(best,'best score')}{st(n?Math.round(ok/n*100)+'%':'–','accuracy')}</div>
 <h2>Insights</h2>{ins.strongest?<p>Strongest: {cap(ins.strongest.key)}.{ins.improve[0]?<> Improve: <Link href={`/learn?topic=${encodeURIComponent(ins.improve[0].key)}`}>{cap(ins.improve[0].key)}</Link>.</>:' No weak areas yet.'}</p>:<p className="mu">Play a few more questions in each topic to see your strengths and areas to improve.</p>}
 <h2>Install</h2><InstallRow/><h2>Achievements and daily reminders</h2><p className="mu">Not available yet. They need an account and a server.</p></>}
