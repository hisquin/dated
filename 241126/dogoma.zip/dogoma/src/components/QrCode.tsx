'use client';
import {useEffect,useState} from 'react';
import QRCode from 'qrcode';
/** Renders a QR code for the public URL. If generation fails the player still gets the address in text. */
export default function QrCode({url}:{url:string}){const [svg,setSvg]=useState<string|null>(null),[failed,setFailed]=useState(false);
 useEffect(()=>{let off=false;QRCode.toString(url,{type:'svg',margin:1,errorCorrectionLevel:'M',color:{dark:'#171A19',light:'#F5F2EA'}}).then(s=>{if(!off)setSvg(s)}).catch(()=>{if(!off)setFailed(true)});return()=>{off=true}},[url]);
 if(failed)return <p role="status">The QR code could not be drawn. On your phone, open <b>{url}</b>.</p>;
 return svg?<div className="qr" role="img" aria-label={`QR code that opens ${url}`} dangerouslySetInnerHTML={{__html:svg}}/>:<p className="mu">Preparing QR code…</p>}
