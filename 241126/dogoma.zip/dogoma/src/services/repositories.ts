import type {Article,Subject,Topic} from '@/core/learning';
import type {DailyItem} from '@/core/daily';
import type {Question} from '@/core/types';
import type {Sess} from '@/core/session';
import type {GameRec} from '@/lib/guest-store';
/** Boundaries the UI depends on. Local adapters live in local.ts; a Supabase adapter can replace each one without touching components. */
export interface QuestionRepository{listPublished(o:{country:string;includeContinental?:boolean}):Promise<Question[]>} // implemented in content.ts
export interface GameSessionRepository{saveSession(s:Sess):Promise<boolean>;resumeSession():Promise<Sess|undefined>;discardSession():Promise<void>;completeSession(s:Sess):Promise<void>}
export interface ResultsRepository{getPlayerResults():Promise<GameRec[]>} // saving goes through the outbox (store.ts finishSession)
export interface LearningRepository{getSubjects():Promise<Subject[]>;getTopics(subjectId?:string):Promise<Topic[]>;getLearningContent(topicId:string):Promise<Article[]>}
export interface DailyRepository{getAll():Promise<DailyItem[]>}
export interface PlayerRepository{getPlayer():Promise<{id:string;registered:boolean;displayName:string;lifetimePoints:number}>}
/** Requires authenticated admin access and server-side checks. Deliberately has no local implementation. */
export interface AdminRepository{createQuestion(q:Question):Promise<void>;updateQuestion(q:Question):Promise<void>;deleteQuestion(id:string):Promise<void>;publishQuestion(id:string):Promise<void>}
