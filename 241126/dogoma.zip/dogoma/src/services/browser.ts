import type {Sess} from '../core/session';
import {readGuest} from '../lib/guest-store';
import {clearSession,finishSession,loadSession,saveSession} from '../lib/store';
import type {GameSessionRepository,PlayerRepository,ResultsRepository} from './repositories';
/** Browser-only adapters (IndexedDB and localStorage). A Supabase adapter would replace these behind the same interfaces. */
export const getSessions=():GameSessionRepository=>({saveSession,resumeSession:loadSession,discardSession:async()=>{await clearSession()},
 completeSession:s=>finishSession({id:s.sid,guestId:s.gid,mode:s.mode,score:s.score,attempted:s.log.length,correct:s.log.filter(x=>x.res==='ok').length,startedAt:s.t0,endedAt:s.t1,offline:s.offline})});
export const getResults=():ResultsRepository=>({getPlayerResults:async()=>readGuest().games});
export const getPlayer=():PlayerRepository=>({getPlayer:async()=>{const g=readGuest();return{id:g.id,registered:false,displayName:'Guest',lifetimePoints:g.xp}}});
export type {Sess};
