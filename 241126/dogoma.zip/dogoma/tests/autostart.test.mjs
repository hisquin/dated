import assert from 'node:assert/strict';
const {parseAutostart:P,autostartHref:H}=await import('../.test-build/core/autostart.js');
assert.equal(P(''),null);assert.equal(P('?autostart=0'),null,'only autostart=1 launches');assert.equal(P('?mode=time'),null,'no launch without the flag');
assert.deepEqual(P('?autostart=1'),{mode:'count',n:15,dur:60,topic:'all'},'defaults: 15 mixed questions');
assert.deepEqual(P('?autostart=1&mode=time&dur=120&topic=history'),{mode:'time',n:15,dur:120,topic:'history'});
assert.equal(P('?autostart=1&n=7').n,15,'unsupported question count falls back');assert.equal(P('?autostart=1&mode=time&dur=9999').dur,60,'unsupported duration falls back');
assert.equal(P('?autostart=1&topic=../../x').topic,'all','unsafe topic is ignored');assert.equal(P('?autostart=1&mode=weird').mode,'count');
assert.equal(H(),'/?autostart=1');assert.equal(H({mode:'time',dur:60}),'/?autostart=1&mode=time&dur=60');assert.equal(H({topic:'geography'}),'/?autostart=1&topic=geography');assert.equal(H({n:10}),'/?autostart=1&n=10');
for(const o of [{},{mode:'time',dur:180},{topic:'culture'},{n:5}]){const q=H(o).split('?')[1];assert.ok(P('?'+q),'round trip '+q)}
console.log('Autostart links: all checks passed');
