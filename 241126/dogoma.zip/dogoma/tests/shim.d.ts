// Test build only: lets core modules that read process.env compile without @types/node installed.
declare const process:{env:Record<string,string|undefined>};
