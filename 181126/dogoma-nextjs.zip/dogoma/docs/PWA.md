# PWA: audit, behaviour and limits
## Audit of the previous version
| Area | Finding | Now |
|---|---|---|
| App shell | Only `/` and icons were precached; JS chunks and fonts were cached only after being fetched, so a first offline load could fail. The cached `/` was never refreshed. | The page sends its loaded `/_next/static/` URLs to the worker after registration; `/` is refreshed on every successful visit; navigations time out after 4s to the cache for slow networks. |
| Questions offline | Not stored. | Published questions are saved to IndexedDB on each successful load and replaced wholesale (unpublished questions cannot linger). Offline, the saved set is used and the home screen says so with its date. |
| Results | Browser history only, no queue. | Every finished game goes into an IndexedDB outbox with a UUID that is also the `game_sessions` primary key. Sync retries on reconnect, on start, every 60s and on "Sync now". A duplicate key counts as already synced. After 8 failures an item is parked until a manual sync. |
| Status | Offline banner only. | Banner shows offline state, results waiting, failures, sync result, update and install. It reports sync only when Supabase is configured. |
| Updates | None; stale workers lingered. | A new worker waits; the player sees "Update available" and reloads when ready. It never reloads mid-game. Caches are versioned (`VERSION` in `sw.js`). |
| Manifest | No `id`. | `id`, standalone display, maskable icon. |
| Trust | Client scores had no marker. | Migration `20260101000600` adds `offline`, `verified`, `app_version` and rejects any client insert with `verified=true`. |
Never cached: Supabase and other cross-origin requests, `/admin`, `/api`, non-GET requests.
## Limits
Synced scores are unverified client reports and must not feed leaderboards until server-side verification exists. A game in progress is lost on refresh. No Background Sync (sync needs the app open). No iOS install hint. Offline sessions are only flagged `offline` when played from saved questions or without a connection at the end.
## Tests
`npm test` runs `tests/pwa.test.mjs` (worker routing against a mocked Cache API) and `tests/sync.test.mjs` (outbox idempotency, retry, concurrency). They do not cover a real browser, real IndexedDB or Supabase.
