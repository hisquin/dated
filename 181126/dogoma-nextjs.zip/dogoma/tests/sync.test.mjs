import assert from 'node:assert/strict';import {runSync} from '../.test-build/sync-core.js';
const mk=(id,tries=0)=>({id,guestId:'g',mode:'count',score:50,attempted:5,correct:3,startedAt:1,endedAt:2,offline:true,tries});
const db=new Map([['a',mk('a')],['b',mk('b')]]);let calls=0,mode='fail';
const d={list:async()=>[...db.values()],save:async r=>db.set(r.id,r),remove:async id=>db.delete(id),insert:async r=>{calls++;await new Promise(x=>setTimeout(x,5));return mode==='fail'?{message:'network'}:mode==='dup'?{code:'23505',message:'dup'}:null}};
let r=await runSync(d);assert.deepEqual([r.synced,r.failed],[0,2]);assert.equal(db.size,2,'failed results are kept');assert.equal(db.get('a').tries,1);
mode='ok';calls=0;const [x,y]=await Promise.all([runSync(d),runSync(d)]);assert.equal(x,y,'concurrent syncs share one run');assert.equal(calls,2,'each result inserted once');assert.equal(db.size,0,'synced results leave the outbox');
db.set('c',mk('c'));mode='dup';r=await runSync(d);assert.equal(r.synced,1,'duplicate key counts as already synced');assert.equal(db.size,0);
db.set('s',mk('s',8));mode='ok';calls=0;r=await runSync(d);assert.equal(r.skipped,1);assert.equal(calls,0,'exhausted items skipped');r=await runSync(d,true);assert.equal(r.synced,1,'force retries them');
console.log('Sync outbox: all checks passed');
