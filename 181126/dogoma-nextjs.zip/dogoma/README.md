# Dogoma (Next.js)
`npm install && npm run dev`. With no Supabase variables set it plays from `src/data/seed.json`. To use Supabase, run the migrations in `supabase/migrations` (see `docs/SUPABASE_SETUP.md`) and set `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`.
Layout: `src/core` (types, scoring, answer handlers), `src/services/content.ts` (repository: local or Supabase), `src/components` (game UI), `src/lib/guest.ts` (guest storage), `public` (PWA files).
Status: written without running `npm install`, `tsc` or `next build`. Run `npm run typecheck` first. No admin dashboard yet.

PWA details and limits: `docs/PWA.md`. Run `npm test` for the worker and sync tests.
