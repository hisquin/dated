/* Dogoma service worker. Caches the app shell and static assets only. It never touches Supabase (cross-origin), /admin or /api, so unpublished or admin data is never cached. Bump VERSION on each release to purge old caches. */
const VERSION='v2',SHELL='dogoma-shell-'+VERSION,STATIC='dogoma-static-'+VERSION,PRE=['/','/offline.html','/manifest.webmanifest','/icons/icon-192.png','/icons/icon-512.png'];
self.addEventListener('install',e=>e.waitUntil(caches.open(SHELL).then(c=>c.addAll(PRE)))); // no skipWaiting: an update must never reload a game in progress
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==SHELL&&x!==STATIC).map(x=>caches.delete(x)))).then(()=>self.clients.claim())));
self.addEventListener('message',e=>{const d=e.data||{};if(d.type==='SKIP_WAITING')self.skipWaiting();
 if(d.type==='CACHE_URLS')e.waitUntil(caches.open(STATIC).then(c=>Promise.all((d.urls||[]).filter(u=>{try{const x=new URL(u);return x.origin===location.origin&&x.pathname.startsWith('/_next/static/')}catch{return false}}).map(u=>c.add(u).catch(()=>{})))))});
const timeout=(ms)=>new Promise((_,j)=>setTimeout(j,ms));
self.addEventListener('fetch',e=>{const r=e.request;if(r.method!=='GET')return;const u=new URL(r.url);
 if(u.origin!==location.origin||u.pathname.startsWith('/admin')||u.pathname.startsWith('/api'))return;
 if(r.mode==='navigate'){e.respondWith(Promise.race([fetch(r),timeout(4000)]).then(res=>{if(res.ok&&u.pathname==='/'){const cp=res.clone();caches.open(SHELL).then(c=>c.put('/',cp))}return res}).catch(()=>caches.match('/').then(h=>h||caches.match('/offline.html'))));return}
 if(u.pathname.startsWith('/_next/static/')||u.pathname.startsWith('/icons/')||u.pathname==='/manifest.webmanifest')e.respondWith(caches.match(r).then(h=>h||fetch(r).then(res=>{if(res.ok){const cp=res.clone();caches.open(STATIC).then(c=>c.put(r,cp))}return res})))});
