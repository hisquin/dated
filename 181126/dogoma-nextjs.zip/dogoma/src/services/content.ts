import {createClient} from '@supabase/supabase-js';
import seed from '@/data/seed.json';
import {validateQuestion} from '@/core/handlers';
import type {Question,QType} from '@/core/types';
export interface ListOpts{country:string;includeContinental?:boolean}
export interface ContentRepository{listPublished(o:ListOpts):Promise<Question[]>}
const keep=(qs:Question[],o:ListOpts)=>qs.filter(q=>!validateQuestion(q)&&((q.scope==='country'&&q.countries.includes(o.country))||(!!o.includeContinental&&q.scope!=='country')));
class LocalRepository implements ContentRepository{async listPublished(o:ListOpts){return keep(seed as unknown as Question[],o)}}
const SELECT='code,scope,prompt,explanation,difficulty,question_type,validation,categories(slug),subcategories(slug),question_options(position,label,match_label,is_correct),accepted_answers(answer,is_primary),question_sources(sources(title)),question_countries(countries(iso_code))';
/* eslint-disable @typescript-eslint/no-explicit-any */
export function fromRow(r:any):Question{const t=r.question_type as QType,o=[...(r.question_options??[])].sort((a:any,b:any)=>a.position-b.position),acc=r.accepted_answers??[],one=(x:any)=>Array.isArray(x)?x[0]:x;
 const q:Question={id:r.code,scope:r.scope,countries:(r.question_countries??[]).map((c:any)=>one(c.countries)?.iso_code).filter(Boolean),category:one(r.categories)?.slug,subcategory:one(r.subcategories)?.slug,difficulty:r.difficulty,type:t,question:r.prompt,explanation:r.explanation??'',validation:r.validation??undefined,sources:(r.question_sources??[]).map((s:any)=>one(s.sources)?.title).filter(Boolean)};
 if(t==='multiple_choice'||t==='true_false'){q.options=o.map((x:any)=>x.label);q.correct_answer=o.find((x:any)=>x.is_correct)?.label}
 else if(t==='chronological_order'){q.options=o.map((x:any)=>x.label);q.correct_answer=q.options}
 else if(t==='matching')q.pairs=o.map((x:any)=>[x.label,x.match_label]);
 else{const p=acc.find((a:any)=>a.is_primary)??acc[0];q.correct_answer=p?.answer;q.accepted_answers=acc.map((a:any)=>a.answer)}
 return q}
/** Reads with the public anon key; row-level security returns published questions only. */
class SupabaseRepository implements ContentRepository{constructor(private url:string,private key:string){}
 async listPublished(o:ListOpts){const sb=createClient(this.url,this.key,{auth:{persistSession:false}});const {data,error}=await sb.from('questions').select(SELECT).eq('status','published');if(error)throw new Error(error.message);return keep((data??[]).map(fromRow),o)}}
export function getRepository():ContentRepository{const u=process.env.NEXT_PUBLIC_SUPABASE_URL,k=process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;return u&&k?new SupabaseRepository(u,k):new LocalRepository()}
