'use client';
import {useCallback,useEffect,useRef,useState} from 'react';
import {all,get} from '@/lib/offline';
import {MAX_TRIES,type OutboxRec} from '@/lib/sync-core';
import {syncNow} from '@/lib/sync';
interface BIP extends Event{prompt():Promise<void>}
/** Registers the service worker and shows honest online, sync, update and install state. */
export default function Pwa(){
 const [online,setOnline]=useState(true),[pending,setPending]=useState(0),[stuck,setStuck]=useState(0),[note,setNote]=useState(''),[upd,setUpd]=useState<ServiceWorker|null>(null),[inst,setInst]=useState<BIP|null>(null),[ready,setReady]=useState(false),wantUpdate=useRef(false);
 const refresh=useCallback(async()=>{const r=(await all<OutboxRec>('outbox'))??[];setPending(r.length);setStuck(r.filter(x=>x.tries>=MAX_TRIES).length)},[]);
 const sync=useCallback(async(force=false)=>{if(!navigator.onLine)return;const r=await syncNow(force);if(r.configured)setNote(r.failed?`${r.failed} result(s) could not sync yet`:r.synced?`${r.synced} result(s) synced`:'');await refresh()},[refresh]);
 useEffect(()=>{if(process.env.NODE_ENV!=='production'||!('serviceWorker' in navigator))return;
  navigator.serviceWorker.register('/sw.js').then(reg=>{const watch=(w:ServiceWorker)=>w.addEventListener('statechange',()=>{if(w.state==='installed'&&navigator.serviceWorker.controller)setUpd(w)});
   if(reg.waiting&&navigator.serviceWorker.controller)setUpd(reg.waiting);reg.addEventListener('updatefound',()=>{if(reg.installing)watch(reg.installing)});
   navigator.serviceWorker.ready.then(r=>{r.active?.postMessage({type:'CACHE_URLS',urls:performance.getEntriesByType('resource').map(e=>e.name).filter(u=>u.includes('/_next/static/'))});
    setTimeout(async()=>setReady(!!(await caches.match('/'))&&!!(await get('questions','set'))),1500)})}).catch(()=>{});
  const cc=()=>{if(wantUpdate.current)location.reload()};navigator.serviceWorker.addEventListener('controllerchange',cc);return()=>navigator.serviceWorker.removeEventListener('controllerchange',cc)},[]);
 useEffect(()=>{const on=()=>{setOnline(navigator.onLine);if(navigator.onLine)sync()},ob=()=>{refresh();sync()},ip=(e:Event)=>{e.preventDefault();setInst(e as BIP)};on();refresh();
  addEventListener('online',on);addEventListener('offline',on);addEventListener('dogoma:outbox',ob);addEventListener('beforeinstallprompt',ip);const t=setInterval(()=>sync(),60000);
  return()=>{removeEventListener('online',on);removeEventListener('offline',on);removeEventListener('dogoma:outbox',ob);removeEventListener('beforeinstallprompt',ip);clearInterval(t)}},[sync,refresh]);
 const show=!online||pending>0||!!upd||!!inst||!!note;
 return <div id="nb" role="status" className={show?'on':''}>{show&&<>
  {!online&&<span>You’re offline{ready?'. Saved questions are ready to play.':'.'} </span>}
  {pending>0&&<span>{pending} result{pending>1?'s':''} saved on this device, not yet synced{stuck?` (${stuck} failing)`:''}. {online&&<button type="button" className="lnk" onClick={()=>sync(true)}>Sync now</button>}</span>}
  {note&&pending===0&&<span>{note}. </span>}
  {upd&&<button type="button" className="lnk" onClick={()=>{wantUpdate.current=true;upd.postMessage({type:'SKIP_WAITING'})}}>Update available: reload</button>}
  {inst&&<button type="button" className="lnk" onClick={()=>{inst.prompt();setInst(null)}}>Install Dogoma</button>}</>}</div>}
