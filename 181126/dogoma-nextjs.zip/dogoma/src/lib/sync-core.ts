export interface OutboxRec{id:string;guestId:string;mode:'count'|'time';score:number;attempted:number;correct:number;startedAt:number;endedAt:number;offline:boolean;tries:number;lastError?:string}
export interface SyncDeps{list():Promise<OutboxRec[]>;save(r:OutboxRec):Promise<unknown>;remove(id:string):Promise<unknown>;insert(r:OutboxRec):Promise<{code?:string;message:string}|null>}
export interface SyncResult{synced:number;failed:number;skipped:number}
export const MAX_TRIES=8;
let running:Promise<SyncResult>|null=null;
/** Idempotent: the session id is the primary key, so a repeat insert (23505) means "already stored". One run at a time. */
export function runSync(d:SyncDeps,force=false):Promise<SyncResult>{if(running)return running;
 running=(async()=>{const out:SyncResult={synced:0,failed:0,skipped:0};for(const r of await d.list()){if(r.tries>=MAX_TRIES&&!force){out.skipped++;continue}
  let err:{code?:string;message:string}|null;try{err=await d.insert(r)}catch(e){err={message:e instanceof Error?e.message:'network error'}}
  if(!err||err.code==='23505'){await d.remove(r.id);out.synced++}else{await d.save({...r,tries:(force?0:r.tries)+1,lastError:err.message});out.failed++}}return out})().finally(()=>{running=null});return running}
