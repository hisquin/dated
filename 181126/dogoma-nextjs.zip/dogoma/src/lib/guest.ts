'use client';
import {useEffect,useState} from 'react';
export interface GameRec{t:number;mode:'count'|'time';score:number;ok:number;n:number}
interface Guest{id:string;games:GameRec[];xp:number}
const K='dogoma.guest';
/** Local guest identity and history. Browser storage only; nothing here is server-synchronised. */
export function useGuest(){const [d,setD]=useState<Guest>({id:'',games:[],xp:0});
 useEffect(()=>{try{const r=JSON.parse(localStorage.getItem(K)||'null');if(r&&Array.isArray(r.games)){setD(r);return}}catch{}const n={id:crypto.randomUUID?.()??'g'+Date.now(),games:[],xp:0};setD(n);try{localStorage.setItem(K,JSON.stringify(n))}catch{}},[]);
 const record=(g:GameRec)=>setD(p=>{const n={...p,games:[...p.games,g].slice(-50),xp:p.xp+g.score};try{localStorage.setItem(K,JSON.stringify(n))}catch{}return n});
 return{d,record}}
export const shuf=<T,>(a:T[])=>{a=[...a];for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
