import {createClient} from '@supabase/supabase-js';
import {all,del,put} from './offline';
import {runSync,type OutboxRec,type SyncResult} from './sync-core';
export async function syncNow(force=false):Promise<SyncResult&{configured:boolean}>{const url=process.env.NEXT_PUBLIC_SUPABASE_URL,key=process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
 if(!url||!key)return{configured:false,synced:0,failed:0,skipped:0};const sb=createClient(url,key,{auth:{persistSession:false}});
 const r=await runSync({list:async()=>(await all<OutboxRec>('outbox'))??[],save:r=>put('outbox',r),remove:id=>del('outbox',id),
  insert:async r=>{const {error}=await sb.from('game_sessions').insert({id:r.id,guest_id:r.guestId,mode:r.mode,started_at:new Date(r.startedAt).toISOString(),ended_at:new Date(r.endedAt).toISOString(),score:r.score,attempted:r.attempted,correct:r.correct,offline:r.offline,app_version:process.env.NEXT_PUBLIC_APP_VERSION??'dev'});return error}},force);
 return{configured:true,...r}}
