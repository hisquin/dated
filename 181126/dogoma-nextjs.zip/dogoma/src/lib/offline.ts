'use client';
import {useEffect,useState} from 'react';
import type {Question} from '@/core/types';
import type {OutboxRec} from './sync-core';
const open=()=>new Promise<IDBDatabase>((res,rej)=>{const r=indexedDB.open('dogoma-offline',1);r.onupgradeneeded=()=>{r.result.createObjectStore('questions',{keyPath:'id'});r.result.createObjectStore('outbox',{keyPath:'id'})};r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)});
async function tx<T>(s:string,m:IDBTransactionMode,f:(o:IDBObjectStore)=>IDBRequest):Promise<T|undefined>{try{const d=await open();return await new Promise<T>((res,rej)=>{const r=f(d.transaction(s,m).objectStore(s));r.onsuccess=()=>res(r.result as T);r.onerror=()=>rej(r.error)})}catch{return undefined}}
export const put=(s:string,v:unknown)=>tx(s,'readwrite',o=>o.put(v)),get=<T,>(s:string,k:string)=>tx<T>(s,'readonly',o=>o.get(k)),all=<T,>(s:string)=>tx<T[]>(s,'readonly',o=>o.getAll()),del=(s:string,k:string)=>tx(s,'readwrite',o=>o.delete(k));
/** Queue a finished game for server sync. The id doubles as an idempotency key. */
export async function enqueue(r:Omit<OutboxRec,'tries'>){await put('outbox',{...r,tries:0});dispatchEvent(new Event('dogoma:outbox'))}
interface Saved{id:'set';at:number;items:Question[]}
/** Published questions are replaced wholesale on every successful online load, so unpublished questions never linger. */
export function useQuestionSet(srv:Question[],failed:boolean){const [st,setSt]=useState<{questions:Question[];source:'live'|'cache'|'none';cachedAt?:number}>({questions:srv,source:srv.length?'live':'none'});
 useEffect(()=>{let off=false;(async()=>{if(srv.length&&!failed){const at=Date.now();await put('questions',{id:'set',at,items:srv} satisfies Saved);if(!off)setSt({questions:srv,source:'live',cachedAt:at});return}
  const s=await get<Saved>('questions','set');if(!off&&s&&s.items.length)setSt({questions:s.items,source:'cache',cachedAt:s.at})})();return()=>{off=true}},[srv,failed]);return st}
