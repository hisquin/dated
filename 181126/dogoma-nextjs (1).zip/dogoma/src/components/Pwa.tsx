'use client';
import {useCallback,useEffect,useRef,useState} from 'react';
import {isStandalone,iosHintText,platform} from '@/lib/install';
import {listOutbox,setMeta} from '@/lib/store';
import {syncNow} from '@/lib/sync';
interface BIP extends Event{prompt():Promise<void>}
/** Service worker registration plus honest status: offline, per-state result counts, update, install. */
export default function Pwa(){
 const [online,setOnline]=useState(true),[c,setC]=useState({pending:0,failed:0,rejected:0}),[note,setNote]=useState(''),[upd,setUpd]=useState<ServiceWorker|null>(null),[inst,setInst]=useState<BIP|null>(null),[ready,setReady]=useState(false),[iosTip,setIosTip]=useState(''),[warn,setWarn]=useState(''),want=useRef(false);
 const refresh=useCallback(async()=>{const r=await listOutbox();setC({pending:r.filter(x=>(x.state??'pending')==='pending').length,failed:r.filter(x=>x.state==='failed').length,rejected:r.filter(x=>x.state==='rejected').length})},[]);
 const sync=useCallback(async(force=false)=>{if(!navigator.onLine)return;const r=await syncNow(force);if(r.configured)setNote(r.auth?'Sign in again to sync your results':r.failed?`${r.failed} result(s) could not sync yet`:r.synced?`${r.synced} result(s) synced (not yet verified)`:'');await refresh()},[refresh]);
 const bg=useCallback(async()=>{try{const reg=await navigator.serviceWorker.ready;await (reg as unknown as {sync?:{register(t:string):Promise<void>}}).sync?.register('dogoma-sync')}catch{/* Background Sync unsupported: foreground sync covers it */}},[]);
 useEffect(()=>{const u=process.env.NEXT_PUBLIC_SUPABASE_URL,k=process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;if(u&&k)void setMeta({id:'cfg',url:u,key:k}); // public anon values, read by the worker for Background Sync
  const p=platform(navigator.userAgent,navigator.maxTouchPoints);if(p.ios&&!isStandalone()&&localStorage.getItem('dogoma.iosHint')!=='1')setIosTip(iosHintText(p));
  if(process.env.NODE_ENV!=='production'||!('serviceWorker' in navigator))return;
  navigator.serviceWorker.register('/sw.js').then(reg=>{const watch=(w:ServiceWorker)=>w.addEventListener('statechange',()=>{if(w.state==='installed'&&navigator.serviceWorker.controller)setUpd(w)});
   if(reg.waiting&&navigator.serviceWorker.controller)setUpd(reg.waiting);reg.addEventListener('updatefound',()=>{if(reg.installing)watch(reg.installing)});
   navigator.serviceWorker.ready.then(r=>{r.active?.postMessage({type:'CACHE_URLS',urls:performance.getEntriesByType('resource').map(e=>e.name).filter(u=>u.includes('/_next/static/'))});setTimeout(async()=>setReady(!!(await caches.match('/'))),1500)})}).catch(()=>{});
  const cc=()=>{if(want.current)location.reload()};navigator.serviceWorker.addEventListener('controllerchange',cc);return()=>navigator.serviceWorker.removeEventListener('controllerchange',cc)},[]);
 useEffect(()=>{const on=()=>{setOnline(navigator.onLine);if(navigator.onLine)sync()},ob=()=>{refresh();void bg();sync()},ip=(e:Event)=>{e.preventDefault();setInst(e as BIP)},ai=()=>{setInst(null);setIosTip('')},st=(e:Event)=>setWarn((e as CustomEvent).detail==='quota'?'Storage is full, so questions could not be saved for offline play.':'Questions could not be saved for offline play.');
  on();refresh();addEventListener('online',on);addEventListener('offline',on);addEventListener('dogoma:outbox',ob);addEventListener('beforeinstallprompt',ip);addEventListener('appinstalled',ai);addEventListener('dogoma:storage',st);const t=setInterval(()=>sync(),60000);
  return()=>{removeEventListener('online',on);removeEventListener('offline',on);removeEventListener('dogoma:outbox',ob);removeEventListener('beforeinstallprompt',ip);removeEventListener('appinstalled',ai);removeEventListener('dogoma:storage',st);clearInterval(t)}},[sync,refresh,bg]);
 const waiting=c.pending+c.failed,show=!online||waiting>0||c.rejected>0||!!upd||!!inst||!!note||!!iosTip||!!warn;
 return <div id="nb" role="status" className={show?'on':''}>{show&&<>
  {!online&&<span>You’re offline{ready?'. Saved questions are ready to play.':'.'}</span>}
  {waiting>0&&<span>{waiting} result{waiting>1?'s':''} saved on this device, not yet synced{c.failed?` (${c.failed} failing)`:''}. {online&&<button type="button" className="lnk" onClick={()=>sync(true)}>Sync now</button>}</span>}
  {c.rejected>0&&<span>{c.rejected} result{c.rejected>1?'s were':' was'} refused by the server.</span>}
  {note&&waiting===0&&<span>{note}.</span>}{warn&&<span>{warn}</span>}
  {upd&&<button type="button" className="lnk" onClick={()=>{want.current=true;upd.postMessage({type:'SKIP_WAITING'})}}>Update available: reload</button>}
  {inst&&<button type="button" className="lnk" onClick={()=>{void inst.prompt();setInst(null)}}>Install Dogoma</button>}
  {iosTip&&<span>{iosTip} <button type="button" className="lnk" onClick={()=>{localStorage.setItem('dogoma.iosHint','1');setIosTip('')}}>Dismiss</button></span>}</>}</div>}
