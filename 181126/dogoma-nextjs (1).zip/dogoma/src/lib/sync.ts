import {createClient} from '@supabase/supabase-js';
import {listOutbox,putOutbox,removeOutbox} from './store';
import {runSync,type SyncResult} from './sync-core';
export async function syncNow(force=false):Promise<SyncResult&{configured:boolean}>{const url=process.env.NEXT_PUBLIC_SUPABASE_URL,key=process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;const none={synced:0,failed:0,skipped:0,rejected:0,auth:0};
 if(!url||!key)return{configured:false,...none};const sb=createClient(url,key,{auth:{persistSession:false}});
 const run=()=>runSync({list:listOutbox,save:putOutbox,remove:removeOutbox,insert:async r=>{const {error,status}=await sb.from('game_sessions').insert({id:r.id,guest_id:r.guestId,mode:r.mode,started_at:new Date(r.startedAt).toISOString(),ended_at:new Date(r.endedAt).toISOString(),score:r.score,attempted:r.attempted,correct:r.correct,offline:r.offline,app_version:process.env.NEXT_PUBLIC_APP_VERSION??'dev'});return error?{code:error.code,status,message:error.message}:null}},force);
 const locks=(navigator as Navigator&{locks?:LockManager}).locks; // one sync at a time across tabs
 const r=locks?await locks.request('dogoma-sync',{ifAvailable:true},l=>l?run():Promise.resolve(null)):await run();return{configured:true,...(r??none)}}
