# Real-device test plan (not yet executed)
Build with `npm run build && npm start` over HTTPS (or a deployed preview). Record pass/fail and device/browser for each step.
1. First online visit (Android Chrome): app loads; DevTools Application shows service worker activated, cache `dogoma-shell-v2` and `dogoma-static-v2` populated, IndexedDB `dogoma-offline` has `questions.current`.
2. Install: Chrome menu or in-app button; app opens standalone. iOS Safari: Share, Add to Home Screen; the hint disappears when launched from the icon.
3. Offline refresh: airplane mode, refresh. App loads and the banner says saved questions are ready.
4. Offline game: finish a 5-question game, including a typed answer and a timeout. Result appears; banner shows 1 result not yet synced.
5. Interruption: start a game, kill the app mid-question, reopen after 10s. Resume is offered, the deadline has not moved. Repeat with the app closed past the deadline (question unanswered) and past a timed session's end.
6. Close and reopen offline: result still queued (IndexedDB), history intact.
7. Reconnect: result syncs within a minute or via Sync now; row appears in `game_sessions` with `verified=false`, `offline=true`. Re-sync causes no duplicate.
8. Failure cases: block `*.supabase.co` and confirm failing state and retries; sign out/expire (when accounts exist); stale deploy: publish a new build and confirm "Update available" appears and does not reload mid-game.
9. Lighthouse PWA audit and storage-full behaviour (DevTools quota override).
