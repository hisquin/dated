// inyungu API — Node 22.5+, zero dependencies (node:http, node:sqlite, node:crypto)
import { DatabaseSync } from 'node:sqlite';
import http from 'node:http';
import crypto from 'node:crypto';
import { readFileSync, existsSync, statSync } from 'node:fs';
import { extname, join, normalize } from 'node:path';

const PORT = +process.env.PORT || 3000, BASE = process.env.BASE_URL || `http://localhost:${PORT}`;
const SECRET = process.env.SECRET || (console.warn('SECRET not set: using a random one, sessions reset on restart'), crypto.randomBytes(32).toString('hex'));
const db = new DatabaseSync(process.env.DB || 'inyungu.db');
db.exec(`PRAGMA journal_mode=WAL;PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,email TEXT UNIQUE NOT NULL,name TEXT NOT NULL,pw TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'user',created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS businesses(id INTEGER PRIMARY KEY,slug TEXT UNIQUE NOT NULL,name TEXT NOT NULL,kind TEXT NOT NULL,category TEXT NOT NULL,district TEXT,neighborhood TEXT,about TEXT NOT NULL,phone TEXT,website TEXT,open_h INTEGER,close_h INTEGER,days TEXT,status TEXT NOT NULL DEFAULT 'pending',verified INTEGER DEFAULT 0,owner_id INTEGER REFERENCES users(id),is_sample INTEGER DEFAULT 0,created TEXT DEFAULT CURRENT_TIMESTAMP,updated TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS claims(id INTEGER PRIMARY KEY,business_id INTEGER NOT NULL REFERENCES businesses(id),user_id INTEGER NOT NULL REFERENCES users(id),note TEXT,status TEXT NOT NULL DEFAULT 'pending',created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS favorites(user_id INTEGER NOT NULL,business_id INTEGER NOT NULL,PRIMARY KEY(user_id,business_id));
CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY,business_id INTEGER NOT NULL,type TEXT NOT NULL,created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,user_id INTEGER,action TEXT,target TEXT,created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS ix_b ON businesses(status,category,district);CREATE INDEX IF NOT EXISTS ix_e ON events(business_id,type,created);`);
const q1 = (s, ...a) => db.prepare(s).get(...a), qa = (s, ...a) => db.prepare(s).all(...a), run = (s, ...a) => db.prepare(s).run(...a);

// ---- helpers
class E extends Error { constructor(c, m, x) { super(m); this.c = c; this.x = x } }
const need = (c, m) => { if (!c) throw new E(400, m) };
const KINDS = ['Business', 'Company', 'Brand'], CATS = ['Food', 'Beauty', 'Shopping', 'Fitness', 'Entertainment', 'Experiences'];
const h = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const slugify = s => s.toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 60) || 'listing';
const uniqueSlug = n => { const b = slugify(n); let s = b, i = 1; while (q1('SELECT 1 FROM businesses WHERE slug=?', s)) s = b + '-' + ++i; return s };
const log = (u, a, t) => run('INSERT INTO audit(user_id,action,target) VALUES(?,?,?)', u?.id ?? null, a, String(t));
function isOpen(b) {
  if (b.open_h == null) return null;
  const p = new Intl.DateTimeFormat('en-US', { timeZone: 'Africa/Kigali', weekday: 'short', hour: 'numeric', hour12: false }).formatToParts(new Date());
  const d = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].indexOf(p.find(x => x.type == 'weekday').value), hr = +p.find(x => x.type == 'hour').value % 24;
  return (b.days || '0123456').includes(d) && hr >= b.open_h && hr < b.close_h;
}
const pub = b => ({ slug: b.slug, name: b.name, kind: b.kind, category: b.category, district: b.district, neighborhood: b.neighborhood, about: b.about, phone: b.phone, website: b.website, verified: !!b.verified, sample: !!b.is_sample, open: isOpen(b), hours: b.open_h == null ? null : { open: b.open_h, close: b.close_h, days: b.days }, updated: b.updated });

// ---- auth (scrypt passwords, HMAC-signed 7-day tokens)
const hashPw = pw => { const s = crypto.randomBytes(16); return s.toString('hex') + ':' + crypto.scryptSync(pw, s, 64).toString('hex') };
const checkPw = (pw, st) => { const [s, k] = st.split(':'), c = crypto.scryptSync(pw, Buffer.from(s, 'hex'), 64); return crypto.timingSafeEqual(c, Buffer.from(k, 'hex')) };
const mac = d => crypto.createHmac('sha256', SECRET).update(d).digest('base64url');
const sign = p => { const d = Buffer.from(JSON.stringify({ ...p, exp: Date.now() + 7 * 864e5 })).toString('base64url'); return d + '.' + mac(d) };
function verify(t) { try { const [d, s] = t.split('.'); if (!crypto.timingSafeEqual(Buffer.from(s), Buffer.from(mac(d)))) return null; const p = JSON.parse(Buffer.from(d, 'base64url')); return p.exp > Date.now() ? p : null } catch { return null } }
const auth = (c, role) => { if (!c.user) throw new E(401, 'login required'); if (role && c.user.role != role) throw new E(403, 'forbidden'); return c.user };
const hits = new Map();
function limit(ip, key, max) { const k = ip + key, n = Date.now(), r = hits.get(k); if (!r || r[1] < n) { hits.set(k, [1, n + 6e4]); return } if (++r[0] > max) throw new E(429, 'too many requests, slow down') }
setInterval(() => { const n = Date.now(); for (const [k, v] of hits) if (v[1] < n) hits.delete(k) }, 6e4).unref();

// ---- validation
function clean(b, partial) {
  const o = {}; for (const k of ['name', 'about', 'district', 'neighborhood', 'phone', 'website', 'kind', 'category']) if (b[k] !== undefined) o[k] = String(b[k]).trim();
  if (!partial) { need(o.name?.length >= 2 && o.name.length <= 120, 'name must be 2–120 characters'); need(KINDS.includes(o.kind), 'kind must be one of ' + KINDS); need(CATS.includes(o.category), 'category must be one of ' + CATS); need(o.about?.length >= 20 && o.about.length <= 2000, 'about must be 20–2000 characters') }
  if (o.kind) need(KINDS.includes(o.kind), 'invalid kind'); if (o.category) need(CATS.includes(o.category), 'invalid category');
  if (o.website) need(/^https?:\/\/[^\s]+$/.test(o.website), 'website must start with http:// or https://');
  if (o.phone) need(/^\+?[0-9 ]{7,16}$/.test(o.phone), 'invalid phone number');
  if (b.open_h !== undefined) { const a = +b.open_h, c = +b.close_h; need(Number.isInteger(a) && Number.isInteger(c) && a >= 0 && c <= 24 && a < c, 'open_h/close_h must be integers 0–24 with open before close'); o.open_h = a; o.close_h = c; if (b.days) { need(/^[0-6]{1,7}$/.test(b.days), 'days must be digits 0–6 (0=Sun)'); o.days = b.days } }
  return o;
}

// ---- routes
const routes = []; const r = (m, p, fn) => routes.push({ m, re: new RegExp('^' + p.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), fn });
const bySlug = s => { const b = q1('SELECT * FROM businesses WHERE slug=?', s); if (!b) throw new E(404, 'not found'); return b };
const own = (c, b) => { if (!(c.user.role == 'admin' || b.owner_id == c.user.id)) throw new E(403, 'you do not manage this listing') };

r('POST', '/api/register', c => { limit(c.ip, 'auth', 10); const { email, name, password } = c.body; need(/^\S+@\S+\.\S+$/.test(email || ''), 'valid email required'); need(String(name || '').trim().length >= 2, 'name required'); need(String(password || '').length >= 8, 'password must be at least 8 characters');
  try { const i = run('INSERT INTO users(email,name,pw) VALUES(?,?,?)', email.toLowerCase(), name.trim(), hashPw(password)).lastInsertRowid; const u = { id: Number(i), role: 'user' }; return [201, { token: sign(u), user: { id: u.id, name: name.trim(), email: email.toLowerCase(), role: 'user' } }] } catch { throw new E(409, 'email already registered') } });
r('POST', '/api/login', c => { limit(c.ip, 'auth', 10); const u = q1('SELECT * FROM users WHERE email=?', String(c.body.email || '').toLowerCase()); if (!u || !checkPw(String(c.body.password || ''), u.pw)) throw new E(401, 'wrong email or password'); return { token: sign({ id: u.id, role: u.role }), user: { id: u.id, name: u.name, email: u.email, role: u.role } } });

r('GET', '/api/businesses', c => {
  const p = c.url.searchParams, w = ["status='approved'"], a = [], f = (k, col) => { if (p.get(k)) { w.push(col + '=?'); a.push(p.get(k)) } };
  f('kind', 'kind'); f('category', 'category'); f('district', 'district'); if (p.get('verified') == '1') w.push('verified=1');
  const s = (p.get('q') || '').replace(/[%_]/g, '').trim(); if (s) { w.push('(name LIKE ? OR about LIKE ? OR category LIKE ? OR district LIKE ? OR neighborhood LIKE ?)'); a.push(...Array(5).fill('%' + s + '%')) }
  let L = qa(`SELECT * FROM businesses WHERE ${w.join(' AND ')} ORDER BY ${p.get('sort') == 'new' ? 'created DESC' : 'name COLLATE NOCASE'}`, ...a).map(pub);
  if (p.get('open') == '1') L = L.filter(b => b.open === true);
  const pg = Math.max(1, +p.get('page') || 1), n = 20; return { total: L.length, page: pg, items: L.slice((pg - 1) * n, pg * n) };
});
r('GET', '/api/businesses/:slug', c => { const b = bySlug(c.params.slug); if (b.status != 'approved' && !(c.user && (c.user.role == 'admin' || c.user.id == b.owner_id))) throw new E(404, 'not found'); return pub(b) });
r('POST', '/api/businesses', c => { const u = auth(c), o = clean(c.body);
  const d = qa("SELECT slug,name FROM businesses WHERE lower(name)=lower(?) AND coalesce(district,'')=coalesce(?,'')", o.name, o.district ?? ''); if (d.length && !c.body.confirm_not_duplicate) throw new E(409, 'possible duplicate listing: claim it instead, or resend with confirm_not_duplicate:true', { duplicates: d });
  const k = Object.keys(o), slug = uniqueSlug(o.name), st = u.role == 'admin' ? 'approved' : 'pending';
  run(`INSERT INTO businesses(slug,status,owner_id,${k})VALUES(?,?,?,${k.map(() => '?')})`, slug, st, u.id, ...k.map(x => o[x])); return [201, { slug, status: st }] });
r('PATCH', '/api/businesses/:slug', c => { auth(c); const b = bySlug(c.params.slug); own(c, b); const o = clean(c.body, true), k = Object.keys(o); need(k.length, 'nothing to update');
  run(`UPDATE businesses SET ${k.map(x => x + '=?')},updated=CURRENT_TIMESTAMP WHERE id=?`, ...k.map(x => o[x]), b.id); log(c.user, 'update', b.slug); return { ok: true } });
r('POST', '/api/businesses/:slug/claim', c => { const u = auth(c), b = bySlug(c.params.slug); if (b.owner_id == u.id) throw new E(400, 'you already manage this listing');
  if (q1("SELECT 1 FROM claims WHERE business_id=? AND user_id=? AND status='pending'", b.id, u.id)) throw new E(409, 'claim already pending');
  run('INSERT INTO claims(business_id,user_id,note) VALUES(?,?,?)', b.id, u.id, String(c.body.note || '').slice(0, 1000)); return [201, { status: 'pending' }] });
r('POST', '/api/businesses/:slug/events', c => { limit(c.ip, 'ev', 60); const t = c.body.type; need(['view', 'call', 'whatsapp', 'website', 'directions'].includes(t), 'invalid event type'); const b = bySlug(c.params.slug); if (b.status != 'approved') throw new E(404, 'not found'); run('INSERT INTO events(business_id,type) VALUES(?,?)', b.id, t); return [201, { ok: true }] });
r('PUT', '/api/favorites/:slug', c => { const u = auth(c), b = bySlug(c.params.slug); run('INSERT OR IGNORE INTO favorites VALUES(?,?)', u.id, b.id); return { saved: true } });
r('DELETE', '/api/favorites/:slug', c => { const u = auth(c), b = bySlug(c.params.slug); run('DELETE FROM favorites WHERE user_id=? AND business_id=?', u.id, b.id); return { saved: false } });
r('GET', '/api/me', c => { const u = auth(c); return { user: q1('SELECT id,name,email,role FROM users WHERE id=?', u.id), favorites: qa('SELECT b.* FROM favorites f JOIN businesses b ON b.id=f.business_id WHERE f.user_id=?', u.id).map(pub), listings: qa('SELECT slug,name,status FROM businesses WHERE owner_id=?', u.id) } });
r('GET', '/api/me/analytics', c => { const u = auth(c); return qa(`SELECT b.slug,b.name,e.type,COUNT(*) n FROM events e JOIN businesses b ON b.id=e.business_id WHERE (b.owner_id=? OR ?='admin') AND e.created>=datetime('now','-30 days') GROUP BY b.id,e.type`, u.id, u.role).reduce((m, x) => ((m[x.slug] ||= { name: x.name, last30days: {} }).last30days[x.type] = x.n, m), {}) });

// admin
r('GET', '/api/admin/queue', c => { auth(c, 'admin'); return { listings: qa("SELECT slug,name,kind,category,district,created FROM businesses WHERE status='pending'"), claims: qa("SELECT c.id,b.slug,b.name,u.email,c.note FROM claims c JOIN businesses b ON b.id=c.business_id JOIN users u ON u.id=c.user_id WHERE c.status='pending'") } });
r('POST', '/api/admin/businesses/:slug/:act', c => { auth(c, 'admin'); const b = bySlug(c.params.slug), a = c.params.act; need(['approve', 'reject', 'verify', 'unverify'].includes(a), 'unknown action');
  run(a == 'approve' || a == 'reject' ? 'UPDATE businesses SET status=? WHERE id=?' : 'UPDATE businesses SET verified=? WHERE id=?', ...(a == 'approve' ? ['approved'] : a == 'reject' ? ['rejected'] : [a == 'verify' ? 1 : 0]), b.id); log(c.user, a, b.slug); return { ok: true } });
r('POST', '/api/admin/claims/:id/:act', c => { auth(c, 'admin'); const cl = q1('SELECT * FROM claims WHERE id=?', c.params.id); if (!cl) throw new E(404, 'not found'); need(['approve', 'reject'].includes(c.params.act), 'unknown action'); const ok = c.params.act == 'approve';
  run('UPDATE claims SET status=? WHERE id=?', ok ? 'approved' : 'rejected', cl.id); if (ok) run('UPDATE businesses SET owner_id=? WHERE id=?', cl.user_id, cl.business_id); log(c.user, 'claim-' + c.params.act, cl.id); return { ok: true } });

// ---- server-rendered, crawlable pages (real URLs, titles, canonical, JSON-LD)
const page = (title, desc, canon, body, ld, robots = 'index,follow') => `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${h(title)}</title><meta name="description" content="${h(desc)}"><meta name="robots" content="${robots}"><link rel="canonical" href="${h(canon)}"><meta property="og:title" content="${h(title)}"><meta property="og:description" content="${h(desc)}"><meta property="og:url" content="${h(canon)}"><meta property="og:type" content="website"><meta name="twitter:card" content="summary">${ld ? `<script type="application/ld+json">${JSON.stringify(ld).replace(/</g, '\\u003c')}</script>` : ''}<style>body{font:17px/1.6 system-ui,sans-serif;max-width:720px;margin:40px auto;padding:0 20px;color:#1c1b18}a{color:#0f5a3c}dt{color:#6b675d;margin-top:12px}dd{margin:0}</style></head><body>${body}</body></html>`;
r('GET', '/b/:slug', c => { const b = q1("SELECT * FROM businesses WHERE slug=? AND status='approved'", c.params.slug); if (!b) return ['html404']; const u = `${BASE}/b/${b.slug}`, o = isOpen(b);
  const ld = { '@context': 'https://schema.org', '@type': b.kind == 'Business' ? 'LocalBusiness' : 'Organization', name: b.name, description: b.about, url: u, ...(b.website && { sameAs: [b.website] }), ...(b.phone && { telephone: b.phone }), ...(b.kind == 'Business' && { address: { '@type': 'PostalAddress', addressLocality: b.neighborhood || 'Kigali', addressRegion: b.district || undefined, addressCountry: 'RW' } }) };
  const body = `<nav><a href="/">Home</a> / <a href="/api/businesses?category=${encodeURIComponent(b.category)}">${h(b.category)}</a></nav><h1>${h(b.name)}</h1><p>${h(b.about)}</p><dl><dt>Type</dt><dd>${h(b.kind)} · ${h(b.category)}</dd><dt>Location</dt><dd>${h([b.neighborhood, b.district, 'Rwanda'].filter(Boolean).join(', '))}</dd>${o == null ? '' : `<dt>Status now</dt><dd>${o ? 'Open' : 'Closed'} (Kigali time)</dd>`}<dt>Verification</dt><dd>${b.verified ? 'Verified by inyungu' : 'Not verified'}</dd>${b.is_sample ? '<dt>Note</dt><dd>Sample listing for development.</dd>' : ''}</dl>`;
  return ['html', page(`${b.name} — ${b.category} in ${b.neighborhood || b.district || 'Rwanda'} | inyungu`, `${b.name}: ${b.about}`.slice(0, 155), u, body, ld)] });
r('GET', '/sitemap.xml', () => ['xml', `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${qa("SELECT slug,updated FROM businesses WHERE status='approved'").map(b => `<url><loc>${BASE}/b/${h(b.slug)}</loc><lastmod>${b.updated.slice(0, 10)}</lastmod></url>`).join('')}</urlset>`]);
r('GET', '/robots.txt', () => ['text', `User-agent: *\nAllow: /b/\nDisallow: /api/\nSitemap: ${BASE}/sitemap.xml\n`]);

// ---- http
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg' };
http.createServer(async (req, res) => {
  const ip = req.socket.remoteAddress, url = new URL(req.url, BASE), send = (code, type, body) => { res.writeHead(code, { 'Content-Type': type + '; charset=utf-8', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'strict-origin-when-cross-origin', 'Content-Security-Policy': "default-src 'self'; style-src 'unsafe-inline'" }); res.end(body) };
  try {
    limit(ip, 'g', 240); let body = {};
    if (['POST', 'PATCH', 'PUT'].includes(req.method)) { let s = '', n = 0; for await (const ch of req) { if ((n += ch.length) > 1e5) throw new E(413, 'body too large'); s += ch } try { body = s ? JSON.parse(s) : {} } catch { throw new E(400, 'invalid JSON') } }
    const t = (req.headers.authorization || '').replace(/^Bearer /, ''), user = t ? verify(t) : null;
    for (const x of routes) { if (x.m != req.method) continue; const m = x.re.exec(url.pathname); if (!m) continue;
      let out = x.fn({ ip, url, body, user, params: m.groups || {} }); if (!Array.isArray(out)) out = [200, out]; const [k, v] = out;
      if (k == 'html') return send(200, 'text/html', v); if (k == 'html404') return send(404, 'text/html', page('Not found | inyungu', 'Page not found', BASE, '<h1>Not found</h1><p><a href="/">Home</a></p>', null, 'noindex'));
      if (k == 'xml') return send(200, 'application/xml', v); if (k == 'text') return send(200, 'text/plain', v); return send(k, 'application/json', JSON.stringify(v)) }
    if (req.method == 'GET' && !url.pathname.startsWith('/api')) { const f = join('public', normalize(url.pathname == '/' ? '/index.html' : url.pathname)); if (!f.startsWith('public') || !existsSync(f) || !statSync(f).isFile()) throw new E(404, 'not found'); res.writeHead(200, { 'Content-Type': MIME[extname(f)] || 'application/octet-stream', 'X-Content-Type-Options': 'nosniff' }); return res.end(readFileSync(f)) }
    throw new E(404, 'not found');
  } catch (e) { if (!(e instanceof E)) console.error(e); send(e.c || 500, 'application/json', JSON.stringify({ error: e.c ? e.message : 'server error', ...e.x })) }
}).listen(PORT, () => console.log('inyungu API on ' + BASE));

// ---- seed: node server.js --seed  (admin + SAMPLE listings, flagged is_sample)
if (process.argv.includes('--seed')) {
  const em = (process.env.ADMIN_EMAIL || 'admin@example.com').toLowerCase(), pw = process.env.ADMIN_PASSWORD || (console.warn('ADMIN_PASSWORD not set: using "change-me-now"'), 'change-me-now');
  if (!q1('SELECT 1 FROM users WHERE email=?', em)) run("INSERT INTO users(email,name,pw,role) VALUES(?,?,?, 'admin')", em, 'Admin', hashPw(pw));
  const S = [['Sample Bistro', 'Business', 'Food', 'Gasabo', 'Kimihurura', 'A neighbourhood restaurant serving set lunches, with dine-in service.', 7, 22, '123456', 1], ['Sample Spa', 'Business', 'Beauty', 'Gasabo', 'Nyarutarama', 'Massage and wellness treatments in a quiet setting.', 9, 20, '123456', 1], ['Sample Market', 'Business', 'Shopping', 'Kicukiro', 'Kicukiro', 'Groceries and household goods for the neighbourhood.', 8, 20, '0123456', 1], ['Sample Gym', 'Business', 'Fitness', 'Gasabo', 'Kacyiru', 'A gym floor with group classes and monthly passes.', 5, 21, '123456', 1], ['Sample Bank', 'Company', 'Shopping', null, 'Kigali', 'A retail bank offering cardholder benefits to its customers.', null, null, null, 1], ['Sample Coffee Roasters', 'Brand', 'Food', null, 'Kigali', 'A local coffee brand sold in shops and cafés around Kigali.', null, null, null, 0]];
  for (const s of S) if (!q1('SELECT 1 FROM businesses WHERE name=?', s[0])) run("INSERT INTO businesses(slug,name,kind,category,district,neighborhood,about,open_h,close_h,days,verified,status,is_sample)VALUES(?,?,?,?,?,?,?,?,?,?,?, 'approved',1)", uniqueSlug(s[0]), ...s);
  console.log('seeded');
}
