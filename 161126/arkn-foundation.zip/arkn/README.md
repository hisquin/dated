# ARKON SCHOOL — Next.js foundation (P0 + P2 seed)

Frontend only. All data is SAMPLE mock data. No backend, auth or persistence exists.

## Verified vs unverified
- VERIFIED (ran here): `npm test` — 9 domain tests (status workflow, admissions/enrolment rules, permissions).
- UNVERIFIED (no network here): `npm install`, `next build`, `tsc`, ESLint, any browser rendering. Run them first and fix what they report.

## Setup
    git checkout -b migrate/next-foundation
    # copy these files in, then:
    npm install next react react-dom
    npm install -D typescript @types/react @types/node @types/react-dom
    npm test && npm run typecheck && npm run build && npm run dev

## Structure
- `src/domain` pure rules and models (tested). `src/services` interfaces. `src/data/mock` sample data.
- `src/lib/site.ts` the one place the domain lives (`NEXT_PUBLIC_SITE_URL`).
- Public pages are Server Components with metadata, JSON-LD, sitemap and robots.

## Not yet migrated from the Artifact
Cohorts pages, apply wizard, auth pages, student/teacher/admin dashboards, curriculum tools, lesson player, classroom UI. See the roadmap.
