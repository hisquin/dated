import { test } from "node:test";
import assert from "node:assert/strict";
import { canTransition, transition, nextStatuses } from "./application-status.ts";
import { canApply, canEnrol } from "./admissions.ts";
import { can, studentCanViewLesson, teacherCanManageCohort } from "./permissions.ts";
import type { Application, Cohort, Course, Enrolment } from "./models.ts";
const course = (o: Partial<Course> = {}): Course => ({ id: "pd", slug: "pd", title: "PD", summary: "", published: true, archived: false, mode: "selective", outcomes: [], ...o });
const cohort = (o: Partial<Cohort> = {}): Cohort => ({ id: "c1", courseId: "pd", name: "C1", status: "Open", capacity: 2, enrolled: 0, deadline: "2026-12-01", ...o });
const app = (o: Partial<Application> = {}): Application => ({ id: "a1", ref: "ARK-1", applicantEmail: "a@x.com", courseId: "pd", cohortId: "c1", status: "Submitted", history: [], ...o });
const T = "2026-11-13";
const why = (c: { ok: boolean }) => (c.ok ? "ok" : (c as { reason: string }).reason);
test("status workflow: only legal moves", () => {
  assert.ok(canTransition("Submitted", "Under review") && canTransition("Under review", "Interview") && canTransition("Interview", "Accepted"));
  assert.ok(!canTransition("Submitted", "Accepted"), "cannot skip review");
  assert.ok(!canTransition("Under review", "Enrolled"), "cannot enrol without acceptance");
  assert.ok(!canTransition("Declined", "Accepted") && nextStatuses("Enrolled").length === 0, "terminal states");
  assert.deepEqual(nextStatuses("Accepted"), ["Enrolled"], "acceptance is not enrolment");
});
test("transition records history and rejects illegal moves", () => {
  const n = transition(app({ status: "Under review" }), "Accepted", T);
  assert.equal(n.status, "Accepted"); assert.equal(n.history.at(-1)?.at, T);
  assert.throws(() => transition(app(), "Enrolled", T), /Illegal/);
});
test("apply: course and cohort gates", () => {
  assert.equal(why(canApply(course(), cohort(), T, [], "a@x.com")), "ok");
  assert.equal(why(canApply(course({ published: false }), cohort(), T, [], "a@x.com")), "course-unpublished");
  assert.equal(why(canApply(course({ archived: true }), cohort(), T, [], "a@x.com")), "course-archived");
  assert.equal(why(canApply(course(), undefined, T, [], "a@x.com")), "cohort-not-found");
  assert.equal(why(canApply(course(), cohort({ courseId: "other" }), T, [], "a@x.com")), "wrong-course");
  assert.equal(why(canApply(course(), cohort({ status: "Closed" }), T, [], "a@x.com")), "cohort-closed");
  assert.equal(why(canApply(course(), cohort({ deadline: "2026-11-01" }), T, [], "a@x.com")), "deadline-passed");
  assert.equal(why(canApply(course(), cohort({ enrolled: 2 }), T, [], "a@x.com")), "cohort-full");
});
test("apply: duplicates (case-insensitive) blocked, declined can reapply", () => {
  assert.equal(why(canApply(course(), cohort(), T, [app()], "A@X.com")), "duplicate");
  assert.equal(why(canApply(course(), cohort(), T, [app({ status: "Declined" })], "a@x.com")), "ok");
});
test("enrol: selective needs Accepted for the same cohort", () => {
  assert.equal(why(canEnrol(course(), cohort(), T, undefined, [], "s1")), "admission-required");
  assert.equal(why(canEnrol(course(), cohort(), T, app({ status: "Under review" }), [], "s1")), "admission-required");
  assert.equal(why(canEnrol(course(), cohort(), T, app({ status: "Accepted", cohortId: "c2" }), [], "s1")), "admission-required");
  assert.equal(why(canEnrol(course(), cohort(), T, app({ status: "Accepted" }), [], "s1")), "ok");
});
test("enrol: accepted students still enrol after the application deadline", () => {
  assert.equal(why(canEnrol(course(), cohort({ deadline: "2026-11-01", status: "Closed" }), T, app({ status: "Accepted" }), [], "s1")), "ok");
});
test("enrol: open courses enrol directly but respect the window; capacity and duplicates always", () => {
  assert.equal(why(canEnrol(course({ mode: "open" }), cohort(), T, undefined, [], "s1")), "ok");
  assert.equal(why(canEnrol(course({ mode: "open" }), cohort({ status: "Closed" }), T, undefined, [], "s1")), "cohort-closed");
  assert.equal(why(canEnrol(course(), cohort({ enrolled: 2 }), T, app({ status: "Accepted" }), [], "s1")), "cohort-full");
  const e: Enrolment = { id: "e", studentId: "s1", courseId: "pd", cohortId: "c1", createdAt: T };
  assert.equal(why(canEnrol(course(), cohort(), T, app({ status: "Accepted" }), [e], "s1")), "duplicate");
  assert.equal(why(canEnrol(course({ published: false, mode: "open" }), cohort(), T, undefined, [], "s1")), "course-unpublished");
});
test("permissions: roles are separate and nobody can change roles from the client", () => {
  assert.ok(can("student", "application:create") && !can("student", "lesson:author") && !can("student", "teacher:invite"));
  assert.ok(can("teacher", "submission:grade") && !can("teacher", "course:manage") && !can("teacher", "application:decide"));
  assert.ok(can("admin", "teacher:invite") && can("admin", "application:decide") && !can("admin", "submission:create"));
  for (const r of ["student", "teacher", "admin"] as const) assert.ok(!can(r, "user:change-role"));
});
test("scoped access: students only enrolled cohorts, teachers only assigned cohorts", () => {
  assert.ok(studentCanViewLesson(["c1"], "c1") && !studentCanViewLesson(["c1"], "c2") && !studentCanViewLesson([], "c1"));
  assert.ok(teacherCanManageCohort("t1", { teacherId: "t1" }) && !teacherCanManageCohort("t1", { teacherId: "t2" }) && !teacherCanManageCohort("t1", {}));
});
