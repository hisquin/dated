import type { Application, Cohort, Course, Enrolment } from "./models.ts";
export type Reason = "course-unpublished" | "course-archived" | "cohort-not-found" | "wrong-course" | "cohort-closed" | "deadline-passed" | "cohort-full" | "duplicate" | "admission-required";
export type Check = { ok: true } | { ok: false; reason: Reason };
const no = (reason: Reason): Check => ({ ok: false, reason });
const yes: Check = { ok: true };
const cohortOpen = (c: Cohort, today: string): Check =>
  c.status !== "Open" ? no("cohort-closed") : c.deadline && c.deadline < today ? no("deadline-passed") : c.enrolled >= c.capacity ? no("cohort-full") : yes;
const courseOk = (course: Course): Check => (course.archived ? no("course-archived") : !course.published ? no("course-unpublished") : yes);
/** May this email apply to this cohort? `today` is YYYY-MM-DD. A server must re-run this inside a transaction later. */
export function canApply(course: Course, cohort: Cohort | undefined, today: string, existing: Application[], email: string): Check {
  const c = courseOk(course); if (!c.ok) return c;
  if (!cohort) return no("cohort-not-found");
  if (cohort.courseId !== course.id) return no("wrong-course");
  const o = cohortOpen(cohort, today); if (!o.ok) return o;
  const dup = existing.some((a) => a.cohortId === cohort.id && a.applicantEmail.toLowerCase() === email.toLowerCase() && a.status !== "Declined");
  return dup ? no("duplicate") : yes;
}
/** May this student be enrolled? Selective courses need an Accepted application for the same cohort. */
export function canEnrol(course: Course, cohort: Cohort | undefined, today: string, application: Application | undefined, enrolments: Enrolment[], studentId: string): Check {
  const c = courseOk(course); if (!c.ok) return c;
  if (!cohort) return no("cohort-not-found");
  if (cohort.courseId !== course.id) return no("wrong-course");
  if (enrolments.some((e) => e.studentId === studentId && e.cohortId === cohort.id)) return no("duplicate");
  if (cohort.status === "Archived") return no("cohort-closed");
  if (cohort.enrolled >= cohort.capacity) return no("cohort-full");
  if (course.mode === "selective") return application && application.cohortId === cohort.id && application.status === "Accepted" ? yes : no("admission-required");
  return cohortOpen(cohort, today); // open enrolment: registration window rules apply
}
