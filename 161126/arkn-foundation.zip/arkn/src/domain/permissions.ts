import type { Role } from "./models.ts";
export type Action = "application:create" | "teacher:invite" | "course:manage" | "cohort:manage" | "application:decide" | "enrolment:manage" | "lesson:author" | "lesson:view" | "submission:create" | "submission:grade" | "user:change-role";
const GRANTS: Record<Role, Action[]> = {
  student: ["application:create", "lesson:view", "submission:create"],
  teacher: ["lesson:author", "lesson:view", "submission:grade"],
  admin: ["teacher:invite", "course:manage", "cohort:manage", "application:decide", "enrolment:manage", "lesson:author", "lesson:view"],
};
// "user:change-role" is granted to nobody: roles change only through trusted server processes.
export const can = (role: Role, action: Action): boolean => GRANTS[role].includes(action);
export const studentCanViewLesson = (enrolledCohortIds: string[], lessonCohortId: string): boolean => enrolledCohortIds.includes(lessonCohortId);
export const teacherCanManageCohort = (teacherId: string, cohort: { teacherId?: string }): boolean => cohort.teacherId === teacherId;
