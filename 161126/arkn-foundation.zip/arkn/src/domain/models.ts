// Backend-agnostic domain models. Services return these; the UI never sees storage details.
export type Role = "student" | "teacher" | "admin";
export type ApplicationStatus = "Draft" | "Submitted" | "Under review" | "Interview" | "Accepted" | "Waitlisted" | "Declined" | "Enrolled";
export type CohortStatus = "Open" | "Coming soon" | "Full" | "Closed" | "Archived";
export type EnrolmentMode = "selective" | "open";
export interface Course { id: string; slug: string; title: string; summary: string; published: boolean; archived: boolean; mode: EnrolmentMode; outcomes: string[]; duration?: string; format?: string; priceRwf?: number; prerequisites?: string }
export interface Cohort { id: string; courseId: string; name: string; status: CohortStatus; capacity: number; enrolled: number; start?: string; end?: string; deadline?: string; schedule?: string; format?: string; teacherId?: string }
export interface Application { id: string; ref: string; applicantEmail: string; courseId: string; cohortId: string; status: ApplicationStatus; history: { status: ApplicationStatus; at: string }[] }
export interface Enrolment { id: string; studentId: string; courseId: string; cohortId: string; createdAt: string }
