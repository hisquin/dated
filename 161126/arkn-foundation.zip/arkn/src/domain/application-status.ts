import type { Application, ApplicationStatus } from "./models.ts";
// Acceptance is NOT enrolment: Enrolled is reachable only from Accepted.
export const TRANSITIONS: Record<ApplicationStatus, ApplicationStatus[]> = {
  Draft: ["Submitted"],
  Submitted: ["Under review"],
  "Under review": ["Interview", "Accepted", "Waitlisted", "Declined"],
  Interview: ["Accepted", "Waitlisted", "Declined"],
  Waitlisted: ["Accepted", "Declined"],
  Accepted: ["Enrolled"],
  Declined: [],
  Enrolled: [],
};
export const nextStatuses = (s: ApplicationStatus): ApplicationStatus[] => TRANSITIONS[s];
export const canTransition = (from: ApplicationStatus, to: ApplicationStatus): boolean => TRANSITIONS[from].includes(to);
export function transition(app: Application, to: ApplicationStatus, at: string): Application {
  if (!canTransition(app.status, to)) throw new Error(`Illegal transition ${app.status} -> ${to}`);
  return { ...app, status: to, history: [...app.history, { status: to, at }] };
}
