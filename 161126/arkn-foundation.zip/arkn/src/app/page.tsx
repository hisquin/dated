import Link from "next/link";
export default function Home() {
  return (<section style={{ padding: "48px 0" }}><h1 style={{ fontSize: "clamp(2.4rem,7vw,4.5rem)" }}>Join a cohort.<br />Build products that <span className="redline">work.</span></h1>
    <p style={{ color: "var(--muted)", maxWidth: "36em" }}>Small, mentored cohorts for designers and builders in Kigali.</p><Link href="/courses">Explore courses →</Link></section>);
}
