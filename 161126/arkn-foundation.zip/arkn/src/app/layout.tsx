import type { Metadata } from "next";
import { Fraunces, Instrument_Sans } from "next/font/google";
import Link from "next/link";
import "./globals.css";
import { SITE, SITE_URL } from "@/lib/site";
import { organizationLd } from "@/lib/jsonld";
import { SAMPLE } from "@/data/mock/catalog";
const display = Fraunces({ subsets: ["latin"], variable: "--font-display" });
const sans = Instrument_Sans({ subsets: ["latin"], variable: "--font-sans" });
export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: { default: `${SITE.name} — product design & development in Kigali`, template: `%s · ${SITE.name}` },
  description: SITE.description,
  openGraph: { siteName: SITE.name, type: "website", url: SITE_URL },
  alternates: { canonical: "/" },
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${display.variable} ${sans.variable}`}>
      <body>
        {SAMPLE && <div className="sample">Sample data — dates and capacities are placeholders</div>}
        <header className="wrap" style={{ display: "flex", gap: 20, padding: "16px 20px", alignItems: "center" }}>
          <Link href="/" style={{ fontWeight: 700, textDecoration: "none" }}>ARKON/SCHOOL</Link>
          <nav aria-label="Main" style={{ display: "flex", gap: 16 }}><Link href="/courses">Courses</Link><Link href="/cohorts">Cohorts</Link></nav>
        </header>
        <main className="wrap">{children}</main>
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationLd()).replace(/</g, "\\u003c") }} />
      </body>
    </html>
  );
}
