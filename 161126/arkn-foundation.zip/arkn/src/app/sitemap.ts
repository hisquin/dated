import type { MetadataRoute } from "next";
import { catalog } from "@/services";
import { abs } from "@/lib/site";
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const courses = await catalog.listCourses();
  return [{ url: abs("/") }, { url: abs("/courses") }, ...courses.map((c) => ({ url: abs(`/courses/${c.slug}`) }))];
}
