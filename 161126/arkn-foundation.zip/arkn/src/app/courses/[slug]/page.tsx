import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { catalog } from "@/services";
import { breadcrumbLd, courseLd } from "@/lib/jsonld";
type P = { params: Promise<{ slug: string }> };
export async function generateStaticParams() { return (await catalog.listCourses()).map((c) => ({ slug: c.slug })); }
export async function generateMetadata({ params }: P): Promise<Metadata> {
  const c = await catalog.getCourse((await params).slug);
  return c ? { title: c.title, description: c.summary, alternates: { canonical: `/courses/${c.slug}` }, openGraph: { title: c.title, description: c.summary } } : {};
}
const ld = (o: object) => <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(o).replace(/</g, "\\u003c") }} />;
export default async function CoursePage({ params }: P) {
  const c = await catalog.getCourse((await params).slug); if (!c) notFound();
  const cohorts = await catalog.listCohorts(c.id);
  return (<article><h1>{c.title}</h1><p>{c.summary}</p><h2>What you will learn</h2><ul>{c.outcomes.map((o) => <li key={o}>{o}</li>)}</ul>
    <h2>Cohorts</h2>{cohorts.length ? <ul>{cohorts.map((h) => <li key={h.id}>{h.name} — {h.status}{h.start ? `, starts ${h.start}` : ""}</li>)}</ul> : <p>No cohorts announced yet.</p>}
    {ld(courseLd(c, cohorts))}{ld(breadcrumbLd([{ name: "Home", path: "/" }, { name: "Courses", path: "/courses" }, { name: c.title, path: `/courses/${c.slug}` }]))}</article>);
}
