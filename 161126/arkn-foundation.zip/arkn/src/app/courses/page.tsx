import type { Metadata } from "next";
import Link from "next/link";
import { catalog } from "@/services";
export const metadata: Metadata = { title: "Courses", description: "Product design and product development programmes at ARKON SCHOOL.", alternates: { canonical: "/courses" } };
export default async function Courses() {
  const courses = await catalog.listCourses();
  return (<section><h1>Courses</h1>{courses.map((c) => (<article key={c.id}><h2><Link href={`/courses/${c.slug}`}>{c.title}</Link></h2><p>{c.summary}</p></article>))}</section>);
}
