import type { MetadataRoute } from "next";
import { abs } from "@/lib/site";
export default function robots(): MetadataRoute.Robots {
  return { rules: [{ userAgent: "*", allow: "/", disallow: ["/student", "/teacher", "/admin", "/classroom", "/sign-in", "/sign-up", "/verify-email", "/forgot-password", "/reset-password", "/accept-invitation"] }], sitemap: abs("/sitemap.xml") };
}
