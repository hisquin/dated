// Single source of truth for the domain. Switching to arkonschool.com = set NEXT_PUBLIC_SITE_URL, nothing else.
export const SITE_URL = (process.env.NEXT_PUBLIC_SITE_URL ?? "https://arkonschool.vercel.app").replace(/\/$/, "");
export const SITE = { name: "ARKON SCHOOL", parent: "ArkonMade", city: "Kigali", country: "RW", description: "Cohort-based product design and product development training by ArkonMade, a product studio in Rwanda." } as const;
export const abs = (path = "/") => `${SITE_URL}${path}`;
