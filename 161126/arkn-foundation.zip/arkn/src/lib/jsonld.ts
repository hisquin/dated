import type { Cohort, Course } from "@/domain/models";
import { SITE, abs } from "./site";
// Structured data may only describe facts that are visible on the same page. No prices, ratings or accreditation are emitted.
export const organizationLd = () => ({ "@context": "https://schema.org", "@type": "EducationalOrganization", name: SITE.name, url: abs("/"), description: SITE.description, parentOrganization: { "@type": "Organization", name: SITE.parent }, address: { "@type": "PostalAddress", addressLocality: SITE.city, addressCountry: SITE.country } });
export const breadcrumbLd = (items: { name: string; path: string }[]) => ({ "@context": "https://schema.org", "@type": "BreadcrumbList", itemListElement: items.map((it, i) => ({ "@type": "ListItem", position: i + 1, name: it.name, item: abs(it.path) })) });
export const courseLd = (c: Course, cohorts: Cohort[]) => ({ "@context": "https://schema.org", "@type": "Course", name: c.title, description: c.summary, url: abs(`/courses/${c.slug}`), provider: { "@type": "EducationalOrganization", name: SITE.name, url: abs("/") },
  ...(c.outcomes.length ? { teaches: c.outcomes } : {}),
  ...(cohorts.some((h) => h.start) ? { hasCourseInstance: cohorts.filter((h) => h.start).map((h) => ({ "@type": "CourseInstance", name: h.name, startDate: h.start, ...(h.end ? { endDate: h.end } : {}), ...(h.format ? { courseMode: h.format } : {}) })) } : {}) });
