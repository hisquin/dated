import type { Cohort, Course } from "@/domain/models";
// SAMPLE DATA. Dates, capacities and durations are placeholders until the school confirms real values.
export const SAMPLE = true;
export const courses: Course[] = [
  { id: "product-design", slug: "product-design", title: "Product Design (UI/UX)", summary: "Research, design and test digital products people can actually use.", published: true, archived: false, mode: "selective", outcomes: ["User experience and interface design", "Product thinking and discovery", "User research", "Wireframing and prototyping", "Design systems", "Usability testing"] },
  { id: "product-development", slug: "product-development", title: "Product Development", summary: "Build, test and ship working digital products, from frontend to AI integration.", published: true, archived: false, mode: "selective", outcomes: ["Software engineering: frontend and backend", "No-code and low-code development", "AI implementation and integration", "Testing and deployment"] },
];
export const cohorts: Cohort[] = [
  { id: "pd-c03", courseId: "product-design", name: "Design · Cohort 03", status: "Open", capacity: 30, enrolled: 18, start: "2026-12-07", end: "2027-03-01", deadline: "2026-11-30", schedule: "Mon & Wed, 6–8pm", format: "Hybrid" },
  { id: "pdv-c02", courseId: "product-development", name: "Development · Cohort 02", status: "Open", capacity: 25, enrolled: 9, start: "2026-12-14", end: "2027-04-05", deadline: "2026-12-05", schedule: "Tue & Thu, 6–8:30pm", format: "On-site" },
  { id: "pd-c04", courseId: "product-design", name: "Design · Cohort 04", status: "Coming soon", capacity: 30, enrolled: 0, start: "2027-02-02", schedule: "Tue & Thu, 6–8pm", format: "Online" },
];
