# Data schema
Content: `regions`, `countries` (ISO alpha-2, region, capital, languages, status), `categories` and `subcategories` (slug, order, active), `question_types` (add a row to register a type), `questions`, `question_options`, `accepted_answers`, `question_countries` (many to many, so a question can belong to several countries), `question_sources`, `sources`, `media_assets` (metadata only; files live in Storage), `question_revisions` (snapshot of the previous row on every change).
Questions carry a stable human code such as `RW-HIS-0001`, a `scope` of `country` or `africa`, and a status of draft, pending_review, reviewed, published or archived. Type-specific data: MC and true/false use options with `is_correct`; ordering uses options where `position` is the correct order; matching uses `label` and `match_label`; typed answers use `accepted_answers` plus `validation` JSONB; maps use `geo` JSONB.
Players and admin: `profiles`, `game_sessions`, `game_answers`, `admin_users`, `admin_activity_log`. Achievements and player statistics tables are not yet created.

## Who can do what (enforced by RLS and triggers)
| Role | Rights |
|---|---|
| anonymous | read published content; insert guest game sessions |
| reviewer | read everything; change question status only |
| editor | create and edit drafts and pending questions, sources and media; cannot publish |
| admin | all content operations including publish and delete |
| super_admin | admin plus managing `admin_users` |
Publishing requires an explanation and at least one source. Editors cannot touch published questions.
