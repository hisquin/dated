# Connecting Dogoma to Supabase

What the migration files do: create all tables, enums, indexes, helper functions, workflow triggers, RLS policies, the `question-media` bucket and its storage policies, and the Rwanda seed content. What you do in the dashboard: create the project, set Auth options, create the first admin, and copy the keys.

1. **Account and project.** Sign up at supabase.com, create an organization and a new project. Save the database password in a password manager.
2. **Keys.** Dashboard → Project Settings → API. Copy the Project URL and the `anon` (publishable) key. The `service_role` key must never go in the browser or in a `VITE_` variable.
3. **Environment.** Copy `.env.example` to `.env.local` and fill in `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.
4. **Client dependency.** In the app project run `npm install @supabase/supabase-js`.
5. **Run migrations (CLI route).** `npm i -g supabase`, then `supabase login`, `supabase link --project-ref YOUR-PROJECT-REF`, `supabase db push`. Files run in order: `..._schema.sql`, `..._storage.sql`, `..._seed_rwanda.sql`. **Dashboard route:** paste each file into SQL Editor in that order and run it.
6. **Schema.** Created by `20260101000100_schema.sql`. It only creates missing objects and never drops data.
7. **RLS.** Enabled on every table in the same file. Anonymous users can only read published questions, active categories, published countries, sources and media rows, and insert guest game sessions. Writes are limited by role (see `docs/DATA_SCHEMA.md`).
8. **Storage bucket.** Created by `..._storage.sql` (`question-media`, public read by URL). Check it in Storage.
9. **Storage policies.** Also in `..._storage.sql`: editors and admins upload, admins delete.
10. **Authentication.** Dashboard → Authentication → Providers: enable Email. For a closed admin team, turn off "Allow new users to sign up" after creating your admins, and set the Site URL and redirect URLs to your deployed domain.
11. **First administrator.** Authentication → Users → Add user (email and password, auto-confirm). Copy the user's UUID.
12. **Assign the role.** In SQL Editor (runs as postgres): `insert into public.admin_users(user_id, role) values ('THE-UUID','super_admin');` Roles: `super_admin`, `admin`, `editor`, `reviewer`. Later role changes are made by a super admin through RLS-protected writes to `admin_users`.
13. **Seed content.** Included in step 5. The 19 starter questions are seeded as `pending_review` because they have not been editorially checked against their sources.
14. **Publish for testing.** After a human has reviewed them: `update public.questions set status='published' where status='pending_review';` (the trigger requires each question to have at least one source). Then check public retrieval: `GET {URL}/rest/v1/questions?select=code,prompt,question_options(*),accepted_answers(*),question_sources(sources(*)),question_countries(countries(iso_code))&status=eq.published` with the anon key as `apikey` and `Authorization: Bearer`.
15. **Admin create and publish.** Sign in as the admin and insert a draft question through the app (or SQL), add a source, then update its status to `published`. Inserting directly as `published` is rejected by design.
16. **Guest gameplay.** The player app must work with no sign-in; guests only need read access plus optional session inserts.
17. **Access tests.** Run `supabase/tests/rls_checks.sql` in the SQL editor and compare each result with its comment. Also test with each role: an editor cannot publish, a reviewer cannot change question text, only a super admin can edit `admin_users`.
18. **Deploy.** Any static host (Vercel, Netlify, Cloudflare Pages). Set the two `VITE_` variables in the host's settings.
19. **Troubleshooting.** `permission denied` or empty results as admin: the user has no `admin_users` row. `new row violates row-level security`: the signed-in role cannot write that table. "Add at least one source before publishing": add a `question_sources` row first. `type "..." already exists` or `relation already exists`: the migration was partly run before; it is safe to re-run. 401 from the REST API: wrong or missing anon key.

Known limit: the anon key can read answer data for published questions, so a determined player can inspect correct answers. Server-side answer checking is a future RPC.

## Country expansion and PWA (added)
Migrations `..._country_expansion.sql` and `..._seed_rwanda_divisions.sql` add languages, flags and imagery, translations, per-country administrative levels and divisions, and `playable_topics(country, include_continental)`. To add a country: insert its `countries` row (`status='published'` when ready), its `administrative_levels`, then questions linked through `question_countries`. The `pwa/` folder holds `manifest.webmanifest`, `sw.js`, `offline.html` and icons; copy them into the app's `public/` folder and register `sw.js` at startup. The service worker caches the app shell only; offline question storage and score syncing belong in the app layer and are not built.
