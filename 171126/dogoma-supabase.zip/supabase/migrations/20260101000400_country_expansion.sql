-- Country expansion: global scope, flags and imagery, per-country administrative structure, translations, topic discovery.
alter table public.questions drop constraint if exists questions_scope_check;
alter table public.questions add constraint questions_scope_check check (scope in ('country','africa','global'));
alter table public.countries add column if not exists flag_emoji text, add column if not exists default_language text, add column if not exists app_label text,
 add column if not exists flag_media_id uuid references public.media_assets(id) on delete set null, add column if not exists hero_media_id uuid references public.media_assets(id) on delete set null;
alter table public.game_sessions add column if not exists country_id uuid references public.countries(id);
create table if not exists public.languages(code text primary key, name text not null, native_name text);
alter table public.accepted_answers add column if not exists language text references public.languages(code);
create table if not exists public.question_translations(question_id uuid references public.questions(id) on delete cascade, language text references public.languages(code), prompt text not null, explanation text, primary key(question_id,language));
-- Each country defines its own hierarchy (e.g. Province > District; Region > County; State > LGA)
create table if not exists public.administrative_levels(id uuid primary key default gen_random_uuid(), country_id uuid not null references public.countries(id) on delete cascade, level int not null check (level>0), label text not null, unique(country_id,level));
create table if not exists public.administrative_divisions(id uuid primary key default gen_random_uuid(), country_id uuid not null references public.countries(id) on delete cascade, level int not null, parent_id uuid references public.administrative_divisions(id) on delete cascade, name text not null, code text, unique(country_id,level,name));
create table if not exists public.question_divisions(question_id uuid references public.questions(id) on delete cascade, division_id uuid references public.administrative_divisions(id) on delete cascade, primary key(question_id,division_id));
create index if not exists divisions_country on public.administrative_divisions(country_id,level);
create index if not exists divisions_parent on public.administrative_divisions(parent_id);
-- Country questions must name at least one country before publishing
create or replace function public.questions_publish_scope() returns trigger language plpgsql set search_path='' as $$
begin if new.status='published' and old.status<>'published' and new.scope='country' and not exists(select 1 from public.question_countries where question_id=new.id) then raise exception 'A country question needs at least one country before publishing'; end if; return new; end $$;
drop trigger if exists questions_publish_scope_t on public.questions; create trigger questions_publish_scope_t before update on public.questions for each row execute function public.questions_publish_scope();
-- Topic discovery: categories that actually have published questions for a country
create or replace function public.playable_topics(p_country text, p_include_continental boolean default false)
returns table(slug text, name text, sort_order int, question_count int) language sql stable security invoker set search_path='' as $$
 select c.slug,c.name,c.sort_order,count(*)::int from public.questions q join public.categories c on c.id=q.category_id
 where q.status='published' and c.is_active and ((q.scope='country' and exists(select 1 from public.question_countries qc join public.countries k on k.id=qc.country_id where qc.question_id=q.id and k.iso_code=upper(p_country) and k.status='published')) or (p_include_continental and q.scope in ('africa','global')))
 group by c.id order by c.sort_order $$;
do $$ declare t text; begin foreach t in array array['languages','question_translations','administrative_levels','administrative_divisions','question_divisions'] loop execute format('alter table public.%I enable row level security',t); end loop; end $$;
drop policy if exists "languages read" on public.languages; create policy "languages read" on public.languages for select using (true);
drop policy if exists "languages write" on public.languages; create policy "languages write" on public.languages for all using (public.can_manage()) with check (public.can_manage());
drop policy if exists "levels read" on public.administrative_levels; create policy "levels read" on public.administrative_levels for select using (exists(select 1 from public.countries c where c.id=country_id and (c.status='published' or public.is_staff())));
drop policy if exists "levels write" on public.administrative_levels; create policy "levels write" on public.administrative_levels for all using (public.can_manage()) with check (public.can_manage());
drop policy if exists "divisions read" on public.administrative_divisions; create policy "divisions read" on public.administrative_divisions for select using (exists(select 1 from public.countries c where c.id=country_id and (c.status='published' or public.is_staff())));
drop policy if exists "divisions write" on public.administrative_divisions; create policy "divisions write" on public.administrative_divisions for all using (public.can_manage()) with check (public.can_manage());
do $$ declare t text; begin foreach t in array array['question_translations','question_divisions'] loop
 execute format('drop policy if exists "%1$s read" on public.%1$I; create policy "%1$s read" on public.%1$I for select using (exists(select 1 from public.questions q where q.id=question_id))',t);
 execute format('drop policy if exists "%1$s write" on public.%1$I; create policy "%1$s write" on public.%1$I for all using (public.can_edit_question(question_id)) with check (public.can_edit_question(question_id))',t); end loop; end $$;
