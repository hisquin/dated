-- Dogoma schema. Only creates what is missing; never drops tables or data.
do $$ begin create type public.content_status as enum ('draft','pending_review','reviewed','published','archived'); exception when duplicate_object then null; end $$;
do $$ begin create type public.admin_role as enum ('super_admin','admin','editor','reviewer'); exception when duplicate_object then null; end $$;

create table if not exists public.regions(id uuid primary key default gen_random_uuid(), code text unique not null, name text not null);
create table if not exists public.countries(id uuid primary key default gen_random_uuid(), iso_code char(2) unique not null check (iso_code ~ '^[A-Z]{2}$'), name text not null, region_id uuid references public.regions(id), capital text, languages text[] not null default '{}', description text, status public.content_status not null default 'draft' check (status in ('draft','published','archived')), created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table if not exists public.categories(id uuid primary key default gen_random_uuid(), slug text unique not null, name text not null, sort_order int not null default 0, is_active boolean not null default true, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table if not exists public.subcategories(id uuid primary key default gen_random_uuid(), category_id uuid not null references public.categories(id) on delete cascade, slug text not null, name text not null, sort_order int not null default 0, is_active boolean not null default true, unique(category_id,slug));
create table if not exists public.question_types(key text primary key, label text not null, is_active boolean not null default true);
create table if not exists public.sources(id uuid primary key default gen_random_uuid(), code text unique not null, title text not null, publisher text, url text, published_on date, source_type text, notes text, created_at timestamptz not null default now());
create table if not exists public.media_assets(id uuid primary key default gen_random_uuid(), bucket text not null default 'question-media', storage_path text unique not null, alt_text text, attribution text, source_url text, mime_type text, created_by uuid references auth.users(id) on delete set null, created_at timestamptz not null default now());

create table if not exists public.questions(
 id uuid primary key default gen_random_uuid(),
 code text unique not null check (code ~ '^[A-Z]{2,3}-[A-Z]{3}-[0-9]{4}$'),
 scope text not null check (scope in ('country','africa')),
 category_id uuid not null references public.categories(id),
 subcategory_id uuid references public.subcategories(id),
 difficulty text not null check (difficulty in ('easy','medium','hard')),
 question_type text not null references public.question_types(key),
 prompt text not null check (length(trim(prompt))>0),
 explanation text,
 validation jsonb not null default '{}',   -- typed-answer tolerance, case sensitivity, normalisation
 geo jsonb,                                -- map_location metadata
 media_id uuid references public.media_assets(id) on delete set null,
 status public.content_status not null default 'draft',
 version int not null default 1,
 created_by uuid references auth.users(id) on delete set null, updated_by uuid references auth.users(id) on delete set null, reviewed_by uuid references auth.users(id) on delete set null,
 published_at timestamptz, created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
 check (status<>'published' or length(trim(coalesce(explanation,'')))>0));
create table if not exists public.question_options(id uuid primary key default gen_random_uuid(), question_id uuid not null references public.questions(id) on delete cascade, position int not null, label text not null, match_label text, is_correct boolean not null default false, unique(question_id,position)); -- MC/TF options; ordering items (position = correct order); matching pairs (label/match_label)
create table if not exists public.accepted_answers(id uuid primary key default gen_random_uuid(), question_id uuid not null references public.questions(id) on delete cascade, answer text not null, is_primary boolean not null default false, unique(question_id,answer));
create table if not exists public.question_countries(question_id uuid references public.questions(id) on delete cascade, country_id uuid references public.countries(id) on delete cascade, primary key(question_id,country_id));
create table if not exists public.question_sources(question_id uuid references public.questions(id) on delete cascade, source_id uuid references public.sources(id) on delete restrict, primary key(question_id,source_id));
create table if not exists public.question_revisions(id uuid primary key default gen_random_uuid(), question_id uuid not null references public.questions(id) on delete cascade, version int not null, snapshot jsonb not null, changed_by uuid, changed_at timestamptz not null default now());

create table if not exists public.profiles(id uuid primary key references auth.users(id) on delete cascade, display_name text, created_at timestamptz not null default now());
create table if not exists public.admin_users(user_id uuid primary key references auth.users(id) on delete cascade, role public.admin_role not null, created_at timestamptz not null default now());
create table if not exists public.admin_activity_log(id bigint generated always as identity primary key, actor uuid references auth.users(id) on delete set null, action text not null, entity text, entity_id text, detail jsonb, created_at timestamptz not null default now());
create table if not exists public.game_sessions(id uuid primary key default gen_random_uuid(), player_id uuid references auth.users(id) on delete set null, guest_id text, mode text not null check (mode in ('count','time')), category_id uuid references public.categories(id), started_at timestamptz not null default now(), ended_at timestamptz, score int not null default 0 check (score>=0), attempted int not null default 0 check (attempted>=0), correct int not null default 0 check (correct>=0), check (player_id is not null or guest_id is not null));
create table if not exists public.game_answers(id uuid primary key default gen_random_uuid(), session_id uuid not null references public.game_sessions(id) on delete cascade, question_id uuid references public.questions(id) on delete set null, result text not null check (result in ('correct','incorrect','unanswered')), points int not null default 0 check (points>=0), elapsed_ms int check (elapsed_ms>=0));

create index if not exists questions_status_cat on public.questions(status,category_id);
create index if not exists questions_scope on public.questions(scope);
create index if not exists questions_type on public.questions(question_type);
create index if not exists questions_fts on public.questions using gin (to_tsvector('simple',prompt));
create index if not exists qc_country on public.question_countries(country_id);
create index if not exists qs_source on public.question_sources(source_id);
create index if not exists rev_question on public.question_revisions(question_id,version);
create index if not exists answers_session on public.game_answers(session_id);

-- Role helpers (security definer so policies can read admin_users without exposing it)
create or replace function public.admin_role_of_user() returns public.admin_role language sql stable security definer set search_path='' as $$ select role from public.admin_users where user_id=auth.uid() $$;
create or replace function public.is_staff() returns boolean language sql stable security definer set search_path='' as $$ select public.admin_role_of_user() is not null $$;
create or replace function public.is_super() returns boolean language sql stable security definer set search_path='' as $$ select coalesce(public.admin_role_of_user()='super_admin',false) $$;
create or replace function public.can_manage() returns boolean language sql stable security definer set search_path='' as $$ select coalesce(public.admin_role_of_user() in ('super_admin','admin'),false) $$;
create or replace function public.can_write_content() returns boolean language sql stable security definer set search_path='' as $$ select coalesce(public.admin_role_of_user() in ('super_admin','admin','editor'),false) $$;
create or replace function public.can_edit_question(qid uuid) returns boolean language sql stable security definer set search_path='' as $$
 select case public.admin_role_of_user() when 'super_admin' then true when 'admin' then true
  when 'editor' then exists(select 1 from public.questions where id=qid and status in ('draft','pending_review')) else false end $$;

-- Workflow rules enforced in the database, not the UI
create or replace function public.questions_guard() returns trigger language plpgsql set search_path='' as $$
declare r public.admin_role := public.admin_role_of_user(); skip text[] := array['status','updated_at','updated_by','reviewed_by','published_at','version'];
begin
 if tg_op='INSERT' then
  if new.status='published' then raise exception 'Create the question as a draft, then publish it'; end if;
  if auth.uid() is not null then new.created_by:=auth.uid(); new.updated_by:=auth.uid();
   if r='editor' and new.status not in ('draft','pending_review') then raise exception 'Editors can only create drafts'; end if; end if;
  return new;
 end if;
 new.updated_at:=now();
 if auth.uid() is not null then new.updated_by:=auth.uid();
  if r='editor' then
   if old.status not in ('draft','pending_review') or new.status not in ('draft','pending_review','archived') then raise exception 'Editors can only change draft or pending questions'; end if;
  elsif r='reviewer' then
   if (to_jsonb(new)-skip)<>(to_jsonb(old)-skip) then raise exception 'Reviewers can only change status'; end if;
  end if;
 end if;
 if new.status='published' and old.status<>'published' then
  if not exists(select 1 from public.question_sources where question_id=new.id) then raise exception 'Add at least one source before publishing'; end if;
  new.published_at:=now(); new.reviewed_by:=coalesce(auth.uid(),new.reviewed_by);
 end if;
 if (to_jsonb(new)-skip)<>(to_jsonb(old)-skip) then new.version:=old.version+1; end if;
 return new;
end $$;
create or replace function public.questions_snapshot() returns trigger language plpgsql security definer set search_path='' as $$
begin insert into public.question_revisions(question_id,version,snapshot,changed_by) values(old.id,old.version,to_jsonb(old),auth.uid()); return new; end $$;
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path='' as $$
begin insert into public.profiles(id,display_name) values(new.id,split_part(new.email,'@',1)) on conflict do nothing; return new; end $$;
create or replace function public.touch_updated_at() returns trigger language plpgsql set search_path='' as $$ begin new.updated_at=now(); return new; end $$;

drop trigger if exists questions_guard_t on public.questions; create trigger questions_guard_t before insert or update on public.questions for each row execute function public.questions_guard();
drop trigger if exists questions_snapshot_t on public.questions; create trigger questions_snapshot_t after update on public.questions for each row when (old.* is distinct from new.*) execute function public.questions_snapshot();
drop trigger if exists countries_touch on public.countries; create trigger countries_touch before update on public.countries for each row execute function public.touch_updated_at();
drop trigger if exists categories_touch on public.categories; create trigger categories_touch before update on public.categories for each row execute function public.touch_updated_at();
drop trigger if exists on_auth_user_created on auth.users; create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

-- Row Level Security: every table enabled; no table is writable by anon.
alter table public.regions enable row level security;
alter table public.countries enable row level security;
alter table public.categories enable row level security;
alter table public.subcategories enable row level security;
alter table public.question_types enable row level security;
alter table public.sources enable row level security;
alter table public.media_assets enable row level security;
alter table public.questions enable row level security;
alter table public.question_options enable row level security;
alter table public.accepted_answers enable row level security;
alter table public.question_countries enable row level security;
alter table public.question_sources enable row level security;
alter table public.question_revisions enable row level security;
alter table public.profiles enable row level security;
alter table public.admin_users enable row level security;
alter table public.admin_activity_log enable row level security;
alter table public.game_sessions enable row level security;
alter table public.game_answers enable row level security;
drop policy if exists "regions read" on public.regions; create policy "regions read" on public.regions for select using (true);
drop policy if exists "regions insert" on public.regions; create policy "regions insert" on public.regions for insert with check (public.can_manage());
drop policy if exists "regions update" on public.regions; create policy "regions update" on public.regions for update using (public.can_manage()) with check (public.can_manage());
drop policy if exists "regions delete" on public.regions; create policy "regions delete" on public.regions for delete using (public.can_manage());
drop policy if exists "question_types read" on public.question_types; create policy "question_types read" on public.question_types for select using (true);
drop policy if exists "question_types insert" on public.question_types; create policy "question_types insert" on public.question_types for insert with check (public.can_manage());
drop policy if exists "question_types update" on public.question_types; create policy "question_types update" on public.question_types for update using (public.can_manage()) with check (public.can_manage());
drop policy if exists "question_types delete" on public.question_types; create policy "question_types delete" on public.question_types for delete using (public.can_manage());
drop policy if exists "countries read" on public.countries; create policy "countries read" on public.countries for select using (status='published' or public.is_staff());
drop policy if exists "countries insert" on public.countries; create policy "countries insert" on public.countries for insert with check (public.can_manage());
drop policy if exists "countries update" on public.countries; create policy "countries update" on public.countries for update using (public.can_manage()) with check (public.can_manage());
drop policy if exists "countries delete" on public.countries; create policy "countries delete" on public.countries for delete using (public.can_manage());
drop policy if exists "categories read" on public.categories; create policy "categories read" on public.categories for select using (is_active or public.is_staff());
drop policy if exists "categories insert" on public.categories; create policy "categories insert" on public.categories for insert with check (public.can_manage());
drop policy if exists "categories update" on public.categories; create policy "categories update" on public.categories for update using (public.can_manage()) with check (public.can_manage());
drop policy if exists "categories delete" on public.categories; create policy "categories delete" on public.categories for delete using (public.can_manage());
drop policy if exists "subcategories read" on public.subcategories; create policy "subcategories read" on public.subcategories for select using (is_active or public.is_staff());
drop policy if exists "subcategories insert" on public.subcategories; create policy "subcategories insert" on public.subcategories for insert with check (public.can_manage());
drop policy if exists "subcategories update" on public.subcategories; create policy "subcategories update" on public.subcategories for update using (public.can_manage()) with check (public.can_manage());
drop policy if exists "subcategories delete" on public.subcategories; create policy "subcategories delete" on public.subcategories for delete using (public.can_manage());
drop policy if exists "sources read" on public.sources; create policy "sources read" on public.sources for select using (true);
drop policy if exists "sources insert" on public.sources; create policy "sources insert" on public.sources for insert with check (public.can_write_content());
drop policy if exists "sources update" on public.sources; create policy "sources update" on public.sources for update using (public.can_write_content()) with check (public.can_write_content());
drop policy if exists "sources delete" on public.sources; create policy "sources delete" on public.sources for delete using (public.can_manage());
drop policy if exists "media read" on public.media_assets; create policy "media read" on public.media_assets for select using (true);
drop policy if exists "media insert" on public.media_assets; create policy "media insert" on public.media_assets for insert with check (public.can_write_content());
drop policy if exists "media update" on public.media_assets; create policy "media update" on public.media_assets for update using (public.can_write_content()) with check (public.can_write_content());
drop policy if exists "media delete" on public.media_assets; create policy "media delete" on public.media_assets for delete using (public.can_manage());
drop policy if exists "questions read" on public.questions; create policy "questions read" on public.questions for select using (status='published' or public.is_staff());
drop policy if exists "questions insert" on public.questions; create policy "questions insert" on public.questions for insert with check (public.can_write_content());
drop policy if exists "questions update" on public.questions; create policy "questions update" on public.questions for update using (public.is_staff()) with check (public.is_staff());
drop policy if exists "questions delete" on public.questions; create policy "questions delete" on public.questions for delete using (public.can_manage());
drop policy if exists "question_options read" on public.question_options; create policy "question_options read" on public.question_options for select using (exists(select 1 from public.questions q where q.id=question_id));
drop policy if exists "question_options insert" on public.question_options; create policy "question_options insert" on public.question_options for insert with check (public.can_edit_question(question_id));
drop policy if exists "question_options update" on public.question_options; create policy "question_options update" on public.question_options for update using (public.can_edit_question(question_id)) with check (public.can_edit_question(question_id));
drop policy if exists "question_options delete" on public.question_options; create policy "question_options delete" on public.question_options for delete using (public.can_edit_question(question_id));
drop policy if exists "accepted_answers read" on public.accepted_answers; create policy "accepted_answers read" on public.accepted_answers for select using (exists(select 1 from public.questions q where q.id=question_id));
drop policy if exists "accepted_answers insert" on public.accepted_answers; create policy "accepted_answers insert" on public.accepted_answers for insert with check (public.can_edit_question(question_id));
drop policy if exists "accepted_answers update" on public.accepted_answers; create policy "accepted_answers update" on public.accepted_answers for update using (public.can_edit_question(question_id)) with check (public.can_edit_question(question_id));
drop policy if exists "accepted_answers delete" on public.accepted_answers; create policy "accepted_answers delete" on public.accepted_answers for delete using (public.can_edit_question(question_id));
drop policy if exists "question_countries read" on public.question_countries; create policy "question_countries read" on public.question_countries for select using (exists(select 1 from public.questions q where q.id=question_id));
drop policy if exists "question_countries insert" on public.question_countries; create policy "question_countries insert" on public.question_countries for insert with check (public.can_edit_question(question_id));
drop policy if exists "question_countries update" on public.question_countries; create policy "question_countries update" on public.question_countries for update using (public.can_edit_question(question_id)) with check (public.can_edit_question(question_id));
drop policy if exists "question_countries delete" on public.question_countries; create policy "question_countries delete" on public.question_countries for delete using (public.can_edit_question(question_id));
drop policy if exists "question_sources read" on public.question_sources; create policy "question_sources read" on public.question_sources for select using (exists(select 1 from public.questions q where q.id=question_id));
drop policy if exists "question_sources insert" on public.question_sources; create policy "question_sources insert" on public.question_sources for insert with check (public.can_edit_question(question_id));
drop policy if exists "question_sources update" on public.question_sources; create policy "question_sources update" on public.question_sources for update using (public.can_edit_question(question_id)) with check (public.can_edit_question(question_id));
drop policy if exists "question_sources delete" on public.question_sources; create policy "question_sources delete" on public.question_sources for delete using (public.can_edit_question(question_id));
drop policy if exists "revisions read" on public.question_revisions; create policy "revisions read" on public.question_revisions for select using (public.is_staff());
drop policy if exists "profiles read own" on public.profiles; create policy "profiles read own" on public.profiles for select using (id=auth.uid());
drop policy if exists "profiles update own" on public.profiles; create policy "profiles update own" on public.profiles for update using (id=auth.uid()) with check (id=auth.uid());
drop policy if exists "admin_users read" on public.admin_users; create policy "admin_users read" on public.admin_users for select using (user_id=auth.uid() or public.is_super());
drop policy if exists "admin_users insert" on public.admin_users; create policy "admin_users insert" on public.admin_users for insert with check (public.is_super());
drop policy if exists "admin_users update" on public.admin_users; create policy "admin_users update" on public.admin_users for update using (public.is_super()) with check (public.is_super());
drop policy if exists "admin_users delete" on public.admin_users; create policy "admin_users delete" on public.admin_users for delete using (public.is_super());
drop policy if exists "log read" on public.admin_activity_log; create policy "log read" on public.admin_activity_log for select using (public.can_manage());
drop policy if exists "log insert" on public.admin_activity_log; create policy "log insert" on public.admin_activity_log for insert with check (public.is_staff() and actor=auth.uid());
drop policy if exists "sessions insert" on public.game_sessions; create policy "sessions insert" on public.game_sessions for insert to anon, authenticated with check ((player_id is null and guest_id is not null) or player_id=auth.uid());
drop policy if exists "sessions read own" on public.game_sessions; create policy "sessions read own" on public.game_sessions for select to authenticated using (player_id=auth.uid());
drop policy if exists "sessions update own" on public.game_sessions; create policy "sessions update own" on public.game_sessions for update to authenticated using (player_id=auth.uid()) with check (player_id=auth.uid());
drop policy if exists "answers insert own" on public.game_answers; create policy "answers insert own" on public.game_answers for insert to authenticated with check (exists(select 1 from public.game_sessions s where s.id=session_id and s.player_id=auth.uid()));
drop policy if exists "answers read own" on public.game_answers; create policy "answers read own" on public.game_answers for select to authenticated using (exists(select 1 from public.game_sessions s where s.id=session_id and s.player_id=auth.uid()));
