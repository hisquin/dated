-- Bucket for question images. Public read by URL; only editors and admins can write.
insert into storage.buckets(id,name,public) values('question-media','question-media',true) on conflict (id) do nothing;
drop policy if exists "media staff list" on storage.objects; create policy "media staff list" on storage.objects for select to authenticated using (bucket_id='question-media' and public.is_staff());
drop policy if exists "media write" on storage.objects; create policy "media write" on storage.objects for insert to authenticated with check (bucket_id='question-media' and public.can_write_content());
drop policy if exists "media update" on storage.objects; create policy "media update" on storage.objects for update to authenticated using (bucket_id='question-media' and public.can_write_content()) with check (bucket_id='question-media' and public.can_write_content());
drop policy if exists "media delete" on storage.objects; create policy "media delete" on storage.objects for delete to authenticated using (bucket_id='question-media' and public.can_manage());
