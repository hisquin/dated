-- Run in the Supabase SQL editor after migrating. Each block should behave as the comment says.
begin;
set local role anon;
select count(*) as published_visible_to_anon from public.questions;            -- 0 until you publish, then > 0
select count(*) as options_visible_to_anon from public.question_options;       -- only options of published questions
insert into public.questions(code,scope,category_id,difficulty,question_type,prompt) select 'RW-HIS-9999','country',id,'easy','multiple_choice','x' from public.categories limit 1; -- must FAIL: row-level security
rollback;
begin; set local role anon; select * from public.admin_users; rollback;         -- must return 0 rows
begin; set local role anon; insert into public.game_sessions(guest_id,mode,score) values ('test-guest','count',10); rollback; -- must succeed (guest session)
