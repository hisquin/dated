/* Dogoma service worker: caches the app shell only. It never touches Supabase (cross-origin) or /admin, so unpublished and admin data are never cached. */
const V='dogoma-shell-v1',SHELL=['/','/offline.html','/manifest.webmanifest','/icons/icon-192.png','/icons/icon-512.png'];
self.addEventListener('install',e=>e.waitUntil(caches.open(V).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==V).map(x=>caches.delete(x)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{const r=e.request,u=new URL(r.url);
 if(r.method!=='GET'||u.origin!==location.origin||u.pathname.startsWith('/admin'))return;
 if(r.mode==='navigate'){e.respondWith(fetch(r).catch(()=>caches.match('/').then(h=>h||caches.match('/offline.html'))));return}
 if(/\.(js|css|woff2|png|svg|webp)$/.test(u.pathname))e.respondWith(caches.match(r).then(h=>h||fetch(r).then(res=>{if(res.ok){const c=res.clone();caches.open(V).then(x=>x.put(r,c))}return res})))});
