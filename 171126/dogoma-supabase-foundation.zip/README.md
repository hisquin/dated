# Dogoma: Supabase foundation
- `supabase/migrations/` schema, RLS, storage and Rwanda seed (run in order).
- `supabase/tests/rls_checks.sql` manual access checks.
- `docs/SUPABASE_SETUP.md`, `docs/DATA_SCHEMA.md`.
- `player-prototype/index.html` the single-file player prototype (local JSON content, no Supabase calls yet).
Status: the SQL has not been executed against a live database. The React/TypeScript app, admin dashboard UI, Supabase adapter and remaining docs are not included yet.
