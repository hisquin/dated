import type { Cohort, Course } from "@/domain/models";
// Pages depend on these interfaces only. Replace the mock implementation with a Supabase one later; no component changes.
export interface CatalogService {
  listCourses(): Promise<Course[]>;
  getCourse(slug: string): Promise<Course | undefined>;
  listCohorts(courseId?: string): Promise<Cohort[]>;
  getCohort(id: string): Promise<Cohort | undefined>;
}
