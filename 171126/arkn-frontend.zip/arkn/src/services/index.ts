import type { CatalogService } from "./interfaces";
import { cohorts, courses } from "@/data/mock/catalog";
export const catalog: CatalogService = {
  listCourses: async () => courses.filter((c) => c.published && !c.archived),
  getCourse: async (slug) => courses.find((c) => c.slug === slug && c.published && !c.archived),
  getCohort: async (id) => cohorts.find((h) => h.id === id && h.status !== "Archived"),
  listCohorts: async (courseId) => cohorts.filter((h) => h.status !== "Archived" && (!courseId || h.courseId === courseId)),
};
