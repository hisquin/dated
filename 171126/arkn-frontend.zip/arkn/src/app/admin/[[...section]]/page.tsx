import { Section } from "@/components/dashboard/sections";
import { Shell } from "@/components/dashboard/Shell";
export default async function Page({ params }: { params: Promise<{ section?: string[] }> }) {
  const { section } = await params;
  return (<Shell role="admin"><Section role="admin" id={section?.[0] ?? "overview"} /></Shell>);
}
