import type { Metadata } from "next";
import { requireRole } from "@/lib/guard";
export const metadata: Metadata = { robots: { index: false, follow: false } };
export default async function Layout({ children }: { children: React.ReactNode }) { await requireRole("admin"); return children; }
