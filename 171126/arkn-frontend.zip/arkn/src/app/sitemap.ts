import type { MetadataRoute } from "next";
import { catalog } from "@/services";
import { abs } from "@/lib/site";
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const [courses, cohorts] = [await catalog.listCourses(), await catalog.listCohorts()];
  return [...["/", "/courses", "/cohorts", "/about", "/studio", "/approach", "/faq", "/contact", "/apply"].map((p) => ({ url: abs(p) })), ...courses.map((c) => ({ url: abs(`/courses/${c.slug}`) })), ...cohorts.map((h) => ({ url: abs(`/cohorts/${h.id}`) }))];
}
