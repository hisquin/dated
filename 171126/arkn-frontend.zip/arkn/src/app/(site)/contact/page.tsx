import type { Metadata } from "next";
import { ContactForm } from "@/components/dashboard/PublicForms";
export const metadata: Metadata = { title: "Contact", description: "Contact ARKON SCHOOL.", alternates: { canonical: "/contact" } };
export default function Page() { return (<article><h1>Contact</h1><p>Questions about a cohort, or want to be notified about the next intake?</p><ContactForm /></article>); }
