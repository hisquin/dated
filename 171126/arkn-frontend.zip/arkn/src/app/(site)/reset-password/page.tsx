import type { Metadata } from "next";
import { Suspense } from "react";
import { Reset } from "@/components/dashboard/AuthForms";
export const metadata: Metadata = { title: "Reset password", robots: { index: false, follow: false } };
export default function Page() { return <Suspense><Reset /></Suspense>; }
