import type { Metadata } from "next";
export const metadata: Metadata = { title: "FAQ", description: "Answers to common questions about applying to ARKON SCHOOL.", alternates: { canonical: "/faq" } };
const QA: [string, string][] = [
  ["What does ARKON SCHOOL teach?", "Two disciplines: product design (UI/UX) and product development, with a focus on practical, project-based learning."],
  ["How do I apply?", "Choose an open cohort and use its Apply button. The application is reviewed before any decision."],
  ["Is acceptance the same as enrolment?", "No. Acceptance is an admissions decision. You are enrolled only after you confirm your place and the school completes your enrolment."],
  ["Do I need a portfolio?", "No. Beginners can apply without one. A portfolio or GitHub link is optional."],
  ["How much does it cost and when do cohorts start?", "Tuition and dates are shown on each course and cohort page once confirmed. Until then they are marked to be confirmed."],
];
export default function FAQ() {
  const ld = { "@context": "https://schema.org", "@type": "FAQPage", mainEntity: QA.map(([q, a]) => ({ "@type": "Question", name: q, acceptedAnswer: { "@type": "Answer", text: a } })) };
  return (<article><h1>Frequently asked questions</h1>{QA.map(([q, a]) => (<section key={q}><h2>{q}</h2><p>{a}</p></section>))}<script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ld).replace(/</g, "\\u003c") }} /></article>);
}
