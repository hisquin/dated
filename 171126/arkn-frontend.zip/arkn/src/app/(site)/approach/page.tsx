import type { Metadata } from "next";
export const metadata: Metadata = { title: "Approach", description: "How learning works at ARKON SCHOOL: briefs, critique, cohorts and shipping.", alternates: { canonical: "/approach" } };
export default function Page() { return (<article><h1>Approach</h1><p>Teaching centres on practical skills, mentorship and demonstrable work.</p><ol><li>Work from real briefs.</li><li>Experiment and build.</li><li>Receive professional critique.</li><li>Improve and ship.</li></ol><p>Programmes cover product design (UI/UX) and product development.</p></article>); }
