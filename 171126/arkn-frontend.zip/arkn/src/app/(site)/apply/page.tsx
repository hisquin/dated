import type { Metadata } from "next";
import { Suspense } from "react";
import { ApplyForm } from "@/components/dashboard/PublicForms";
export const metadata: Metadata = { title: "Apply", description: "Apply to an ARKON SCHOOL cohort.", alternates: { canonical: "/apply" } };
export default function Page() { return (<article><h1>Apply</h1><Suspense><ApplyForm /></Suspense></article>); }
