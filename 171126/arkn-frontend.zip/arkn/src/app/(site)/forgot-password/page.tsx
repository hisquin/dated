import type { Metadata } from "next";
import { Forgot } from "@/components/dashboard/AuthForms";
export const metadata: Metadata = { title: "Forgot password", robots: { index: false, follow: false } };
export default function Page() { return <Forgot />; }
