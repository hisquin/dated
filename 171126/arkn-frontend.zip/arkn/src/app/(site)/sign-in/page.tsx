import type { Metadata } from "next";
import { SignIn } from "@/components/dashboard/AuthForms";
export const metadata: Metadata = { title: "Sign in", robots: { index: false, follow: false } };
export default function Page() { return <SignIn />; }
