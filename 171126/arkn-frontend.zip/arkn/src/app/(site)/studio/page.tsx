import type { Metadata } from "next";
export const metadata: Metadata = { title: "Studio", description: "How ARKON SCHOOL connects to ArkonMade's product studio.", alternates: { canonical: "/studio" } };
export default function Page() { return (<article><h1>Studio</h1><p>ARKON SCHOOL is connected to ArkonMade, an active product design and development studio.</p><p>Students learn the way practitioners work: through briefs, experimentation, collaboration, critique and shipping real products.</p></article>); }
