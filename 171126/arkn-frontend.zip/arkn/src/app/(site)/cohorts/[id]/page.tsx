import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { canApply } from "@/domain/admissions";
import { catalog } from "@/services";
import { breadcrumbLd } from "@/lib/jsonld";
type P = { params: Promise<{ id: string }> };
const WHY: Record<string, string> = { "cohort-closed": "Registration for this cohort is not open.", "deadline-passed": "The application deadline has passed.", "cohort-full": "This cohort is full.", "course-unpublished": "This course is not accepting applications.", "course-archived": "This course is archived." };
export async function generateMetadata({ params }: P): Promise<Metadata> { const h = await catalog.getCohort((await params).id); return h ? { title: h.name, alternates: { canonical: `/cohorts/${h.id}` } } : {}; }
export default async function CohortPage({ params }: P) {
  const h = await catalog.getCohort((await params).id); if (!h) notFound();
  const c = await catalog.getCourse(h.courseId), r = c ? canApply(c, h, new Date().toISOString().slice(0, 10), [], "") : { ok: false as const, reason: "course-unpublished" as const };
  return (<article><p><Link href="/cohorts">← Cohorts</Link></p><h1>{h.name}</h1><p>{c?.title} · {h.status}</p>
    <dl><dt>Starts</dt><dd>{h.start ?? "To be confirmed"}</dd><dt>Schedule</dt><dd>{h.schedule ?? "To be confirmed"}</dd><dt>Format</dt><dd>{h.format ?? "To be confirmed"}</dd><dt>Apply by</dt><dd>{h.deadline ?? "To be confirmed"}</dd><dt>Spaces</dt><dd>{h.capacity - h.enrolled} of {h.capacity} left (sample data)</dd></dl>
    {r.ok ? <Link className="btn" href={`/apply?cohort=${h.id}`}>Apply now</Link> : <p className="note">{WHY[r.reason] ?? "Applications are not available."} <Link href="/contact">Ask to be notified about the next intake.</Link></p>}
    <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbLd([{ name: "Home", path: "/" }, { name: "Cohorts", path: "/cohorts" }, { name: h.name, path: `/cohorts/${h.id}` }])).replace(/</g, "\\u003c") }} /></article>);
}
