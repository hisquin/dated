import type { Metadata } from "next";
import Link from "next/link";
import { catalog } from "@/services";
export const metadata: Metadata = { title: "Cohorts and intakes", description: "Upcoming ARKON SCHOOL cohorts, start dates and registration status.", alternates: { canonical: "/cohorts" } };
export default async function Cohorts() {
  const [cohorts, courses] = [await catalog.listCohorts(), await catalog.listCourses()];
  return (<section><h1>Cohorts</h1><p>Every course runs in cohorts. Pick the start that suits you.</p>
    {cohorts.length ? <ul className="plain">{cohorts.map((h) => (<li key={h.id}><Link href={`/cohorts/${h.id}`}><strong>{h.name}</strong></Link> · {courses.find((c) => c.id === h.courseId)?.title} · {h.status}{h.start ? ` · starts ${h.start}` : " · start date to be confirmed"}</li>))}</ul> : <p>No cohorts have been announced yet.</p>}</section>);
}
