import Link from "next/link";
const links: [string, string][] = [["Courses", "/courses"], ["Cohorts", "/cohorts"], ["About", "/about"], ["Studio", "/studio"], ["Approach", "/approach"], ["FAQ", "/faq"], ["Contact", "/contact"]];
export default function SiteLayout({ children }: { children: React.ReactNode }) {
  return (<>
    <header className="site"><div className="wrap bar"><Link href="/" className="logo">ARKON/SCHOOL</Link>
      <nav aria-label="Main">{links.map(([l, h]) => <Link key={h} href={h}>{l}</Link>)}</nav><span style={{ flex: 1 }} /><Link href="/sign-in">Sign in</Link><Link href="/apply" className="btn sm">Apply</Link></div></header>
    <main className="wrap">{children}</main>
    <footer className="wrap foot">ARKON SCHOOL · the learning arm of ArkonMade · Rwanda</footer></>);
}
