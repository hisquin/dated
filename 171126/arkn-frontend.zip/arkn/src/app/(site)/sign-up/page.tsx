import type { Metadata } from "next";
import { SignUp } from "@/components/dashboard/AuthForms";
export const metadata: Metadata = { title: "Create account", robots: { index: false, follow: false } };
export default function Page() { return <SignUp />; }
