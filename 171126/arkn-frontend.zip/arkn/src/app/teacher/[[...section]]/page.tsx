import { Section } from "@/components/dashboard/sections";
import { Shell } from "@/components/dashboard/Shell";
export default async function Page({ params }: { params: Promise<{ section?: string[] }> }) {
  const { section } = await params;
  return (<Shell role="teacher"><Section role="teacher" id={section?.[0] ?? "overview"} /></Shell>);
}
