import type { Row } from "@/lib/demo";
// SAMPLE DATA for the frontend phase. Demo password for every seeded account: arkon-demo
export const DEMO_PASSWORD = "arkon-demo";
export const USERS: Row[] = [
  { id: "u1", name: "ARKON Admin", email: "admin@arkon.test", phone: "", role: "Admin", status: "Active", bio: "", link: "", avatar: "", password: DEMO_PASSWORD },
  { id: "u2", name: "Sample Teacher", email: "teacher@arkon.test", phone: "", role: "Teacher", status: "Active", bio: "Sample teacher profile.", link: "", avatar: "", password: DEMO_PASSWORD },
  { id: "u3", name: "Sample Student", email: "student@arkon.test", phone: "", role: "Student", status: "Active", bio: "", link: "", avatar: "", password: DEMO_PASSWORD },
  { id: "u4", name: "Second Student", email: "student2@arkon.test", phone: "", role: "Student", status: "Active", bio: "", link: "", avatar: "", password: DEMO_PASSWORD },
];
export const COURSES: Row[] = [
  { id: "product-design", title: "Product Design (UI/UX)", summary: "Research, design and test digital products.", duration: "12 weeks", format: "Hybrid", outcomes: "User research; Wireframing and prototyping; Design systems; Usability testing", status: "Published" },
  { id: "product-development", title: "Product Development", summary: "Build, test and ship digital products.", duration: "16 weeks", format: "On-site", outcomes: "Frontend and backend; AI integration; Testing and deployment", status: "Published" },
];
export const COHORTS: Row[] = [
  { id: "pd-c03", courseId: "product-design", name: "Design · Cohort 03", status: "Open", capacity: 30, enrolled: 18, start: "2026-12-07", end: "2027-03-01", deadline: "2026-11-30", schedule: "Mon & Wed, 6–8pm", format: "Hybrid", teacherEmail: "teacher@arkon.test" },
  { id: "pdv-c02", courseId: "product-development", name: "Development · Cohort 02", status: "Open", capacity: 25, enrolled: 9, start: "2026-12-14", end: "2027-04-05", deadline: "2026-12-05", schedule: "Tue & Thu, 6–8:30pm", format: "On-site", teacherEmail: "" },
  { id: "pd-c04", courseId: "product-design", name: "Design · Cohort 04", status: "Coming soon", capacity: 30, enrolled: 0, start: "2027-02-02", end: "", deadline: "2027-01-20", schedule: "Tue & Thu, 6–8pm", format: "Online", teacherEmail: "" },
];
export const APPS: Row[] = [
  { id: "a1", ref: "ARK-DEMO1", name: "Second Student", email: "student2@arkon.test", courseId: "product-design", cohortId: "pd-c03", status: "Under review", date: "2026-11-08" },
  { id: "a2", ref: "ARK-DEMO2", name: "Eric Habimana", email: "eric@example.com", courseId: "product-development", cohortId: "pdv-c02", status: "Submitted", date: "2026-11-06" },
  { id: "a3", ref: "ARK-DEMO3", name: "Grace Mukamana", email: "grace@example.com", courseId: "product-design", cohortId: "pd-c03", status: "Interview", date: "2026-11-05" },
  { id: "a4", ref: "ARK-DEMO4", name: "David Nshuti", email: "david@example.com", courseId: "product-design", cohortId: "pd-c03", status: "Accepted", date: "2026-11-02" },
  { id: "a5", ref: "ARK-DEMO5", name: "Sample Student", email: "student@arkon.test", courseId: "product-design", cohortId: "pd-c03", status: "Enrolled", date: "2026-10-20" },
];
export const ENROLS: Row[] = [{ id: "e1", studentEmail: "student@arkon.test", studentName: "Sample Student", cohortId: "pd-c03", progress: "40%", date: "2026-10-28" }];
export const LESSONS: Row[] = [
  { id: "l1", title: "What is product discovery", module: "1 · Discovery", cohortId: "pd-c03", format: "Video", status: "Published" },
  { id: "l2", title: "User interviews", module: "1 · Discovery", cohortId: "pd-c03", format: "Text", status: "Published" },
  { id: "l3", title: "Low-fidelity wireframes", module: "2 · Wireframing", cohortId: "pd-c03", format: "Audio", status: "Draft" },
];
export const SUBS: Row[] = [
  { id: "s1", student: "student@arkon.test", assignment: "User interviews", status: "Submitted", grade: "", feedback: "", cohortId: "pd-c03" },
  { id: "s2", student: "student2@arkon.test", assignment: "User interviews", status: "Graded", grade: 82, feedback: "Clear insights. Tighten your synthesis.", cohortId: "pd-c03" },
];
export const ATTEND: Row[] = [
  { id: "t1", student: "Sample Student", session: "2026-11-11 · Wireframing", mark: "Present", cohortId: "pd-c03" },
  { id: "t2", student: "Second Student", session: "2026-11-11 · Wireframing", mark: "Late", cohortId: "pd-c03" },
];
export const SESSIONS: Row[] = [
  { id: "c1", date: "2026-11-18", time: "18:00", type: "Class", topic: "Prototyping workshop", cohortId: "pd-c03" },
  { id: "c2", date: "2026-11-21", time: "23:59", type: "Deadline", topic: "Wireframe set due", cohortId: "pd-c03" },
];
export const ANNS: Row[] = [{ id: "n1", title: "Studio visit", body: "Sample announcement: studio visit on Nov 20.", audience: "All", author: "admin@arkon.test", date: "2026-11-10" }];
export const NOTIFS: Row[] = [{ id: "m1", to: "student@arkon.test", title: "Welcome to ARKON SCHOOL", body: "Sample notification.", date: "2026-10-28" }];
export const SETTINGS: Row[] = [{ id: "s", schoolName: "ARKON SCHOOL", contactEmail: "", applicationsOpen: "Yes", windowStart: "2026-11-01", windowEnd: "2026-12-05", enrolmentOpen: "Yes" }];
