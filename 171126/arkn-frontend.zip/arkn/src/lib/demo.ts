"use client";
// DEMO persistence: browser localStorage + a plain cookie. Not secure, not shared between devices. Replaced by real services later.
import { useCallback, useEffect, useState } from "react";
export type Row = { id: string } & Record<string, string | number | boolean>;
const K = "arkon-demo:", COOKIE = "arkon_demo_session";
export function read<T>(key: string, seed: T): T { if (typeof window === "undefined") return seed; try { const v = localStorage.getItem(K + key); return v ? (JSON.parse(v) as T) : seed; } catch { return seed; } }
export function write<T>(key: string, v: T) { try { localStorage.setItem(K + key, JSON.stringify(v)); window.dispatchEvent(new Event("arkon-demo")); } catch { /* storage unavailable */ } }
export function useStore<T>(key: string, seed: T): [T, (v: T) => void] {
  const [v, setV] = useState<T>(seed);
  useEffect(() => { const load = () => setV(read(key, seed)); load(); window.addEventListener("arkon-demo", load); return () => window.removeEventListener("arkon-demo", load); }, [key]); // eslint-disable-line react-hooks/exhaustive-deps
  const set = useCallback((n: T) => write(key, n), [key]);
  return [v, set];
}
export function startSession(role: string, email: string) { document.cookie = `${COOKIE}=${encodeURIComponent(role + "|" + email)}; path=/; SameSite=Lax`; }
export function endSession() { document.cookie = `${COOKIE}=; path=/; max-age=0`; }
export function useMe(): string { const [e, setE] = useState(""); useEffect(() => { const m = document.cookie.match(new RegExp(COOKIE + "=([^;]+)")); setE(m ? decodeURIComponent(m[1]).split("|")[1] ?? "" : ""); }, []); return e; }
