import { cookies } from "next/headers";
import { redirect } from "next/navigation";
// DEMO guard: trusts a cookie the browser set itself. Real enforcement (verified session + database rules) comes with the backend phase.
export async function requireRole(role: "student" | "teacher" | "admin"): Promise<string> {
  const raw = (await cookies()).get("arkon_demo_session")?.value ?? "";
  const [r, email] = decodeURIComponent(raw).split("|");
  if (!r) redirect("/sign-in");
  if (r !== role) redirect("/" + r);
  return email ?? "";
}
