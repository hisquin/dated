"use client";
import { canEnrol } from "@/domain/admissions";
import type { Application, ApplicationStatus, Cohort, CohortStatus, Course, Enrolment } from "@/domain/models";
import { read, write, type Row } from "./demo";
import { APPS, COHORTS, COURSES, ENROLS, NOTIFS } from "@/data/mock/seed";
const WHY: Record<string, string> = { "course-unpublished": "The course is not published.", "course-archived": "The course is archived.", "cohort-not-found": "Cohort not found.", "wrong-course": "Cohort and course do not match.", "cohort-closed": "The cohort is closed.", "deadline-passed": "The registration window has closed.", "cohort-full": "The cohort is full.", duplicate: "Already enrolled in this cohort.", "admission-required": "Only accepted applicants can be enrolled." };
/** Enrols an Accepted applicant using the tested domain rules. Returns "" on success or a reason. Demo storage only. */
export function enrol(appId: string): string {
  const a = read<Row[]>("applications", APPS).find((x) => x.id === appId); if (!a) return "Application not found.";
  const ch = read<Row[]>("cohorts", COHORTS), c = ch.find((x) => x.id === a.cohortId), co = read<Row[]>("courses", COURSES).find((x) => x.id === a.courseId);
  const ens = read<Row[]>("enrolments", ENROLS);
  const course: Course | undefined = co && { id: String(co.id), slug: String(co.id), title: String(co.title), summary: "", published: co.status === "Published", archived: co.status === "Archived", mode: "selective", outcomes: [] };
  const cohort: Cohort | undefined = c && { id: String(c.id), courseId: String(c.courseId), name: String(c.name), status: c.status as CohortStatus, capacity: Number(c.capacity), enrolled: Number(c.enrolled) };
  const app: Application = { id: String(a.id), ref: String(a.ref), applicantEmail: String(a.email), courseId: String(a.courseId), cohortId: String(a.cohortId), status: a.status as ApplicationStatus, history: [] };
  const list: Enrolment[] = ens.map((e) => ({ id: String(e.id), studentId: String(e.studentEmail), courseId: "", cohortId: String(e.cohortId), createdAt: "" }));
  if (!course) return "Course not found.";
  const r = canEnrol(course, cohort, new Date().toISOString().slice(0, 10), app, list, String(a.email));
  if (!r.ok) return WHY[r.reason] ?? r.reason;
  write("applications", read<Row[]>("applications", APPS).map((x) => (x.id === appId ? { ...x, status: "Enrolled" } : x)));
  write("cohorts", ch.map((x) => (x.id === a.cohortId ? { ...x, enrolled: Number(x.enrolled) + 1 } : x)));
  write("enrolments", [{ id: "e" + Date.now().toString(36), studentEmail: String(a.email), studentName: String(a.name), cohortId: String(a.cohortId), progress: "0%", date: new Date().toISOString().slice(0, 10) }, ...ens]);
  write("notifications", [{ id: "m" + Date.now().toString(36), to: String(a.email), title: "You are enrolled", body: `Your place in ${cohort?.name} is confirmed (demo).`, date: new Date().toISOString().slice(0, 10) }, ...read<Row[]>("notifications", NOTIFS)]);
  return "";
}
