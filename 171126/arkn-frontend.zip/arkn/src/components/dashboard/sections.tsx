"use client";
import { useState, type FormEvent } from "react";
import { canTransition } from "@/domain/application-status";
import type { ApplicationStatus } from "@/domain/models";
import { enrol } from "@/lib/enrol";
import { read, useMe, useStore, write, type Row } from "@/lib/demo";
import { ANNS, APPS, ATTEND, COHORTS, COURSES, ENROLS, LESSONS, NOTIFS, SESSIONS, SETTINGS, SUBS, USERS } from "@/data/mock/seed";
import { Empty, Head, Pill, Resource, Stats, type Act } from "./ui";
const today = () => new Date().toISOString().slice(0, 10), uid = (p: string) => p + Date.now().toString(36);
const notify = (to: string, title: string, body: string) => write("notifications", [{ id: uid("m"), to, title, body, date: today() }, ...read<Row[]>("notifications", NOTIFS)]);
const setStatus = (to: string): Act => ({ label: to === "Under review" ? "Start review" : to === "Interview" ? "Invite to interview" : to === "Accepted" ? "Accept" : to === "Waitlisted" ? "Waitlist" : "Decline", show: (r) => canTransition(r.status as ApplicationStatus, to as ApplicationStatus), run: () => ({ status: to }) });
// ---------- shared ----------
function Profile() {
  const me = useMe(), [users, setUsers] = useStore<Row[]>("users", USERS), u = users.find((x) => x.email === me), [msg, setMsg] = useState(""), [pic, setPic] = useState<string | null>(null);
  if (!u) return <Empty t="Profile not found" s="Sign in again." />;
  function save(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); const fd = new FormData(e.currentTarget), pw = String(fd.get("password") ?? ""), name = String(fd.get("name") ?? "").trim(), link = String(fd.get("link") ?? "").trim();
    if (!name) return setMsg("Name is required."); if (link && !/^https?:\/\//i.test(link)) return setMsg("Link must start with https://"); if (pw && pw.length < 8) return setMsg("Password needs at least 8 characters.");
    setUsers(users.map((x) => (x.id === u!.id ? { ...x, name, phone: String(fd.get("phone") ?? ""), bio: String(fd.get("bio") ?? ""), link, avatar: pic ?? String(x.avatar), ...(pw ? { password: pw } : {}) } : x))); setMsg("Saved (demo data, this browser only).");
  }
  function pick(f?: File) { if (!f) return; if (f.size > 200000) return setMsg("Photo must be under 200 KB."); const r = new FileReader(); r.onload = () => setPic(String(r.result)); r.readAsDataURL(f); }
  const av = pic ?? String(u.avatar);
  return (<section><Head t="Profile" s={`Role: ${u.role} (assigned by the system, not editable)`} />
    <form onSubmit={save} className="panel" noValidate>{av ? <img src={av} alt="Your profile photo" width={72} height={72} className="avatar" /> : <span className="avatar">{String(u.name).slice(0, 2).toUpperCase()}</span>}
      <label>Profile photo<input type="file" accept="image/*" onChange={(e) => pick(e.target.files?.[0])} /></label>
      <label>Full name<input name="name" defaultValue={String(u.name)} /></label><label>Email<input value={String(u.email)} readOnly /></label>
      <label>Phone<input name="phone" type="tel" defaultValue={String(u.phone)} /></label><label>Short biography<textarea name="bio" rows={3} defaultValue={String(u.bio)} /></label>
      <label>Portfolio, CV or website link<input name="link" type="url" defaultValue={String(u.link)} /></label><label>New password (optional)<input name="password" type="password" autoComplete="new-password" /></label>
      <button className="btn" type="submit">Save profile</button>{msg && <p className="note" role="status">{msg}</p>}</form></section>);
}
const Announcements = ({ role }: { role: string }) => { const me = useMe(); return (<Resource id="announcements" seed={ANNS} title="Announcements" sub={role === "admin" ? "School-wide or targeted" : "Updates for your cohorts"} cols={[{ k: "title", l: "Title" }, { k: "audience", l: "Audience" }, { k: "date", l: "Date" }]} filter="audience" create="New announcement"
  fields={[{ k: "title", l: "Title", req: true }, { k: "body", l: "Message", type: "textarea", req: true }, { k: "audience", l: "Audience", type: "select", opts: role === "admin" ? ["All", "Students", "Teachers"] : ["My cohorts"] }]} prep={(r) => ({ ...r, author: me, date: today() })} where={(r) => role === "admin" || r.author === me} after={(r) => (r.audience === "All" || r.audience === "Students" ? (notify("student@arkon.test", `Announcement: ${r.title}`, String(r.body)), "Published. A demo notification was added for the sample student.") : "Published (demo data).")} />); };
// ---------- admin ----------
function AdminOverview() {
  const [a] = useStore<Row[]>("applications", APPS), [c] = useStore<Row[]>("cohorts", COHORTS), [u] = useStore<Row[]>("users", USERS), [co] = useStore<Row[]>("courses", COURSES);
  const spaces = c.filter((x) => x.status === "Open").reduce((t, x) => t + Number(x.capacity) - Number(x.enrolled), 0), pending = a.filter((x) => x.status === "Submitted" || x.status === "Under review"), iv = a.filter((x) => x.status === "Interview");
  return (<section><Head t="Overview" s="Sample data, this browser only" /><Stats items={[["Students", u.filter((x) => x.role === "Student").length], ["Teachers", u.filter((x) => x.role === "Teacher").length], ["Applications", a.length], ["Active courses", co.filter((x) => x.status === "Published").length], ["Active cohorts", c.filter((x) => x.status !== "Archived" && x.status !== "Closed").length], ["Open spaces", spaces]]} />
    <h2>Pending applications ({pending.length})</h2>{pending.length ? <ul>{pending.map((x) => <li key={x.id}>{String(x.name)} · {String(x.cohortId)} · <Pill s={String(x.status)} /></li>)}</ul> : <Empty t="Nothing pending" s="New applications appear here." />}
    <h2>Upcoming interviews ({iv.length})</h2>{iv.length ? <ul>{iv.map((x) => <li key={x.id}>{String(x.name)} · {String(x.cohortId)}</li>)}</ul> : <p>No interviews scheduled.</p>}
    <h2>Cohort spaces</h2><ul>{c.map((x) => <li key={x.id}>{String(x.name)}: {Number(x.capacity) - Number(x.enrolled)} of {String(x.capacity)} spaces left</li>)}</ul></section>);
}
function EnrolPanel() {
  const [a] = useStore<Row[]>("applications", APPS), [en] = useStore<Row[]>("enrolments", ENROLS), [msg, setMsg] = useState(""), acc = a.filter((x) => x.status === "Accepted");
  return (<section><Head t="Enrolments" s="Accepted applicants become students only when enrolled" />{msg && <p className="note" role="status">{msg}</p>}
    <h2>Accepted, awaiting enrolment ({acc.length})</h2>{acc.length ? <div className="tw"><table><tbody>{acc.map((x) => <tr key={x.id}><td>{String(x.name)}</td><td>{String(x.cohortId)}</td><td><button className="btn sm" onClick={() => { const e = enrol(String(x.id)); setMsg(e || `${x.name} enrolled (demo data).`); }}>Enrol</button></td></tr>)}</tbody></table></div> : <Empty t="No accepted applicants" s="Accept an application first." />}
    <h2>Current enrolments ({en.length})</h2>{en.length ? <div className="tw"><table><thead><tr><th>Student</th><th>Cohort</th><th>Since</th></tr></thead><tbody>{en.map((x) => <tr key={x.id}><td data-l="Student">{String(x.studentName)}</td><td data-l="Cohort">{String(x.cohortId)}</td><td data-l="Since">{String(x.date)}</td></tr>)}</tbody></table></div> : <Empty t="No enrolments" s="Enrolled students appear here." />}</section>);
}
const userActs: Act[] = [{ label: "Deactivate", show: (r) => r.status === "Active", run: () => ({ status: "Inactive" }) }, { label: "Activate", show: (r) => r.status !== "Active", run: () => ({ status: "Active" }) }];
const ucols = [{ k: "name", l: "Name" }, { k: "email", l: "Email" }, { k: "role", l: "Role" }, { k: "status", l: "Status", pill: true }];
const upf = [{ k: "name", l: "Full name", req: true }, { k: "email", l: "Email", type: "email" as const, req: true }, { k: "phone", l: "Phone" }, { k: "bio", l: "Biography", type: "textarea" as const }, { k: "link", l: "External link" }];
function Settings() {
  const [s, set] = useStore<Row[]>("settings", SETTINGS), r = s[0], [m, setM] = useState("");
  return (<section><Head t="Settings" s="School information, application periods, enrolment" /><form className="panel" onSubmit={(e) => { e.preventDefault(); const f = Object.fromEntries(new FormData(e.currentTarget)) as Record<string, string>; set([{ ...r, ...f }]); setM("Saved (demo data)."); }}>
    <label>School name<input name="schoolName" defaultValue={String(r.schoolName)} /></label><label>Contact email<input name="contactEmail" type="email" defaultValue={String(r.contactEmail)} /></label>
    <label>Applications open<select name="applicationsOpen" defaultValue={String(r.applicationsOpen)}><option>Yes</option><option>No</option></select></label>
    <label>Application window starts<input name="windowStart" type="date" defaultValue={String(r.windowStart)} /></label><label>Application window ends<input name="windowEnd" type="date" defaultValue={String(r.windowEnd)} /></label>
    <label>Enrolment open<select name="enrolmentOpen" defaultValue={String(r.enrolmentOpen)}><option>Yes</option><option>No</option></select></label><button className="btn" type="submit">Save settings</button>{m && <p className="note" role="status">{m}</p>}</form></section>);
}
const courseActs: Act[] = [{ label: "Publish", show: (r) => r.status !== "Published", run: () => ({ status: "Published" }) }, { label: "Unpublish", show: (r) => r.status === "Published", run: () => ({ status: "Draft" }) }, { label: "Archive", show: (r) => r.status !== "Archived", run: () => ({ status: "Archived" }) }];
// ---------- teacher / student ----------
function useMine() { const me = useMe(), [c] = useStore<Row[]>("cohorts", COHORTS), mine = c.filter((x) => x.teacherEmail === me).map((x) => String(x.id)); return { me, mine, c }; }
function TeacherOverview() {
  const { mine, c } = useMine(), [en] = useStore<Row[]>("enrolments", ENROLS), [s] = useStore<Row[]>("submissions", SUBS), [se] = useStore<Row[]>("sessions", SESSIONS);
  if (!mine.length) return <section><Head t="Overview" /><Empty t="No cohort assigned yet" s="An administrator assigns cohorts to teachers. Your students and tools appear here once you are assigned." /></section>;
  return (<section><Head t="Overview" s="Your assigned cohorts" /><Stats items={[["Cohorts", mine.length], ["Students", en.filter((x) => mine.includes(String(x.cohortId))).length], ["To grade", s.filter((x) => mine.includes(String(x.cohortId)) && x.status === "Submitted").length], ["Upcoming", se.filter((x) => mine.includes(String(x.cohortId))).length]]} /><h2>Cohorts</h2><ul>{c.filter((x) => mine.includes(String(x.id))).map((x) => <li key={x.id}>{String(x.name)} · {String(x.schedule)}</li>)}</ul></section>);
}
function TeacherOnly({ children }: { children: (m: ReturnType<typeof useMine>) => React.ReactNode }) { const m = useMine(); return m.mine.length ? <>{children(m)}</> : <section><Head t="Not assigned yet" /><Empty t="No cohort assigned yet" s="An administrator assigns cohorts to teachers." /></section>; }
function useEnrolled() { const me = useMe(), [en] = useStore<Row[]>("enrolments", ENROLS); const cohortId = String(en.find((x) => x.studentEmail === me)?.cohortId ?? ""); return { me, cohortId }; }
const Locked = () => <section><Head t="Locked" /><Empty t="Locked until you are enrolled" s="Learning content opens after your application is accepted and your enrolment is confirmed. Check Applications." /></section>;
function Learning() {
  const { me, cohortId } = useEnrolled(), [l] = useStore<Row[]>("lessons", LESSONS), [p, setP] = useStore<Row[]>("progress", []);
  if (!cohortId) return <Locked />; const mine = l.filter((x) => x.cohortId === cohortId && x.status === "Published"), done = (id: string) => p.some((x) => x.id === me + ":" + id);
  return (<section><Head t="My learning" s={`${mine.filter((x) => done(String(x.id))).length} of ${mine.length} lessons complete`} />{mine.length ? <div className="tw"><table><thead><tr><th>Lesson</th><th>Module</th><th>Format</th><th>Status</th></tr></thead><tbody>{mine.map((x) => <tr key={x.id}><td data-l="Lesson">{String(x.title)}</td><td data-l="Module">{String(x.module)}</td><td data-l="Format">{String(x.format)} <small>(demo: no media attached)</small></td><td data-l="Status"><button className="btn alt sm" onClick={() => setP(done(String(x.id)) ? p.filter((y) => y.id !== me + ":" + x.id) : [...p, { id: me + ":" + x.id }])}>{done(String(x.id)) ? "Completed ✓" : "Mark complete"}</button></td></tr>)}</tbody></table></div> : <Empty t="No lessons published yet" s="Your teacher is preparing the course." />}</section>);
}
function StudentOverview() {
  const { me, cohortId } = useEnrolled(), [a] = useStore<Row[]>("applications", APPS), [n] = useStore<Row[]>("notifications", NOTIFS), mine = a.filter((x) => x.email === me);
  return (<section><Head t="Overview" /><Stats items={[["Applications", mine.length], ["Enrolled in", cohortId || "—"], ["Notifications", n.filter((x) => x.to === me).length]]} /><h2>Next steps</h2><ul>{!mine.length && <li>Browse <a href="/cohorts">cohorts</a> and apply.</li>}{mine.map((x) => <li key={x.id}>{String(x.cohortId)}: <Pill s={String(x.status)} />{x.status === "Accepted" && " — confirm your enrolment in Applications."}{x.status === "Enrolled" && " — open My learning."}</li>)}</ul></section>);
}
// ---------- registry ----------
export function Section({ role, id }: { role: string; id: string }) {
  const k = `${role}/${id}`;
  if (id === "profile") return <Profile />; if (id === "announcements" && role !== "student") return <Announcements role={role} />;
  switch (k) {
    case "admin/overview": return <AdminOverview />;
    case "admin/applications": return <Resource id="applications" seed={APPS} title="Applications" sub="Applied, under review, interview, accepted or declined" cols={[{ k: "ref", l: "Ref" }, { k: "name", l: "Applicant" }, { k: "cohortId", l: "Cohort" }, { k: "date", l: "Date" }, { k: "status", l: "Status", pill: true }]} filter="status" noDelete
      acts={[...["Under review", "Interview", "Accepted", "Waitlisted", "Declined"].map(setStatus), { label: "Send notice (demo)", show: (r) => ["Interview", "Accepted", "Declined", "Waitlisted"].includes(String(r.status)), run: (r) => { notify(String(r.email), `Application update: ${r.status}`, `Your application ${r.ref} is now: ${r.status}.`); } }]} />;
    case "admin/enrolments": return <EnrolPanel />;
    case "admin/courses": return <Resource id="courses" seed={COURSES} title="Courses" sub="Create, publish, unpublish and archive" cols={[{ k: "title", l: "Course" }, { k: "duration", l: "Duration" }, { k: "format", l: "Format" }, { k: "status", l: "Status", pill: true }]} filter="status" create="New course" acts={courseActs}
      fields={[{ k: "title", l: "Title", req: true }, { k: "summary", l: "Description", type: "textarea", req: true }, { k: "duration", l: "Duration" }, { k: "format", l: "Format", type: "select", opts: ["Hybrid", "On-site", "Online"] }, { k: "outcomes", l: "Learning objectives (separate with ;)", type: "textarea" }, { k: "status", l: "Status", type: "select", opts: ["Draft", "Published", "Archived"] }]} prep={(r) => ({ ...r, id: String(r.title).toLowerCase().replace(/[^a-z0-9]+/g, "-") })} />;
    case "admin/cohorts": return <Resource id="cohorts" seed={COHORTS} title="Cohorts" sub="Schedules, capacity and teachers" cols={[{ k: "name", l: "Cohort" }, { k: "start", l: "Starts" }, { k: "enrolled", l: "Enrolled" }, { k: "capacity", l: "Capacity" }, { k: "teacherEmail", l: "Teacher" }, { k: "status", l: "Status", pill: true }]} filter="status" create="New cohort"
      acts={[{ label: "Archive", show: (r) => r.status !== "Archived", run: () => ({ status: "Archived" }) }]} fields={[{ k: "name", l: "Cohort name", req: true }, { k: "courseId", l: "Course id (e.g. product-design)", req: true }, { k: "start", l: "Start date", type: "date", req: true }, { k: "end", l: "End date", type: "date" }, { k: "deadline", l: "Application deadline", type: "date" }, { k: "schedule", l: "Schedule" }, { k: "format", l: "Format", type: "select", opts: ["Hybrid", "On-site", "Online"] }, { k: "capacity", l: "Capacity", type: "number", req: true }, { k: "teacherEmail", l: "Assigned teacher email", type: "email" }, { k: "status", l: "Registration status", type: "select", opts: ["Open", "Coming soon", "Full", "Closed", "Archived"] }]} prep={(r) => ({ ...r, enrolled: 0 })} />;
    case "admin/students": return <Resource id="users" seed={USERS} title="Students" sub="Students create their own accounts" cols={ucols} filter="status" where={(r) => r.role === "Student"} acts={userActs} fields={upf} noDelete />;
    case "admin/teachers": return <Resource id="users" seed={USERS} title="Teachers" sub="Created by admins; share the default password or let them use Forgot password" cols={ucols} filter="status" where={(r) => r.role === "Teacher"} acts={userActs} create="Add teacher" fields={upf} noDelete
      prep={(r) => ({ ...r, role: "Teacher", status: "Active", avatar: "", password: "Ark-" + Math.random().toString(36).slice(2, 8) })} after={(r, e) => (e ? "Teacher updated (demo data)." : `Teacher account created (demo). Default password: ${r.password}. In production this would be emailed or set via Forgot password.`)} />;
    case "admin/users": return <Resource id="users" seed={USERS} title="Users and roles" sub="Roles are assigned by the system. Admin accounts come from the administrative setup process." cols={ucols} filter="role" acts={userActs} />;
    case "admin/settings": return <Settings />;
    case "teacher/overview": return <TeacherOverview />;
    case "teacher/cohorts": return <TeacherOnly>{({ mine }) => <Resource id="cohorts" seed={COHORTS} title="My cohorts" sub="Schedule, students and capacity" cols={[{ k: "name", l: "Cohort" }, { k: "schedule", l: "Schedule" }, { k: "start", l: "Starts" }, { k: "enrolled", l: "Enrolled" }, { k: "capacity", l: "Capacity" }]} where={(r) => mine.includes(String(r.id))} />}</TeacherOnly>;
    case "teacher/lessons": return <TeacherOnly>{({ mine }) => <Resource id="lessons" seed={LESSONS} title="Lessons and resources" sub="Draft, publish and attach formats (media upload comes with the backend)" cols={[{ k: "title", l: "Lesson" }, { k: "module", l: "Module" }, { k: "format", l: "Format" }, { k: "status", l: "Status", pill: true }]} filter="status" where={(r) => mine.includes(String(r.cohortId))} create="New lesson" acts={[{ label: "Publish", show: (r) => r.status !== "Published", run: () => ({ status: "Published" }) }, { label: "Unpublish", show: (r) => r.status === "Published", run: () => ({ status: "Draft" }) }]} fields={[{ k: "title", l: "Lesson title", req: true }, { k: "module", l: "Module", req: true }, { k: "cohortId", l: "Cohort", type: "select", opts: mine }, { k: "format", l: "Format", type: "select", opts: ["Video", "Audio", "Text", "Document", "Link"] }, { k: "status", l: "Status", type: "select", opts: ["Draft", "Published"] }]} />}</TeacherOnly>;
    case "teacher/submissions": return <TeacherOnly>{({ mine }) => <Resource id="submissions" seed={SUBS} title="Submissions" sub="Grade work and give feedback" cols={[{ k: "student", l: "Student" }, { k: "assignment", l: "Assignment" }, { k: "grade", l: "Grade" }, { k: "status", l: "Status", pill: true }]} filter="status" where={(r) => mine.includes(String(r.cohortId))} noDelete fields={[{ k: "grade", l: "Grade (0–100)", type: "number" }, { k: "feedback", l: "Feedback", type: "textarea", req: true }, { k: "status", l: "Status", type: "select", opts: ["Graded", "Resubmit requested", "Submitted"] }]} after={(r) => { notify(String(r.student), `Feedback on ${r.assignment}`, String(r.feedback)); return "Saved. A demo notification was added for the student."; }} />}</TeacherOnly>;
    case "teacher/attendance": return <TeacherOnly>{({ mine }) => <Resource id="attendance" seed={ATTEND} title="Attendance" sub="Mark Present, Absent or Late" cols={[{ k: "student", l: "Student" }, { k: "session", l: "Session" }, { k: "mark", l: "Mark", pill: true }]} filter="mark" where={(r) => mine.includes(String(r.cohortId))} acts={["Present", "Absent", "Late"].map((m) => ({ label: m, show: (r: Row) => r.mark !== m, run: () => ({ mark: m }) }))} />}</TeacherOnly>;
    case "teacher/students": return <TeacherOnly>{({ mine }) => <Resource id="enrolments" seed={ENROLS} title="Students" sub="Students in your cohorts" cols={[{ k: "studentName", l: "Student" }, { k: "studentEmail", l: "Email" }, { k: "cohortId", l: "Cohort" }, { k: "progress", l: "Progress" }]} where={(r) => mine.includes(String(r.cohortId))} />}</TeacherOnly>;
    case "teacher/calendar": return <TeacherOnly>{({ mine }) => <Resource id="sessions" seed={SESSIONS} title="Teaching calendar" sub="Classes and deadlines" cols={[{ k: "date", l: "Date" }, { k: "time", l: "Time" }, { k: "type", l: "Type" }, { k: "topic", l: "Topic" }, { k: "cohortId", l: "Cohort" }]} filter="type" where={(r) => mine.includes(String(r.cohortId))} />}</TeacherOnly>;
    case "student/overview": return <StudentOverview />;
    case "student/learning": return <Learning />;
    case "student/assignments": return <AssignmentsView />;
    case "student/applications": return <MyApplications />;
    case "student/notifications": return <MyNotifs />;
  }
  return <Empty t="Page not found" s="That section does not exist." />;
}
function AssignmentsView() { const { me, cohortId } = useEnrolled(); if (!cohortId) return <Locked />; return <Resource id="submissions" seed={SUBS} title="Assignments" sub="Submit work and read feedback" cols={[{ k: "assignment", l: "Assignment" }, { k: "status", l: "Status", pill: true }, { k: "grade", l: "Grade" }, { k: "feedback", l: "Feedback" }]} where={(r) => r.student === me} create="Submit work" noDelete fields={[{ k: "assignment", l: "Assignment name", req: true }, { k: "feedback", l: "Link or notes for your teacher" }]} prep={(r) => ({ ...r, student: me, status: "Submitted", grade: "", cohortId, feedback: "" })} after={() => "Submitted (demo data). Your teacher sees it in their Submissions."} />; }
function MyApplications() { const me = useMe(); return <Resource id="applications" seed={APPS} title="Applications" sub="History and next steps" cols={[{ k: "ref", l: "Ref" }, { k: "cohortId", l: "Cohort" }, { k: "date", l: "Date" }, { k: "status", l: "Status", pill: true }]} where={(r) => r.email === me} empty="No applications yet. Browse cohorts and apply." acts={[{ label: "Confirm enrolment", show: (r) => r.status === "Accepted", run: (r) => { const e = enrol(String(r.id)); if (e) { alert(e); return; } return { status: "Enrolled" }; } }]} />; }
function MyNotifs() { const me = useMe(); return <Resource id="notifications" seed={NOTIFS} title="Notifications" cols={[{ k: "title", l: "Title" }, { k: "body", l: "Message" }, { k: "date", l: "Date" }]} where={(r) => r.to === me} empty="You're all caught up." />; }
