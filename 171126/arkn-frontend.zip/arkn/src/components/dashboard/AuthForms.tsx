"use client";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useState, type FormEvent } from "react";
import { read, startSession, write, type Row } from "@/lib/demo";
import { DEMO_PASSWORD, USERS } from "@/data/mock/seed";
const EM = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
const users = () => read<Row[]>("users", USERS);
const Err = ({ m }: { m: string }) => (m ? <p className="err" role="alert">{m}</p> : null);
export function SignIn() {
  const r = useRouter(), [m, setM] = useState("");
  function go(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); const f = new FormData(e.currentTarget), email = String(f.get("email")).trim().toLowerCase(), pw = String(f.get("password"));
    if (!EM.test(email) || !pw) return setM("Enter your email and password.");
    const u = users().find((x) => String(x.email).toLowerCase() === email && x.password === pw);
    if (!u) return setM("Incorrect email or password.");
    if (u.status !== "Active") return setM("This account is not active. Contact the school.");
    const role = String(u.role).toLowerCase(); startSession(role, String(u.email)); r.push("/" + role); // role comes from the account record, never from the form
  }
  return (<form onSubmit={go} className="panel" noValidate><h1>Sign in</h1><label>Email<input name="email" type="email" autoComplete="email" /></label><label>Password<input name="password" type="password" autoComplete="current-password" /></label><Err m={m} />
    <button className="btn" type="submit">Sign in</button><p><Link href="/forgot-password">Forgot password?</Link> · <Link href="/sign-up">Create a student account</Link></p>
    <div className="note"><strong>Demo accounts</strong> (password <code>{DEMO_PASSWORD}</code>): admin@arkon.test, teacher@arkon.test, student@arkon.test. The system picks your dashboard from the account. Data stays in this browser.</div></form>);
}
export function SignUp() {
  const r = useRouter(), [m, setM] = useState("");
  function go(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); const f = new FormData(e.currentTarget), name = String(f.get("name")).trim(), email = String(f.get("email")).trim().toLowerCase(), pw = String(f.get("password")), c = String(f.get("confirm"));
    if (!name) return setM("Enter your full name."); if (!EM.test(email)) return setM("Enter a valid email."); if (pw.length < 8) return setM("Password needs at least 8 characters."); if (pw !== c) return setM("Passwords do not match.");
    const all = users(); if (all.some((x) => String(x.email).toLowerCase() === email)) return setM("An account with this email already exists. Sign in instead.");
    write("users", [...all, { id: "u" + Date.now().toString(36), name, email, phone: "", role: "Student", status: "Active", bio: "", link: "", avatar: "", password: pw }]); // role is always Student
    startSession("student", email); r.push("/student");
  }
  return (<form onSubmit={go} className="panel" noValidate><h1>Create your account</h1><p>Student accounts only. Creating an account does not enrol you in a course. Teachers are added by the school.</p>
    <label>Full name<input name="name" autoComplete="name" /></label><label>Email<input name="email" type="email" autoComplete="email" /></label><label>Password<input name="password" type="password" autoComplete="new-password" /></label><label>Confirm password<input name="confirm" type="password" autoComplete="new-password" /></label><Err m={m} />
    <button className="btn" type="submit">Create account</button><p className="note">Demo: email verification is not simulated yet and the account lives only in this browser.</p><p><Link href="/sign-in">Already have an account?</Link></p></form>);
}
export function Forgot() {
  const [sent, setSent] = useState<string | null>(null), [m, setM] = useState("");
  return sent ? (<div className="panel" role="status"><h1>Check your email</h1><p>If that email has an account, a reset link would be sent. No email is sent in this demo.</p><Link className="btn" href={`/reset-password?email=${encodeURIComponent(sent)}`}>Demo: open the reset link</Link></div>) : (
    <form className="panel" noValidate onSubmit={(e) => { e.preventDefault(); const v = String(new FormData(e.currentTarget).get("email")).trim().toLowerCase(); if (!EM.test(v)) return setM("Enter a valid email."); setSent(v); }}><h1>Forgot password</h1><label>Email<input name="email" type="email" /></label><Err m={m} /><button className="btn" type="submit">Send reset link</button></form>);
}
export function Reset() {
  const email = (useSearchParams().get("email") ?? "").toLowerCase(), r = useRouter(), [m, setM] = useState("");
  function go(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); const f = new FormData(e.currentTarget), pw = String(f.get("password"));
    if (pw.length < 8) return setM("Password needs at least 8 characters."); if (pw !== String(f.get("confirm"))) return setM("Passwords do not match.");
    const all = users(); if (!all.some((x) => String(x.email).toLowerCase() === email)) return setM("This reset link is not valid.");
    write("users", all.map((x) => (String(x.email).toLowerCase() === email ? { ...x, password: pw } : x))); r.push("/sign-in");
  }
  return (<form onSubmit={go} className="panel" noValidate><h1>Set a new password</h1><p>For {email || "unknown account"}</p><label>New password<input name="password" type="password" autoComplete="new-password" /></label><label>Confirm password<input name="confirm" type="password" autoComplete="new-password" /></label><Err m={m} /><button className="btn" type="submit">Update password</button></form>);
}
