"use client";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useState, type FormEvent } from "react";
import { canApply } from "@/domain/admissions";
import type { Application, Cohort, Course } from "@/domain/models";
import { read, useStore, write, type Row } from "@/lib/demo";
import { APPS, COHORTS, COURSES } from "@/data/mock/seed";
const EM = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
const WHY: Record<string, string> = { duplicate: "You have already applied to this cohort with this email.", "cohort-closed": "This cohort is not open.", "deadline-passed": "The deadline has passed.", "cohort-full": "This cohort is full.", "cohort-not-found": "Choose a cohort." };
export function ContactForm() {
  const [done, setDone] = useState(false), [m, setM] = useState("");
  function go(e: FormEvent<HTMLFormElement>) { e.preventDefault(); const f = new FormData(e.currentTarget), email = String(f.get("email")).trim(), msg = String(f.get("message")).trim(); if (!String(f.get("name")).trim() || !EM.test(email) || !msg) return setM("Name, a valid email and a message are required."); write("enquiries", [{ id: "q" + Date.now().toString(36), name: String(f.get("name")), email, message: msg }, ...read<Row[]>("enquiries", [])]); setDone(true); }
  return done ? <p className="note" role="status">Saved in this demo browser only. No message was sent to the school, because no email service is connected yet.</p> : (<form onSubmit={go} className="panel" noValidate><label>Name<input name="name" autoComplete="name" /></label><label>Email<input name="email" type="email" /></label><label>Message<textarea name="message" rows={4} /></label>{m && <p className="err" role="alert">{m}</p>}<button className="btn" type="submit">Send</button></form>);
}
export function ApplyForm() {
  const q = useSearchParams(), [apps, setApps] = useStore<Row[]>("applications", APPS), [cohorts] = useStore<Row[]>("cohorts", COHORTS), [courses] = useStore<Row[]>("courses", COURSES);
  const [cid, setCid] = useState(q.get("cohort") ?? ""), [m, setM] = useState(""), [ref, setRef] = useState("");
  const today = new Date().toISOString().slice(0, 10), conv = (h: Row): Cohort => ({ id: String(h.id), courseId: String(h.courseId), name: String(h.name), status: h.status as Cohort["status"], capacity: Number(h.capacity), enrolled: Number(h.enrolled), deadline: String(h.deadline) || undefined });
  const course = (id: string): Course => { const c = courses.find((x) => x.id === id); return { id, slug: id, title: String(c?.title ?? id), summary: "", published: c?.status === "Published", archived: c?.status === "Archived", mode: "selective", outcomes: [] }; };
  const open = cohorts.filter((h) => { const r = canApply(course(String(h.courseId)), conv(h), today, [], ""); return r.ok; });
  function go(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); const f = new FormData(e.currentTarget), name = String(f.get("name")).trim(), email = String(f.get("email")).trim().toLowerCase(), why = String(f.get("why")).trim(), h = cohorts.find((x) => x.id === cid);
    if (!h) return setM("Choose a cohort."); if (!name) return setM("Enter your full name."); if (!EM.test(email)) return setM("Enter a valid email."); if (why.length < 20) return setM("Tell us a little more about why you want to join (20+ characters).");
    const existing: Application[] = apps.map((a) => ({ id: String(a.id), ref: String(a.ref), applicantEmail: String(a.email), courseId: String(a.courseId), cohortId: String(a.cohortId), status: a.status as Application["status"], history: [] }));
    const r = canApply(course(String(h.courseId)), conv(h), today, existing, email); if (!r.ok) return setM(WHY[r.reason] ?? "You cannot apply to this cohort.");
    const code = "ARK-" + Date.now().toString(36).toUpperCase().slice(-6); setApps([{ id: "a" + Date.now().toString(36), ref: code, name, email, courseId: String(h.courseId), cohortId: String(h.id), status: "Submitted", date: today, why }, ...apps]); setRef(code);
  }
  if (ref) return (<div role="status"><p className="mono">Saved in this demo browser only</p><h2>Application {ref}</h2><p>It is now visible to the demo admin. Next: review, a possible interview, a decision, then confirming your place. Acceptance is not enrolment. The full six-step application is being ported from the prototype.</p><Link className="btn" href="/cohorts">Back to cohorts</Link></div>);
  return (<form onSubmit={go} className="panel" noValidate>{!open.length && <p className="note">No cohort is open for applications right now. <Link href="/cohorts">See cohorts</Link></p>}
    <label>Cohort<select value={cid} onChange={(e) => setCid(e.target.value)}><option value="">Select a cohort</option>{open.map((h) => <option key={String(h.id)} value={String(h.id)}>{String(h.name)} · starts {String(h.start)}</option>)}</select></label>
    <label>Full name<input name="name" autoComplete="name" /></label><label>Email<input name="email" type="email" autoComplete="email" /></label><label>Why do you want to join?<textarea name="why" rows={4} /></label>{m && <p className="err" role="alert">{m}</p>}<button className="btn" type="submit" disabled={!open.length}>Submit application</button></form>);
}
