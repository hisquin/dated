"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { endSession } from "@/lib/demo";
type Item = { l: string; h?: string; kids?: { l: string; h: string }[] };
const NAV: Record<string, Item[]> = {
  admin: [{ l: "Overview", h: "" }, { l: "Admissions", kids: [{ l: "Applications", h: "applications" }, { l: "Enrolments", h: "enrolments" }] }, { l: "Academics", kids: [{ l: "Courses", h: "courses" }, { l: "Cohorts", h: "cohorts" }] }, { l: "People", kids: [{ l: "Students", h: "students" }, { l: "Teachers", h: "teachers" }, { l: "Users & roles", h: "users" }] }, { l: "Announcements", h: "announcements" }, { l: "Settings", h: "settings" }],
  teacher: [{ l: "Overview", h: "" }, { l: "Cohorts", h: "cohorts" }, { l: "Teaching", kids: [{ l: "Lessons", h: "lessons" }, { l: "Submissions", h: "submissions" }, { l: "Attendance", h: "attendance" }] }, { l: "Students", h: "students" }, { l: "Calendar", h: "calendar" }, { l: "Announcements", h: "announcements" }],
  student: [{ l: "Overview", h: "" }, { l: "Learning", kids: [{ l: "My learning", h: "learning" }, { l: "Assignments", h: "assignments" }] }, { l: "Applications", h: "applications" }, { l: "Notifications", h: "notifications" }],
};
export function Shell({ role, children }: { role: string; children: React.ReactNode }) {
  const [open, setOpen] = useState(false), r = useRouter(), base = "/" + role;
  return (<><header className="dash"><div className="wrap bar"><Link href={base} className="logo">ARKON/{role.toUpperCase()}</Link>
    <nav id="dn" className={open ? "open" : ""} aria-label={`${role} navigation`}>{NAV[role].map((i) => i.kids ? (<details key={i.l}><summary>{i.l}</summary><div className="menu">{i.kids.map((k) => <Link key={k.h} href={`${base}/${k.h}`} onClick={() => setOpen(false)}>{k.l}</Link>)}</div></details>) : <Link key={i.l} href={i.h ? `${base}/${i.h}` : base} onClick={() => setOpen(false)}>{i.l}</Link>)}</nav>
    <span style={{ flex: 1 }} /><Link href={`${base}/profile`}>Profile</Link><button className="btn alt sm" onClick={() => { endSession(); r.push("/sign-in"); }}>Sign out</button>
    <button className="btn alt sm burger" aria-expanded={open} aria-controls="dn" onClick={() => setOpen(!open)}>Menu</button></div></header>
    <div className="demo2">Frontend demo: data lives in this browser only. Nothing is saved to a server or sent.</div><main className="wrap">{children}</main></>);
}
