"use client";
import { useState, type FormEvent, type ReactNode } from "react";
import { useStore, type Row } from "@/lib/demo";
export type Field = { k: string; l: string; type?: "text" | "textarea" | "select" | "date" | "number" | "email"; opts?: string[]; req?: boolean };
export type Act = { label: string; show?: (r: Row) => boolean; run: (r: Row) => Partial<Row> | void };
export function Pill({ s }: { s: string }) { const t = /active|accepted|enrolled|open|published|graded|present/i.test(s) ? "g" : /pending|review|interview|draft|waitlist|submitted|soon|late|resubmit/i.test(s) ? "o" : "m"; return <span className={`pl t-${t}`}>{s}</span>; }
export const Stats = ({ items }: { items: [string, string | number][] }) => (<div className="stats">{items.map(([l, v]) => (<div key={l}><span className="mono">{l}</span><b>{v}</b></div>))}</div>);
export const Head = ({ t, s, children }: { t: string; s?: string; children?: ReactNode }) => (<div className="ph"><div><h1>{t}</h1>{s && <p>{s}</p>}</div>{children}</div>);
export const Empty = ({ t, s }: { t: string; s: string }) => (<div className="empty"><strong>{t}</strong><p>{s}</p></div>);
type P = { id: string; seed: Row[]; title: string; sub?: string; cols: { k: string; l: string; pill?: boolean }[]; fields?: Field[]; filter?: string; acts?: Act[]; create?: string; prep?: (r: Row) => Row; after?: (r: Row, edit: boolean) => string; where?: (r: Row) => boolean; noDelete?: boolean; empty?: string; top?: ReactNode };
export function Resource(p: P) {
  const [rows, setRows] = useStore<Row[]>(p.id, p.seed);
  const [q, setQ] = useState(""), [f, setF] = useState(""), [ed, setEd] = useState<Row | null>(null), [open, setOpen] = useState(false), [err, setErr] = useState<Record<string, string>>({}), [msg, setMsg] = useState("");
  const base = rows.filter((r) => !p.where || p.where(r));
  const shown = base.filter((r) => (!f || String(r[p.filter ?? ""]) === f) && Object.values(r).join(" ").toLowerCase().includes(q.toLowerCase()));
  const kinds = p.filter ? Array.from(new Set(base.map((r) => String(r[p.filter!])))) : [];
  function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); const fd = new FormData(e.currentTarget), v: Row = { id: ed?.id ?? "r" + Date.now().toString(36) }, er: Record<string, string> = {};
    for (const x of p.fields ?? []) { const raw = String(fd.get(x.k) ?? "").trim(); if (x.req && !raw) er[x.k] = "Required"; else if (x.type === "email" && raw && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(raw)) er[x.k] = "Enter a valid email"; v[x.k] = x.type === "number" ? Number(raw) : raw; }
    setErr(er); if (Object.keys(er).length) return;
    const row: Row = ed ? { ...ed, ...v } : p.prep ? p.prep(v) : v;
    setRows(ed ? rows.map((r) => (r.id === ed.id ? row : r)) : [row, ...rows]); setMsg(p.after ? p.after(row, !!ed) : "Saved (demo data)."); setOpen(false); setEd(null);
  }
  const canEdit = !!p.fields;
  return (<section>
    <Head t={p.title} s={p.sub}>{p.create && p.fields && <button className="btn" onClick={() => { setEd(null); setErr({}); setOpen(true); }}>{p.create}</button>}</Head>
    {msg && <p className="note" role="status">{msg}</p>}{p.top}
    {open && p.fields && (<form key={ed?.id ?? "new"} onSubmit={submit} noValidate className="panel"><h2>{ed ? "Edit" : p.create}</h2>
      {p.fields.map((x) => (<label key={x.k}>{x.l}{x.req ? "" : " (optional)"}
        {x.type === "textarea" ? <textarea name={x.k} rows={3} defaultValue={String(ed?.[x.k] ?? "")} /> : x.type === "select" ? <select name={x.k} defaultValue={String(ed?.[x.k] ?? x.opts?.[0] ?? "")}>{x.opts?.map((o) => <option key={o}>{o}</option>)}</select> : <input name={x.k} type={x.type ?? "text"} defaultValue={String(ed?.[x.k] ?? "")} />}
        {err[x.k] && <span className="err">{err[x.k]}</span>}</label>))}
      <div className="row2"><button className="btn" type="submit">Save</button><button type="button" className="btn alt" onClick={() => { setOpen(false); setEd(null); }}>Cancel</button></div></form>)}
    <div className="bar2"><input type="search" placeholder="Search…" aria-label="Search" value={q} onChange={(e) => setQ(e.target.value)} />{kinds.length > 1 && <select aria-label="Filter" value={f} onChange={(e) => setF(e.target.value)}><option value="">All</option>{kinds.map((k) => <option key={k}>{k}</option>)}</select>}</div>
    {shown.length === 0 ? <Empty t={base.length ? "No matches" : "Nothing here yet"} s={p.empty ?? (base.length ? "Try a different search or filter." : "Items will appear here.")} /> : (
      <div className="tw"><table><thead><tr>{p.cols.map((c) => <th key={c.k}>{c.l}</th>)}<th>Actions</th></tr></thead><tbody>{shown.map((r) => (<tr key={r.id}>
        {p.cols.map((c) => <td key={c.k} data-l={c.l}>{c.pill ? <Pill s={String(r[c.k])} /> : String(r[c.k] ?? "—") || "—"}</td>)}
        <td data-l="Actions"><div className="row2">
          {p.acts?.filter((a) => !a.show || a.show(r)).map((a) => <button key={a.label} className="btn alt sm" onClick={() => { const patch = a.run(r); if (patch) setRows(rows.map((x) => (x.id === r.id ? { ...x, ...patch } : x))); }}>{a.label}</button>)}
          {canEdit && <button className="btn alt sm" onClick={() => { setEd(r); setErr({}); setOpen(true); }}>Edit</button>}
          {canEdit && !p.noDelete && <button className="btn alt sm" onClick={() => { if (confirm("Delete this item? (demo data)")) setRows(rows.filter((x) => x.id !== r.id)); }}>Delete</button>}</div></td></tr>))}</tbody></table></div>)}
  </section>);
}
