# ARKON SCHOOL — Next.js frontend (demo data only)

Frontend phase. No backend, no real auth, no email, no file storage. Everything saved in the UI lives in the browser (localStorage + a plain cookie) and is labelled as demo.

## Run
    npm install next react react-dom
    npm install -D typescript @types/react @types/node @types/react-dom
    npm run dev          # http://localhost:3000
    npm test             # 9 domain tests (these were run and pass)
    npm run typecheck && npm run build

## Demo accounts (password `arkon-demo`)
admin@arkon.test · teacher@arkon.test · student@arkon.test
Sign-in has no role field: the dashboard comes from the account record. Students can sign up (always Student). Teachers are created by an admin (Admin > People > Teachers > Add teacher shows a default password), then sign in with it or use Forgot password.

## Routes
Public: / /courses /courses/[slug] /cohorts /cohorts/[id] /about /studio /approach /faq /contact /apply
Auth: /sign-in /sign-up /forgot-password /reset-password (noindex)
Admin /admin[/applications|enrolments|courses|cohorts|students|teachers|users|announcements|settings|profile]
Teacher /teacher[/cohorts|lessons|submissions|attendance|students|calendar|announcements|profile]
Student /student[/learning|assignments|applications|notifications|profile]
Dashboards are noindex; the role guard trusts a browser cookie (demo only).

## Status — VERIFIED vs NOT
Verified: domain rules via `npm test`.
NOT verified (no network/browser where this was written): install, typecheck, build, any rendering, every dashboard interaction. Expect small type errors on first build; fix and re-run.

## Not built yet
Six-step application wizard (prototype exists in the Artifact; /apply here is a short single form), email verification, multi-format lesson player (watch/listen/read, transcripts), module-to-lesson curriculum builder with reordering, assignment authoring with deadlines, calendar creation, classroom UI, real media/files, reports, teacher-to-cohort assignment UI beyond a text field, tests for the UI.
