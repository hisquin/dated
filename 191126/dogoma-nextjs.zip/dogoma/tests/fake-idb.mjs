/** Minimal in-memory IndexedDB: transactions buffer writes and commit only on success (so aborts roll back); failures can be injected. */
export function fakeIDB({ver=0,stores=[],data={}}={}){const S=new Set(stores),D={};for(const n of stores)D[n]=new Map(Object.entries(data[n]??{}));let V=ver,failFn=null;
 const db={objectStoreNames:{contains:n=>S.has(n)},createObjectStore(n){S.add(n);D[n]??=new Map()},close(){},
  transaction(names){names=[].concat(names);const sh=new Map(names.map(n=>[n,new Map(D[n])])),tx={};let pend=0,dead=false;
   const fin=()=>{if(!dead&&pend===0){names.forEach(n=>{D[n]=sh.get(n)});tx.oncomplete&&tx.oncomplete()}}; // commit immediately, like serialized real transactions
   const req=f=>{const r={};pend++;setTimeout(()=>{if(dead)return;try{r.result=f();r.onsuccess&&r.onsuccess()}catch(e){dead=true;tx.error=e;r.error=e;r.onerror&&r.onerror();tx.onabort&&tx.onabort();return}pend--;fin()},0);return r};
   tx.objectStore=n=>({get:k=>req(()=>sh.get(n).get(k)),getAll:()=>req(()=>[...sh.get(n).values()]),put:v=>req(()=>{if(failFn&&failFn(n,v))throw Object.assign(new Error('quota'),{name:'QuotaExceededError'});sh.get(n).set(v.id,JSON.parse(JSON.stringify(v)))}),delete:k=>req(()=>{sh.get(n).delete(k)})});
   tx.abort=()=>{dead=true;tx.onabort&&tx.onabort()};return tx}};
 const indexedDB={open(_n,v){const r={};setTimeout(()=>{r.result=db;if(v&&v>V){const old=V;V=v;r.onupgradeneeded&&r.onupgradeneeded({oldVersion:old})}r.onsuccess&&r.onsuccess()},0);return r}};
 return{indexedDB,data:D,fail:f=>{failFn=f},version:()=>V}}
