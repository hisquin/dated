import learning from '@/data/learning.json';
import daily from '@/data/daily.json';
import {validateItem,type DailyItem} from '@/core/daily';
import type {Article,Subject,Topic} from '@/core/learning';
import type {DailyRepository,LearningRepository} from './repositories';
const L=learning as unknown as {subjects:Subject[];topics:Topic[];articles:Article[]};
class LocalLearning implements LearningRepository{async getSubjects(){return L.subjects}async getTopics(s?:string){return s?L.topics.filter(t=>t.subjectId===s):L.topics}async getLearningContent(id:string){return L.articles.filter(a=>a.topicId===id&&a.status==='published'&&a.sources.length>0)}}
class LocalDaily implements DailyRepository{async getAll(){return(daily as unknown as DailyItem[]).filter(i=>!validateItem(i))}}
export const getLearning=():LearningRepository=>new LocalLearning(),getDaily=():DailyRepository=>new LocalDaily();
