export type OutboxState='pending'|'failed'|'rejected'|'synced';
/** pending: queued. failed: retrying. rejected: refused by the server, never retried. synced: stored on the server but NOT verified (no client record is ever "verified"). */
export interface OutboxRec{id:string;guestId:string;mode:'count'|'time';score:number;attempted:number;correct:number;startedAt:number;endedAt:number;offline:boolean;state:OutboxState;tries:number;lastError?:string;syncedAt?:number}
export interface SyncError{code?:string;status?:number;message:string}
export interface SyncDeps{list():Promise<OutboxRec[]>;save(r:OutboxRec):Promise<unknown>;remove(id:string):Promise<unknown>;insert(r:OutboxRec):Promise<SyncError|null>}
export interface SyncResult{synced:number;failed:number;skipped:number;rejected:number;auth:number}
export const MAX_TRIES=8,KEEP_SYNCED_MS=14*864e5;
export type Outcome='ok'|'dup'|'auth'|'rejected'|'retry';
export function classify(e:SyncError|null):Outcome{if(!e)return'ok';if(e.code==='23505'||e.status===409)return'dup';if(e.status===401||e.code==='PGRST301'||e.code==='PGRST303'||/jwt/i.test(e.message))return'auth';
 if(['42501','23514','23502','22P02','22007'].includes(e.code??'')||(e.status!==undefined&&e.status>=400&&e.status<500&&![408,429].includes(e.status)))return'rejected';return'retry'}
let running:Promise<SyncResult>|null=null;
/** Idempotent (the session id is the primary key) and single-flight. Failed records are kept; auth errors never burn retries. */
export function runSync(d:SyncDeps,force=false,now=Date.now()):Promise<SyncResult>{if(running)return running;
 running=(async()=>{const out:SyncResult={synced:0,failed:0,skipped:0,rejected:0,auth:0};
  for(const r of await d.list()){if(r.state==='synced'){if(r.syncedAt&&now-r.syncedAt>KEEP_SYNCED_MS)await d.remove(r.id);continue}if(r.state==='rejected')continue;if(r.tries>=MAX_TRIES&&!force){out.skipped++;continue}
   let err:SyncError|null;try{err=await d.insert(r)}catch(e){err={message:e instanceof Error?e.message:'network error'}}
   const o=classify(err);if(o==='ok'||o==='dup'){await d.save({...r,state:'synced',syncedAt:now,lastError:undefined});out.synced++}
   else if(o==='auth'){out.auth++;break}else if(o==='rejected'){await d.save({...r,state:'rejected',lastError:err?.message});out.rejected++}
   else{await d.save({...r,state:'failed',tries:(force?0:r.tries)+1,lastError:err?.message});out.failed++}}return out})().finally(()=>{running=null});return running}
