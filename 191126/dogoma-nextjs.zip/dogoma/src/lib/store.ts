import {validateQuestion} from '../core/handlers';
import type {Sess} from '../core/session';
import {read,readAll,transact} from './idb';
import type {OutboxRec} from './sync-core';
export type NewResult=Omit<OutboxRec,'tries'|'state'|'syncedAt'|'lastError'>;
/** Atomically queues the result and deletes the active session. The session id is the outbox key, so finishing twice cannot create two results or reset a synced one. */
export async function finishSession(r:NewResult){await transact(['outbox','session'],'readwrite',s=>{const g=s.outbox.get(r.id);g.onsuccess=()=>{if(!g.result)s.outbox.put({...r,tries:0,state:'pending'})};s.session.delete('active')});if(typeof dispatchEvent==='function')dispatchEvent(new Event('dogoma:outbox'))}
export const saveSession=async(s:Sess)=>{try{await transact(['session'],'readwrite',x=>{x.session.put({id:'active',data:s})});return true}catch{return false}};
export const clearSession=()=>transact(['session'],'readwrite',x=>{x.session.delete('active')}).catch(()=>{});
export async function loadSession():Promise<Sess|undefined>{try{const d=(await read<{data:Sess}>('session','active'))?.data;
 if(d&&typeof d.sid==='string'&&Array.isArray(d.qs)&&Array.isArray(d.log)&&Number.isInteger(d.i)&&d.i<d.qs.length&&['ask','feedback','done'].includes(d.phase)&&d.qs.every(q=>!validateQuestion(q)))return d;if(d)await clearSession()}catch{/* unreadable */}return undefined}
export const listOutbox=()=>readAll<OutboxRec>('outbox').catch(()=>[] as OutboxRec[]);
export const putOutbox=(r:OutboxRec)=>transact(['outbox'],'readwrite',s=>{s.outbox.put(r)});
export const removeOutbox=(id:string)=>transact(['outbox'],'readwrite',s=>{s.outbox.delete(id)});
export const setMeta=(v:{id:string}&Record<string,unknown>)=>transact(['meta'],'readwrite',s=>{s.meta.put(v)}).catch(()=>{});
