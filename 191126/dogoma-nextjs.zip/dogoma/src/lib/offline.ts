'use client';
import {useEffect,useState} from 'react';
import type {Question} from '@/core/types';
import {loadQuestionSet,saveQuestionSet} from './qstore';
/** Live questions replace the saved set only if they validate and the swap commits; otherwise the last known good set stays. */
export function useQuestionSet(srv:Question[],failed:boolean){const [st,setSt]=useState<{questions:Question[];source:'live'|'cache'|'none';cachedAt?:number}>({questions:srv,source:srv.length?'live':'none'});
 useEffect(()=>{let off=false;(async()=>{if(srv.length&&!failed){const r=await saveQuestionSet(srv);if(!r.ok)dispatchEvent(new CustomEvent('dogoma:storage',{detail:r.reason}));if(!off)setSt({questions:srv,source:'live',cachedAt:Date.now()});return}
  const s=await loadQuestionSet();if(!off&&s)setSt({questions:s.items,source:'cache',cachedAt:s.at})})();return()=>{off=true}},[srv,failed]);return st}
