import {validateQuestion} from '../core/handlers';
import type {Question} from '../core/types';
import {read,transact} from './idb';
export interface SavedSet{id:'current'|'previous';at:number;count:number;hash:string;items:Question[]}
const hash=(s:string)=>{let h=5381;for(let i=0;i<s.length;i++)h=((h<<5)+h+s.charCodeAt(i))|0;return String(h)};
export const fingerprint=(items:Question[])=>hash(JSON.stringify(items));
export const validateSet=(items:unknown):items is Question[]=>Array.isArray(items)&&items.length>0&&items.every(q=>!!q&&typeof q==='object'&&typeof (q as Question).id==='string'&&!validateQuestion(q as Question));
const intact=(r:SavedSet|undefined):r is SavedSet=>!!r&&validateSet(r.items)&&r.count===r.items.length&&r.hash===fingerprint(r.items);
const quota=(e:unknown)=>(e as {name?:string})?.name==='QuotaExceededError';
export type SaveResult={ok:true}|{ok:false;reason:'invalid'|'quota'|'unavailable'};
/** One transaction: the intact current set becomes "previous" and the new set becomes "current", or nothing changes. */
export async function saveQuestionSet(items:unknown,at=Date.now()):Promise<SaveResult>{if(!validateSet(items))return{ok:false,reason:'invalid'};
 const rec:SavedSet={id:'current',at,count:items.length,hash:fingerprint(items),items};
 const attempt=(keepPrev:boolean)=>transact(['questions'],'readwrite',s=>{const g=s.questions.get('current');g.onsuccess=()=>{const c=g.result as SavedSet|undefined;if(keepPrev&&intact(c))s.questions.put({...c,id:'previous'});if(!keepPrev)s.questions.delete('previous');s.questions.put(rec)}});
 try{await attempt(true);return{ok:true}}catch(e){if(!quota(e))return{ok:false,reason:'unavailable'};try{await attempt(false);return{ok:true}}catch{return{ok:false,reason:'quota'}}}}
/** Last known good set: current if intact, else previous. Corrupt records are deleted. */
export async function loadQuestionSet():Promise<{items:Question[];at:number;from:'current'|'previous'}|undefined>{try{for(const k of['current','previous'] as const){const r=await read<SavedSet>('questions',k);if(intact(r))return{items:r.items,at:r.at,from:k};if(r)await transact(['questions'],'readwrite',s=>{s.questions.delete(k)}).catch(()=>{})}}catch{/* storage unavailable */}return undefined}
