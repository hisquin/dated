export type Availability='installed'|'native'|'ios-safari'|'ios-other'|'desktop'|'unavailable';
export interface InstallEnv{standalone:boolean;canPrompt:boolean;ios:boolean;iosSafari:boolean;mobile:boolean}
export const availability=(e:InstallEnv,installedFlag=false):Availability=>e.standalone||installedFlag?'installed':e.canPrompt?'native':e.ios?(e.iosSafari?'ios-safari':'ios-other'):!e.mobile?'desktop':'unavailable';
export interface Memory{shownAt?:number;dismissedAt?:number;dismissals:number;acceptedAt?:number;installedAt?:number}
export const COOLDOWN_MS=3*864e5,SESSION_MS=30*60e3,MAX_DISMISSALS=3;
export type InstallState='installed'|'unavailable'|'accepted'|'dismissed'|'invited'|'ios-manual'|'available'|'first-visit';
export const installState=(a:Availability,m:Memory):InstallState=>a==='installed'||m.installedAt?'installed':a==='unavailable'?'unavailable':m.acceptedAt?'accepted':m.dismissedAt?'dismissed':m.shownAt?'invited':a.startsWith('ios')?'ios-manual':a==='native'?'available':'first-visit';
/** Strong on first visit, quiet afterwards: not on refresh within 30 minutes, not within 3 days of a dismissal, never after 3 dismissals (the manual install option stays in Profile). */
export function shouldInvite(a:Availability,m:Memory,now:number){if(a==='installed'||a==='unavailable'||m.installedAt||m.acceptedAt||m.dismissals>=MAX_DISMISSALS)return false;if(m.dismissedAt&&now-m.dismissedAt<COOLDOWN_MS)return false;return !(m.shownAt&&now-m.shownAt<SESSION_MS)}
export const onShown=(m:Memory,now:number):Memory=>({...m,shownAt:now}),onDismiss=(m:Memory,now:number):Memory=>({...m,dismissedAt:now,dismissals:m.dismissals+1}),onAccept=(m:Memory,now:number):Memory=>({...m,acceptedAt:now}),onInstalled=(m:Memory,now:number):Memory=>({...m,installedAt:now});
const priv=(h:string)=>/^(localhost|127\.|0\.0\.0\.0|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|\[::1\])/.test(h)||h.endsWith('.local');
/** The QR code must open the real public address: NEXT_PUBLIC_APP_URL, else the current origin if it is public. Never localhost. */
export function publicAppUrl(envUrl:string|undefined,origin:string):{url:string|null;reason?:string}{let u:URL;try{u=new URL(envUrl?.trim()||origin)}catch{return{url:null,reason:'invalid URL'}}
 if(!/^https?:$/.test(u.protocol))return{url:null,reason:'URL must be http or https'};if(priv(u.hostname))return{url:null,reason:'Set NEXT_PUBLIC_APP_URL to the public address (this one is localhost or a private network).'};return{url:u.origin+(u.pathname==='/'?'':u.pathname.replace(/\/$/,''))}}
