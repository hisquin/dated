export const DB_NAME='dogoma-offline',DB_VER=2;
export const STORES=['questions','outbox','meta','session'] as const;
export type St=typeof STORES[number];
let dbp:Promise<IDBDatabase>|null=null;
/** Upgrades are additive: missing stores are created and existing data is never dropped. */
function open():Promise<IDBDatabase>{if(!dbp){dbp=new Promise((res,rej)=>{const r=indexedDB.open(DB_NAME,DB_VER);
 r.onupgradeneeded=()=>{const d=r.result;for(const s of STORES)if(!d.objectStoreNames.contains(s))d.createObjectStore(s,{keyPath:'id'})};
 r.onblocked=()=>rej(new Error('database blocked by another tab'));r.onerror=()=>rej(r.error);
 r.onsuccess=()=>{const d=r.result;d.onversionchange=()=>{d.close();dbp=null};d.onclose=()=>{dbp=null};res(d)}});dbp.catch(()=>{dbp=null})}return dbp}
/** Resolves only when the whole transaction commits; any failure aborts it and nothing is written. */
export function transact(stores:St[],mode:IDBTransactionMode,fn:(s:Record<St,IDBObjectStore>)=>void):Promise<void>{return open().then(db=>new Promise<void>((res,rej)=>{const tx=db.transaction(stores,mode);tx.oncomplete=()=>res();tx.onabort=()=>rej(tx.error??new Error('transaction aborted'));
 try{const o={} as Record<St,IDBObjectStore>;for(const n of stores)o[n]=tx.objectStore(n);fn(o)}catch(e){try{tx.abort()}catch{/* already finished */}rej(e)}}))}
export const read=async<T,>(s:St,k:string):Promise<T|undefined>=>{const db=await open();return new Promise((res,rej)=>{const r=db.transaction(s,'readonly').objectStore(s).get(k);r.onsuccess=()=>res(r.result as T|undefined);r.onerror=()=>rej(r.error)})};
export const readAll=async<T,>(s:St):Promise<T[]>=>{const db=await open();return new Promise((res,rej)=>{const r=db.transaction(s,'readonly').objectStore(s).getAll();r.onsuccess=()=>res(r.result as T[]);r.onerror=()=>rej(r.error)})};
