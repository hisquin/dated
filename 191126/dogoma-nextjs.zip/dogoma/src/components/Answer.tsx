'use client';
import {useMemo,useState,type MutableRefObject} from 'react';
import {shuf} from '@/lib/guest';
import type {Answer as A,Question} from '@/core/types';
interface P{q:Question;locked:boolean;picked:A;onSubmit:(a:A)=>void;getRef:MutableRefObject<()=>A>}
/** One input per question type. Add a case here when registering a new type. */
export default function Answer({q,locked,picked,onSubmit,getRef}:P){
 const [text,setText]=useState(''),[seq,setSeq]=useState<string[]>([]),[sel,setSel]=useState<string[]>((q.pairs??[]).map(()=>''));
 const opts=useMemo(()=>q.type==='true_false'?['True','False']:shuf(q.options??[]),[q]),rights=useMemo(()=>shuf((q.pairs??[]).map(p=>p[1])),[q]);
 if(q.type==='multiple_choice'||q.type==='true_false'){getRef.current=()=>null;
  return <div>{opts.map(o=><button key={o} type="button" disabled={locked} className={'opt'+(locked?(o===q.correct_answer?' ok':o===picked?' bad':''):'')} onClick={()=>onSubmit(o)}>{o}</button>)}</div>}
 if(q.type==='fill_blank'||q.type==='short_answer'){getRef.current=()=>text;const go=()=>{if(text.trim())onSubmit(text)};
  return <div className="trow"><input autoFocus type="text" inputMode="text" enterKeyHint="send" autoComplete="off" autoCapitalize="off" autoCorrect="off" spellCheck={false} aria-label="Your answer" value={text} disabled={locked} onChange={e=>setText(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'&&!e.nativeEvent.isComposing){e.preventDefault();go()}}}/><button type="button" className="btn" disabled={locked} onClick={go}>Submit</button></div>}
 if(q.type==='chronological_order'){getRef.current=()=>seq;const n=q.options!.length;
  return <div><p className="mu">Tap in order, earliest first.</p>{opts.map(o=>{const i=seq.indexOf(o);return <button key={o} type="button" className="opt" disabled={locked||i>=0} onClick={()=>{const s=[...seq,o];setSeq(s);if(s.length===n)onSubmit(s)}}>{i>=0?`${i+1}. `:''}{o}</button>})}<button type="button" className="lnk" disabled={locked} onClick={()=>setSeq([])}>Start over</button></div>}
 getRef.current=()=>sel;
 return <div>{q.pairs!.map((p,i)=><label key={p[0]} className="mrow"><span>{p[0]}</span><select disabled={locked} value={sel[i]} onChange={e=>setSel(sel.map((v,j)=>j===i?e.target.value:v))}><option value="">Choose…</option>{rights.map(r=><option key={r}>{r}</option>)}</select></label>)}<button type="button" className="btn" disabled={locked} onClick={()=>onSubmit(sel)}>Submit</button></div>}
