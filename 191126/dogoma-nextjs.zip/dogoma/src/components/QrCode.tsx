'use client';
import {useEffect,useState} from 'react';
import QRCode from 'qrcode';
export default function QrCode({url}:{url:string}){const [svg,setSvg]=useState('');
 useEffect(()=>{QRCode.toString(url,{type:'svg',margin:1,errorCorrectionLevel:'M',color:{dark:'#171A19',light:'#F5F2EA'}}).then(setSvg).catch(()=>setSvg(''))},[url]);
 return svg?<div className="qr" role="img" aria-label={`QR code that opens ${url}`} dangerouslySetInnerHTML={{__html:svg}}/>:null}
