'use client';
import {useEffect,useMemo,useReducer,useRef,useState} from 'react';
import Link from 'next/link';
import Answer from './Answer';
import {analyze,categoryTally} from '@/core/analytics';
import {CFG} from '@/core/config';
import {HANDLERS} from '@/core/handlers';
import {qLimit} from '@/core/scoring';
import {advance,create,cur,recover,submit,tick,type Sess} from '@/core/session';
import {shuf,useGuest} from '@/lib/guest';
import {useQuestionSet} from '@/lib/offline';
import {clearSession,finishSession,loadSession,saveSession} from '@/lib/store';
import type {Answer as A,Question} from '@/core/types';
type Mode='count'|'time';
const cap=(s:string)=>s[0].toUpperCase()+s.slice(1),fmt=(ms:number)=>{const s=Math.max(0,Math.ceil(ms/1e3));return Math.floor(s/60)+':'+String(s%60).padStart(2,'0')};
export default function App({questions:srv,loadError}:{questions:Question[];loadError?:string|null}){
 const {questions,source,cachedAt}=useQuestionSet(srv,!!loadError);
 const [view,setView]=useState<'home'|'game'|'result'>('home'),[cat,setCat]=useState('all'),[mode,setMode]=useState<Mode>('count'),[count,setCount]=useState(15),[dur,setDur]=useState(120);
 const S=useRef<Sess|null>(null),getA=useRef<()=>A>(()=>null),api=useRef({tk:()=>{}}),[,bump]=useReducer((x:number)=>x+1,0),guest=useGuest();
 const cats=useMemo(()=>[...new Set(questions.map(q=>q.category))],[questions]),pool=useMemo(()=>questions.filter(q=>cat==='all'||q.category===cat),[questions,cat]);
 const [resume,setResume]=useState<Sess|null>(null);
 /* Session transitions are pure functions of (session, timestamp). Every change is persisted, so a reload or crash recovers the same deadlines. */
 const finalize=(s:Sess)=>{const ok=s.log.filter(x=>x.res==='ok').length;guest.record({sid:s.sid,cat:categoryTally(s.log,s.qs),t:Date.now(),mode:s.mode,score:s.score,ok,n:s.log.length});void finishSession({id:s.sid,guestId:s.gid,mode:s.mode,score:s.score,attempted:s.log.length,correct:ok,startedAt:s.t0,endedAt:s.t1,offline:s.offline});setView('result')};
 const step=(n:Sess)=>{S.current=n;if(n.phase==='done')finalize(n);else void saveSession(n);bump()};
 const resolve=(a:A)=>{const s=S.current;if(s)step(submit(s,a,Date.now(),false))};
 const next=()=>{const s=S.current;if(s&&s.phase==='feedback')step(advance(s,Date.now()))};
 api.current.tk=()=>{const s=S.current;if(!s||s.phase==='done')return;const n=tick(s,Date.now(),getA.current());if(n!==s)step(n);else bump()};
 useEffect(()=>{if(view!=='game')return;const id=setInterval(()=>api.current.tk(),200);return()=>clearInterval(id)},[view]);
 useEffect(()=>{document.body.dataset.playing=view==='game'?'1':'';return()=>{document.body.dataset.playing=''}},[view]);
 useEffect(()=>{void loadSession().then(s=>{if(!s)return;const r=recover(s,Date.now());if(r.phase==='done'){S.current=r;finalize(r)}else setResume(r)})},[]); // eslint-disable-line react-hooks/exhaustive-deps
 const start=()=>{if(!pool.length)return;const n=Date.now();setResume(null);step(advance(create({mode,qs:shuf(pool).slice(0,mode==='time'?pool.length:count),durSec:dur,now:n,sid:crypto.randomUUID(),gid:guest.d.id,offline:!navigator.onLine||source==='cache'}),n));setView('game')};
 const doResume=()=>{if(!resume)return;const r=recover(resume,Date.now());setResume(null);step(r);if(r.phase!=='done')setView('game')};
 const discard=()=>{setResume(null);void clearSession()};
 const quit=()=>{S.current=null;void clearSession();setView('home')};
 const chip=(on:boolean,label:string,f:()=>void)=><button key={label} type="button" className="chip" aria-pressed={on} onClick={f}>{label}</button>;

 if(view==='home'){const t=mode==='time',g=guest.d.games,best=g.reduce((m,x)=>Math.max(m,x.score),0);
  return <><section className="hero"><p className="kick">DOGOMA / Know Rwanda</p><h1>Know where you come from.</h1><p className="mu">Faster correct answers earn more points. No account needed.</p></section>
  {resume&&<div className="fb" role="status"><b>You have a game in progress</b><p>Its timers kept running on the clock while you were away. Time already used is not given back.</p><div className="row"><button type="button" className="btn" onClick={doResume}>Resume</button><button type="button" className="chip" onClick={discard}>Discard</button></div></div>}{source==='cache'&&<p className="mu" role="status">Playing saved questions from {cachedAt?new Date(cachedAt).toLocaleDateString():'an earlier visit'}. They refresh when you’re back online.</p>}{loadError&&source!=='cache'&&<p role="alert">Could not load questions and none are saved on this device. Reconnect and refresh.</p>}
  <div className="grp"><p>What do you want to test your knowledge on?</p>{chip(cat==='all','Mixed knowledge ('+questions.length+')',()=>setCat('all'))}{cats.map(c=>chip(cat===c,cap(c)+' ('+questions.filter(q=>q.category===c).length+')',()=>setCat(c)))}</div>
  <div className="grp"><p>How do you want to play?</p>{chip(!t,'Set number of questions',()=>setMode('count'))}{chip(t,'Against the clock',()=>setMode('time'))}</div>
  <div className="grp"><p>{t?'Time limit':'Number of questions'}</p>{t?CFG.durations.map(d=>chip(dur===d,d/60+(d===60?' minute':' minutes'),()=>setDur(d))):CFG.counts.map(c=>chip(count===c,String(c),()=>setCount(c)))}</div>
  <div className="row"><button type="button" className="btn" disabled={!pool.length} onClick={start}>Start game</button><span className="mu">{!pool.length?'No published questions yet for this topic.':t?'Answer as many as you can. Each question has its own time limit.':pool.length<count?`Only ${pool.length} questions available, so this game will have ${pool.length}.`:''}</span></div>
  <div className="stats"><span><b>{g.length}</b>games played</span><span><b>{best}</b>best score</span><span><b>{guest.d.xp}</b>total points</span></div></>}

 const s=S.current;if(!s)return null;
 if(view==='game'){const n=Date.now(),t=s.mode==='time',q=cur(s),asking=s.phase==='ask',r=Math.max(0,s.qdl-n),pct=Math.min(100,(t?(n-s.t0)/(s.end-s.t0):s.log.length/s.qs.length)*100);
  return <><div className="bar"><span>{t?'Question '+(s.log.length+(asking?1:0)):`Question ${s.i+1} of ${s.qs.length}`}</span><span className="num">{s.score} pts</span><span className="num">{t?fmt(s.end-n)+' left':''}</span><button type="button" className="lnk" onClick={quit}>Quit</button></div><div className="prog"><i style={{width:pct+'%'}}/></div>
  <article><p className="kick">{cap(q.category)}, {q.difficulty}</p><div className="qt"><span className="num">{asking?Math.ceil(r/1e3)+'s':''}</span><div className="tbar"><i style={{width:asking?r/qLimit(q)*100+'%':'0%'}}/></div>{s.last?.res==='ok'&&<span className="pts" aria-hidden="true">+{s.last.pts}</span>}</div><h2>{q.question}</h2>
  <Answer key={q.id} q={q} locked={!asking} picked={s.last?.answer??null} getRef={getA} onSubmit={a=>resolve(a)}/>
  {s.last&&<><p className="sr" role="status">{s.last.res==='ok'?`Correct, ${s.last.pts} points`:s.last.res==='none'?'Time’s up':'Incorrect'}</p>{s.last.res!=='ok'&&q.type!=='multiple_choice'&&q.type!=='true_false'&&<p className="reveal">{HANDLERS[q.type].show(q)}</p>}</>}</article></>}

 const t=s.mode==='time',prev=guest.d.games.slice(0,-1).filter(g=>g.mode===s.mode),R=analyze(s.log,s.qs,s.score,Math.max(0,s.t1-s.t0),prev),mins=Math.max(1e3,s.t1-s.t0)/6e4,best=prev.reduce((m,x)=>Math.max(m,x.score),0);
 const pct=(x:number)=>Math.round(x*100)+'%',sec=(ms:number)=>(ms/1e3).toFixed(1)+'s',fmtDur=(ms:number)=>{const x=Math.round(ms/1e3);return Math.floor(x/60)+':'+String(x%60).padStart(2,'0')};
 const st=(v:string|number,l:string)=><div key={l}><b className="num">{v}</b><small>{l}</small></div>;
 const bars=(b:{key:string;correct:number;total:number;accuracy:number}[])=>b.map(x=><div className="rowbar" key={x.key}><span>{cap(x.key)}</span><div className="track"><i style={{width:x.accuracy*100+'%'}}/></div><small className="num">{x.correct}/{x.total}</small></div>);
 return <><section className="hero"><p className="kick">{t?'Against the clock':'Quiz'} complete</p><h1><span className="num">{s.score}</span> <small>points</small></h1>
  <p className="mu">{R.vsPrevious?`${R.vsPrevious.accuracyDelta>=0?'Up':'Down'} ${Math.abs(Math.round(R.vsPrevious.accuracyDelta*100))} points in accuracy on your last attempt. `:''}{s.score>best?'New personal best for this format.':'Personal best: '+best+'.'}</p></section>
  <div className="sg">{st(pct(R.accuracy),'accuracy')}{st(R.correct,'correct')}{st(R.incorrect,'incorrect')}{R.unanswered>0&&st(R.unanswered,'unanswered')}{st(fmtDur(R.durationMs),'total time')}{st(R.avgMs?sec(R.avgMs):'–','avg response')}{t&&st((R.total/mins).toFixed(1),'per minute')}</div>
  {R.byCategory.length>0&&<section><h2>By topic</h2>{bars(R.byCategory)}{R.strongest&&<p className="mu">Strongest: {cap(R.strongest.key)}.{R.weakest?` Weakest: ${cap(R.weakest.key)}.`:''}</p>}</section>}
  {R.byDifficulty.length>0&&<section><h2>By difficulty</h2>{bars(R.byDifficulty)}</section>}
  <section><h2>Next steps</h2>{R.improve.length?R.improve.map(b=><div className="rec" key={b.key}><p>Strengthen your knowledge of {cap(b.key)}.</p><Link className="btn" href={`/learn?topic=${encodeURIComponent(b.key)}`}>Explore Learning</Link></div>):<p className="mu">{R.strongest?'No weak areas stand out in this game.':'Answer a few more questions per topic to see insights.'}</p>}</section>
  <div className="row"><button type="button" className="btn" onClick={start}>Play again</button><button type="button" className="chip" onClick={quit}>Return home</button><Link className="chip" href="/learn">Explore Learning</Link><Link className="chip" href="/leaderboard">Leaderboard</Link></div>
  <details className="review"><summary>Review answers</summary><ol className="rev">{s.log.map(l=>{const q=s.qs.find(x=>x.id===l.id)!;return <li key={l.id}><span>{l.res==='ok'?'✓':l.res==='bad'?'✕':'–'}</span>{q.question}<br/><small>{HANDLERS[q.type].show(q)}</small></li>})}</ol></details></>}
