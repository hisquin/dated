'use client';
import {useCallback,useEffect,useState} from 'react';
import QrCode from './QrCode';
import {ENV} from '@/lib/env';
import {isStandalone,platform} from '@/lib/install';
import {availability,onAccept,onDismiss,onInstalled,onShown,publicAppUrl,shouldInvite,type Availability,type Memory} from '@/lib/install-state';
const K='dogoma.install';
interface BIP extends Event{prompt():Promise<void>;userChoice:Promise<{outcome:string}>}
const load=():Memory=>{try{const m=JSON.parse(localStorage.getItem(K)||'null');if(m&&typeof m.dismissals==='number')return m}catch{/* ignore */}return{dismissals:0}};
/** Branded install invitation. The native prompt only appears after the player taps Install. */
export default function InstallCard(){
 const [ev,setEv]=useState<BIP|null>(null),[av,setAv]=useState<Availability>('unavailable'),[show,setShow]=useState(false),[url,setUrl]=useState<{url:string|null;reason?:string}>({url:null});
 const save=useCallback((m:Memory)=>{try{localStorage.setItem(K,JSON.stringify(m))}catch{/* ignore */}},[]);
 const compute=useCallback((e:BIP|null)=>{const p=platform(navigator.userAgent,navigator.maxTouchPoints);return availability({standalone:isStandalone(),canPrompt:!!e,ios:p.ios,iosSafari:p.iosSafari,mobile:p.ios||p.android||(matchMedia('(pointer:coarse)').matches&&innerWidth<900)})},[]);
 useEffect(()=>{setUrl(publicAppUrl(ENV.appUrl,location.origin));const a=compute(null);setAv(a);if(a!=='native'&&shouldInvite(a,load(),Date.now())){save(onShown(load(),Date.now()));setShow(true)}
  const bip=(e:Event)=>{e.preventDefault();const b=e as BIP;setEv(b);setAv('native');if(shouldInvite('native',load(),Date.now())){save(onShown(load(),Date.now()));setShow(true)}};
  const inst=()=>{save(onInstalled(load(),Date.now()));setShow(false);setAv('installed')},open=()=>{setAv(compute(null));setShow(true)};
  addEventListener('beforeinstallprompt',bip);addEventListener('appinstalled',inst);addEventListener('dogoma:install-open',open);
  return()=>{removeEventListener('beforeinstallprompt',bip);removeEventListener('appinstalled',inst);removeEventListener('dogoma:install-open',open)}},[compute,save]);
 if(!show||av==='installed')return null;
 const close=()=>{save(onDismiss(load(),Date.now()));setShow(false)};
 const install=async()=>{if(!ev)return;await ev.prompt();const c=await ev.userChoice;save(c.outcome==='accepted'?onAccept(load(),Date.now()):onDismiss(load(),Date.now()));setEv(null);setShow(false)};
 return <section className="inv" aria-label="Install Dogoma">
  {av==='desktop'?<><h2>Dogoma is even better on your phone.</h2><p>Scan to open Dogoma on your mobile device, then install it from there.</p>{url.url?<QrCode url={url.url}/>:<p className="mu">{url.reason}</p>}</>
  :<><h2>Take Dogoma wherever you go.</h2><p>Install the app for a faster, more convenient knowledge and gaming experience.</p></>}
  {av==='native'&&<button type="button" className="btn" onClick={install}>Install Dogoma</button>}
  {(av==='ios-safari'||av==='ios-other')&&<ol><li>{av==='ios-safari'?'Tap the Share button in Safari.':'Open Dogoma in Safari.'}</li>{av==='ios-other'&&<li>Tap the Share button.</li>}<li>Choose Add to Home Screen, then Add.</li></ol>}
  {av==='unavailable'&&<p>Use your browser menu and choose Install app or Add to Home screen.</p>}
  <button type="button" className="lnk" onClick={close}>Not now</button></section>}
/** Always-available entry point (Profile): opens the same invitation, or says that Dogoma is already installed. */
export function InstallRow(){const [done,setDone]=useState(false);useEffect(()=>setDone(isStandalone()),[]);
 return done?<p>Dogoma is installed on this device.</p>:<button type="button" className="chip" onClick={()=>dispatchEvent(new Event('dogoma:install-open'))}>Install Dogoma</button>}
