'use client';
import {useCallback,useEffect,useRef,useState} from 'react';
import {ENV} from '@/lib/env';
import {listOutbox,setMeta} from '@/lib/store';
import {syncNow} from '@/lib/sync';
/** Service worker registration plus honest status: offline, per-state result counts, update, install. */
export default function Pwa(){
 const [online,setOnline]=useState(true),[c,setC]=useState({pending:0,failed:0,rejected:0}),[note,setNote]=useState(''),[upd,setUpd]=useState<ServiceWorker|null>(null),[ready,setReady]=useState(false),[warn,setWarn]=useState(''),want=useRef(false);
 const refresh=useCallback(async()=>{const r=await listOutbox();setC({pending:r.filter(x=>(x.state??'pending')==='pending').length,failed:r.filter(x=>x.state==='failed').length,rejected:r.filter(x=>x.state==='rejected').length})},[]);
 const sync=useCallback(async(force=false)=>{if(!navigator.onLine)return;const r=await syncNow(force);if(r.configured)setNote(r.auth?'Sign in again to sync your results':r.failed?`${r.failed} result(s) could not sync yet`:r.synced?`${r.synced} result(s) synced (not yet verified)`:'');await refresh()},[refresh]);
 const bg=useCallback(async()=>{try{const reg=await navigator.serviceWorker.ready;await (reg as unknown as {sync?:{register(t:string):Promise<void>}}).sync?.register('dogoma-sync')}catch{/* Background Sync unsupported: foreground sync covers it */}},[]);
 useEffect(()=>{if(ENV.supabase)void setMeta({id:'cfg',url:ENV.supabase.url,key:ENV.supabase.anonKey}); // public anon values, read by the worker for Background Sync
  if(process.env.NODE_ENV!=='production'||!('serviceWorker' in navigator))return;
  navigator.serviceWorker.register('/sw.js').then(reg=>{const watch=(w:ServiceWorker)=>w.addEventListener('statechange',()=>{if(w.state==='installed'&&navigator.serviceWorker.controller)setUpd(w)});
   if(reg.waiting&&navigator.serviceWorker.controller)setUpd(reg.waiting);reg.addEventListener('updatefound',()=>{if(reg.installing)watch(reg.installing)});
   navigator.serviceWorker.ready.then(r=>{r.active?.postMessage({type:'CACHE_URLS',urls:performance.getEntriesByType('resource').map(e=>e.name).filter(u=>u.includes('/_next/static/'))});setTimeout(async()=>setReady(!!(await caches.match('/'))),1500)})}).catch(()=>{});
  const cc=()=>{if(want.current)location.reload()};navigator.serviceWorker.addEventListener('controllerchange',cc);return()=>navigator.serviceWorker.removeEventListener('controllerchange',cc)},[]);
 useEffect(()=>{const on=()=>{setOnline(navigator.onLine);if(navigator.onLine)sync()},ob=()=>{refresh();void bg();sync()},st=(e:Event)=>setWarn((e as CustomEvent).detail==='quota'?'Storage is full, so questions could not be saved for offline play.':'Questions could not be saved for offline play.');
  on();refresh();addEventListener('online',on);addEventListener('offline',on);addEventListener('dogoma:outbox',ob);addEventListener('dogoma:storage',st);const t=setInterval(()=>sync(),60000);
  return()=>{removeEventListener('online',on);removeEventListener('offline',on);removeEventListener('dogoma:outbox',ob);removeEventListener('dogoma:storage',st);clearInterval(t)}},[sync,refresh,bg]);
 const waiting=c.pending+c.failed,show=!online||waiting>0||c.rejected>0||!!upd||!!note||!!warn;
 return <div id="nb" role="status" className={show?'on':''}>{show&&<>
  {!online&&<span>You’re offline{ready?'. Saved questions are ready to play.':'.'}</span>}
  {waiting>0&&<span>{waiting} result{waiting>1?'s':''} saved on this device, not yet synced{c.failed?` (${c.failed} failing)`:''}. {online&&<button type="button" className="lnk" onClick={()=>sync(true)}>Sync now</button>}</span>}
  {c.rejected>0&&<span>{c.rejected} result{c.rejected>1?'s were':' was'} refused by the server.</span>}
  {note&&waiting===0&&<span>{note}.</span>}{warn&&<span>{warn}</span>}
  {upd&&<button type="button" className="lnk" onClick={()=>{want.current=true;upd.postMessage({type:'SKIP_WAITING'})}}>Update available: reload</button>}</>}</div>}
