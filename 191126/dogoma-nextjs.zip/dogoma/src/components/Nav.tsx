'use client';
import Link from 'next/link';
import {usePathname} from 'next/navigation';
const items=[['/','Play'],['/learn','Learn'],['/leaderboard','Leaderboard'],['/profile','Profile']] as const;
/** Bottom bar on phones, sidebar on desktop (CSS). Player navigation only; admin gets its own shell. */
export default function Nav(){const p=usePathname();return <nav className="main" aria-label="Main">{items.map(([h,l])=><Link key={h} href={h} aria-current={(h==='/'?p==='/':p.startsWith(h))?'page':undefined}>{l}</Link>)}</nav>}
