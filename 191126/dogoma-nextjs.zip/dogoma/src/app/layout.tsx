import type {Metadata,Viewport} from 'next';
import {Bricolage_Grotesque,Instrument_Sans} from 'next/font/google';
import Pwa from '@/components/Pwa';
import Nav from '@/components/Nav';
import InstallCard from '@/components/InstallCard';
import './globals.css';
const display=Bricolage_Grotesque({subsets:['latin'],axes:['opsz','wdth'],variable:'--font-display',display:'swap'});
const body=Instrument_Sans({subsets:['latin'],variable:'--font-body',display:'swap'});
export const metadata:Metadata={title:'Dogoma – Know Rwanda',description:'A Pan-African knowledge game. Starts with Know Rwanda.',manifest:'/manifest.webmanifest',appleWebApp:{capable:true,title:'Dogoma',statusBarStyle:'black-translucent'},icons:{icon:'/icons/icon-192.png',apple:'/icons/icon-192.png'}};
export const viewport:Viewport={themeColor:'#171A19',width:'device-width',initialScale:1,viewportFit:'cover'};
export default function RootLayout({children}:{children:React.ReactNode}){
 return <html lang="en" className={`${display.variable} ${body.variable}`}><body><Pwa/><header><svg className="logo" viewBox="0 0 100 112" fill="none" stroke="currentColor" strokeWidth="11" strokeLinecap="round" aria-hidden="true"><circle cx="50" cy="14" r="10" fill="currentColor" stroke="none"/><path d="M16 46C2 74 22 98 42 104 68 110 90 90 90 58 90 44 82 34 76 30"/><path d="M26 82C48 92 68 80 64 62 62 50 44 50 34 60"/></svg><span className="brand">DOGOMA</span></header><InstallCard/><main id="app">{children}</main><Nav/></body></html>}
