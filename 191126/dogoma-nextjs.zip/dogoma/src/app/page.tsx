import App from '@/components/App';
import {ACTIVE_COUNTRY} from '@/core/config';
import {getRepository} from '@/services/content';
import type {Question} from '@/core/types';
export const revalidate=60; // published content refreshes at most once a minute
export default async function Page(){let qs:Question[]=[],err:string|null=null;
 try{qs=await getRepository().listPublished({country:ACTIVE_COUNTRY})}catch(e){err=e instanceof Error?e.message:'load failed'}
 return <App questions={qs} loadError={err}/>}
