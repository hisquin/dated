import {LeaderboardView} from '@/components/Views';
export default function Page(){return <LeaderboardView/>}
