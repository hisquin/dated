import {ProfileView} from '@/components/Views';
export default function Page(){return <ProfileView/>}
