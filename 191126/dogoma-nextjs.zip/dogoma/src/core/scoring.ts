import {CFG} from './config';
import type {Question} from './types';
export const qLimit=(q:Question)=>CFG.qTime[q.difficulty]*1000;
/** Linear from max (instant) to min (at the deadline); late answers score 0. */
export function scoreFor(q:Question,ms:number){const T=qLimit(q);ms=Math.max(0,ms);if(ms>T)return 0;const mx=CFG.max[q.difficulty],mn=Math.round(mx*CFG.minRatio);return Math.round(mn+(mx-mn)*(T-ms)/T)}
