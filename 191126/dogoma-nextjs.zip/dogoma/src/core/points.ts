/** Local points ledger, guest-to-account migration and ranking. Everything here is client-side and UNVERIFIED; official rankings require server-verified entries. */
export interface LedgerEntry{key:string;playerId:string;points:number;at:number;mode:'count'|'time';verified:boolean}
export interface GuestGame{sid?:string;t:number;mode:'count'|'time';score:number}
export const award=(ledger:LedgerEntry[],e:LedgerEntry)=>ledger.some(x=>x.key===e.key)?{ledger,added:false}:{ledger:[...ledger,e],added:true};
export const lifetime=(ledger:LedgerEntry[],playerId:string)=>ledger.filter(e=>e.playerId===playerId).reduce((a,e)=>a+e.points,0);
export interface MigrationReport{migrated:number;duplicates:number;skipped:number;points:number}
/** Idempotent: the session id is the key, so repeating the migration, or a result already on the account, adds nothing. Games without a session id cannot be deduplicated, are reported as skipped and stay on the device. */
export function migrateGuest(games:GuestGame[],account:LedgerEntry[],accountId:string):{ledger:LedgerEntry[];report:MigrationReport}{let ledger=account;const r:MigrationReport={migrated:0,duplicates:0,skipped:0,points:0};
 for(const g of games){if(!g.sid){r.skipped++;continue}const a=award(ledger,{key:g.sid,playerId:accountId,points:g.score,at:g.t,mode:g.mode,verified:false});ledger=a.ledger;if(a.added){r.migrated++;r.points+=g.score}else r.duplicates++}return{ledger,report:r}}
export type Period='week'|'month'|'all';
export interface Row{playerId:string;name:string;points:number;rank:number}
const SPAN:Record<Period,number>={week:7*864e5,month:30*864e5,all:Infinity};
export interface Contender{playerId:string;name:string;registered:boolean}
/** Official board: registered players and verified entries only. Local board: everything on this device, to be labelled unverified. Rolling windows; ties share a rank. */
export function rank(entries:LedgerEntry[],who:Contender[],period:Period,now:number,board:'official'|'local'):Row[]{const by=new Map<string,number>();
 for(const e of entries){const p=who.find(w=>w.playerId===e.playerId);if(!p||now-e.at>SPAN[period]||(board==='official'&&!(p.registered&&e.verified)))continue;by.set(e.playerId,(by.get(e.playerId)??0)+e.points)}
 const rows=[...by].map(([id,points])=>({playerId:id,name:who.find(w=>w.playerId===id)!.name,points})).sort((a,b)=>b.points-a.points||a.name.localeCompare(b.name));let last=-1,rk=0;
 return rows.map((r,i)=>{if(r.points!==last){rk=i+1;last=r.points}return{...r,rank:rk}})}
export const positionOf=(rows:Row[],id:string)=>rows.find(r=>r.playerId===id)??null;
