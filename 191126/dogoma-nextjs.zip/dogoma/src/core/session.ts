import {CFG} from './config';
import {HANDLERS,isBlank} from './handlers';
import {qLimit,scoreFor} from './scoring';
import type {Answer,LogEntry,Question,Result} from './types';
export type Mode='count'|'time';
export interface Sess{sid:string;gid:string;offline:boolean;mode:Mode;qs:Question[];i:number;score:number;log:LogEntry[];phase:'ask'|'feedback'|'done';qs0:number;qdl:number;fbEnd:number;end:number;t0:number;t1:number;last?:{res:Result;pts:number;answer:Answer}}
/* Pure transitions: every deadline is an absolute timestamp, so reloading, backgrounding or closing the app cannot add time. */
export const cur=(s:Sess)=>s.qs[s.i];
export function create(o:{mode:Mode;qs:Question[];durSec:number;now:number;sid:string;gid:string;offline:boolean}):Sess{return{sid:o.sid,gid:o.gid,offline:o.offline,mode:o.mode,qs:o.qs,i:-1,score:0,log:[],phase:'feedback',qs0:0,qdl:0,fbEnd:0,end:o.mode==='time'?o.now+o.durSec*1000:0,t0:o.now,t1:0}}
const done=(s:Sess,now:number):Sess=>({...s,phase:'done',t1:Math.min(now,s.end||Infinity)});
export function advance(s:Sess,now:number):Sess{if(s.phase==='done')return s;if(s.end&&now>=s.end)return done(s,now);const i=s.i+1;if(i>=s.qs.length)return done(s,now);return{...s,i,phase:'ask',qs0:now,qdl:now+qLimit(s.qs[i]),last:undefined}}
export function submit(s:Sess,a:Answer,now:number,auto:boolean):Sess{if(s.phase!=='ask')return s;if(s.end&&now>=s.end)return done(s,now);
 const q=cur(s),blank=(!auto&&now>s.qdl)||isBlank(a),ok=!blank&&HANDLERS[q.type].check(q,a),ms=Math.min(now-s.qs0,qLimit(q)),pts=ok?scoreFor(q,ms):0,res:Result=blank?'none':ok?'ok':'bad';
 return{...s,phase:'feedback',score:s.score+pts,log:[...s.log,{id:q.id,res,pts,ms}],fbEnd:now+CFG.fb[s.mode]*1000,last:{res,pts,answer:blank?null:a}}}
export function tick(s:Sess,now:number,partial:Answer):Sess{if(s.phase==='done')return s;if(s.end&&now>=s.end)return done(s,now);
 if(s.phase==='ask'&&now>=s.qdl)return submit(s,partial,now,true);if(s.phase==='feedback'&&now>=s.fbEnd)return advance(s,now);return s}
/** Rules after an interruption: an expired question is unanswered (typed text is not persisted); an expired timed session ends and discards the open question; feedback that ran out moves on. */
export function recover(s:Sess,now:number):Sess{let x=s;for(let n=0;n<10000;n++){const y=tick(x,now,null);if(y===x)break;x=y}return x}
