import type {Answer,Question,QType} from './types';
const norm=(s:string)=>s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9 ]/g,'').replace(/\s+/g,' ').trim();
function osa(a:string,b:string){const m=a.length,n=b.length,d:number[][]=Array.from({length:m+1},(_,i)=>[i,...Array(n).fill(0)]);for(let j=1;j<=n;j++)d[0][j]=j;for(let i=1;i<=m;i++)for(let j=1;j<=n;j++){d[i][j]=Math.min(d[i-1][j]+1,d[i][j-1]+1,d[i-1][j-1]+(a[i-1]!==b[j-1]?1:0));if(i>1&&j>1&&a[i-1]===b[j-2]&&a[i-2]===b[j-1])d[i][j]=Math.min(d[i][j],d[i-2][j-2]+1)}return d[m][n]}
/** Tolerant matching: normalisation, accepted variants, typo tolerance by length; answers containing digits stay exact. */
export function fuzzy(q:Question,a:string){const v={normalization:true,allow_minor_typos:true,case_sensitive:false,...q.validation},C=[String(q.correct_answer),...(q.accepted_answers??[])];
 if(v.case_sensitive)return C.some(c=>c.trim()===a.trim());const f=(s:string)=>v.normalization?norm(s):s.trim().toLowerCase(),x=f(a);if(!x)return false;
 return C.some(c=>{const y=f(c);if(x===y)return true;if(!v.allow_minor_typos||/\d/.test(y))return false;const L=y.length,k=L<=4?0:L<=8?1:2;return k>0&&Math.abs(x.length-L)<=k&&osa(x,y)<=k})}
interface Handler{validate(q:Question):string|null;check(q:Question,a:Answer):boolean;show(q:Question):string}
const str=(q:Question)=>typeof q.correct_answer==='string'&&q.correct_answer.trim()?null:'correct_answer required';
const choice:Handler={validate:q=>q.options&&q.options.length>=2&&q.options.includes(q.correct_answer as string)?null:'options must include correct_answer',check:(q,a)=>a===q.correct_answer,show:q=>String(q.correct_answer)};
const typed:Handler={validate:str,check:(q,a)=>typeof a==='string'&&fuzzy(q,a),show:q=>String(q.correct_answer)};
/** Register a new question type here, plus its input in components/Answer.tsx. */
export const HANDLERS:Record<QType,Handler>={multiple_choice:choice,true_false:{...choice,validate:q=>['True','False'].includes(q.correct_answer as string)?null:'answer must be True or False'},fill_blank:typed,short_answer:typed,
 chronological_order:{validate:q=>q.options&&Array.isArray(q.correct_answer)&&q.options.length===q.correct_answer.length?null:'ordered answer must match options',check:(q,a)=>JSON.stringify(a)===JSON.stringify(q.correct_answer),show:q=>(q.correct_answer as string[]).join(' → ')},
 matching:{validate:q=>q.pairs&&q.pairs.length>=2&&new Set(q.pairs.map(p=>p[1])).size===q.pairs.length?null:'pairs need 2+ unique right-hand values',check:(q,a)=>Array.isArray(a)&&q.pairs!.every((p,i)=>a[i]===p[1]),show:q=>q.pairs!.map(p=>p.join(' – ')).join('; ')}};
export const validateQuestion=(q:Question)=>HANDLERS[q.type]?HANDLERS[q.type].validate(q):'unknown question type';
export const isBlank=(a:Answer)=>a==null||(typeof a==='string'?!a.trim():a.every(x=>!x));
