import type {Difficulty} from './types';
import {ENV} from '../lib/env';
/** All timing and scoring values live here, independent of the UI. */
export const CFG={max:{easy:80,medium:100,hard:120} as Record<Difficulty,number>,minRatio:0.2,qTime:{easy:20,medium:25,hard:30} as Record<Difficulty,number>,fb:{count:1.4,time:1.4},counts:[5,10,15,20],durations:[60,120,180,300]};
export const ACTIVE_COUNTRY=ENV.country;
