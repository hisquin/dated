export type Difficulty='easy'|'medium'|'hard';
export type QType='multiple_choice'|'true_false'|'fill_blank'|'short_answer'|'chronological_order'|'matching';
export interface Validation{normalization?:boolean;allow_minor_typos?:boolean;case_sensitive?:boolean}
export interface Question{id:string;scope:'country'|'africa'|'global';countries:string[];category:string;subcategory?:string;difficulty:Difficulty;type:QType;question:string;explanation:string;options?:string[];correct_answer?:string|string[];pairs?:[string,string][];accepted_answers?:string[];validation?:Validation;sources:string[]}
export type Answer=string|string[]|null;
export type Result='ok'|'bad'|'none';
export interface LogEntry{id:string;res:Result;pts:number;ms:number}
