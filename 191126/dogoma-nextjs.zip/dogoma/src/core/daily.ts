export interface DailyItem{id:string;date:string;title:string;body:string;category:string;sources:string[];learnTopic?:string;quizCategory?:string}
export const validTimezone=(tz:string)=>{try{new Intl.DateTimeFormat('en',{timeZone:tz});return true}catch{return false}};
export const localDateKey=(now:number,tz:string)=>new Intl.DateTimeFormat('en-CA',{timeZone:validTimezone(tz)?tz:'UTC',year:'numeric',month:'2-digit',day:'2-digit'}).format(now);
export const validateItem=(i:DailyItem)=>!i.id||!i.title?.trim()||!i.body?.trim()||!/^\d{4}-\d{2}-\d{2}$/.test(i.date)?'incomplete item':!i.sources?.length?'every item needs a source':null;
/** Only an item published for the player's local date; never a made-up substitute. */
export const itemFor=(items:DailyItem[],now:number,tz:string)=>items.filter(i=>!validateItem(i)).find(i=>i.date===localDateKey(now,tz));
export const deepLink=(i:Pick<DailyItem,'date'>)=>`/daily?date=${i.date}`;
export interface Prefs{enabled:boolean;time:string;timezone:string;permission:'default'|'granted'|'denied'}
export const defaultPrefs=(tz:string):Prefs=>({enabled:false,time:'08:00',timezone:validTimezone(tz)?tz:'UTC',permission:'default'});
export const validatePrefs=(p:Prefs)=>!/^([01]\d|2[0-3]):[0-5]\d$/.test(p.time)?'time must be HH:MM':!validTimezone(p.timezone)?'unknown timezone':null;
/** Permission is requested only after an explicit tap by a registered player, never twice after a refusal. */
export const canRequestPermission=(p:Prefs,registered:boolean,userInitiated:boolean)=>registered&&userInitiated&&p.permission==='default';
export const setEnabled=(p:Prefs,on:boolean,perm:Prefs['permission']):Prefs=>({...p,permission:perm,enabled:on&&perm==='granted'});
