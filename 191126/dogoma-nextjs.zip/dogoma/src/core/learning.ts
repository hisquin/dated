export interface Subject{id:string;name:string;description:string}
export interface Topic{id:string;subjectId:string;name:string;summary:string;quizCategory?:string}
export interface Article{id:string;topicId:string;title:string;body:string;sources:string[];status:'draft'|'published'}
