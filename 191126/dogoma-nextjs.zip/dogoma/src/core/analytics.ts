import type {LogEntry,Question} from './types';
export const MIN_SAMPLE=2,WEAK_BELOW=0.6;
export interface Bucket{key:string;total:number;correct:number;accuracy:number}
export interface Analytics{total:number;correct:number;incorrect:number;unanswered:number;accuracy:number;score:number;durationMs:number;avgMs:number;fastestCorrectMs:number|null;byCategory:Bucket[];byDifficulty:Bucket[];strongest:Bucket|null;weakest:Bucket|null;improve:Bucket[];vsPrevious:{accuracyDelta:number;scoreDelta:number}|null}
const toBuckets=(m:Record<string,[number,number]>):Bucket[]=>Object.entries(m).map(([key,[c,t]])=>({key,total:t,correct:c,accuracy:t?c/t:0}));
export function tally(log:LogEntry[],qs:Question[],by:(q:Question)=>string):Record<string,[number,number]>{const o:Record<string,[number,number]>={};for(const l of log){const q=qs.find(x=>x.id===l.id);if(!q)continue;const b=(o[by(q)]??=[0,0]);b[1]++;if(l.res==='ok')b[0]++}return o}
export const categoryTally=(log:LogEntry[],qs:Question[])=>tally(log,qs,q=>q.category);
/** Insights only from buckets with enough answers; nothing is reported from thin data. */
export function insights(b:Bucket[],min=MIN_SAMPLE){const e=b.filter(x=>x.total>=min).sort((x,y)=>y.accuracy-x.accuracy||y.total-x.total),strongest=e[0]??null,last=e[e.length-1];
 return{strongest,weakest:e.length>1&&last.accuracy<strongest!.accuracy?last:null,improve:e.filter(x=>x.accuracy<WEAK_BELOW).sort((x,y)=>x.accuracy-y.accuracy)}}
export const aggregate=(games:{cat?:Record<string,[number,number]>}[]):Bucket[]=>{const m:Record<string,[number,number]>={};for(const g of games)for(const [k,[c,t]] of Object.entries(g.cat??{})){const b=(m[k]??=[0,0]);b[0]+=c;b[1]+=t}return toBuckets(m)};
export function analyze(log:LogEntry[],qs:Question[],score:number,durationMs:number,prev:{score:number;ok:number;n:number}[]):Analytics{
 const total=log.length,correct=log.filter(l=>l.res==='ok').length,unanswered=log.filter(l=>l.res==='none').length,answered=log.filter(l=>l.res!=='none'),cats=toBuckets(categoryTally(log,qs)),ins=insights(cats),accuracy=total?correct/total:0,p=prev[prev.length-1];
 const oks=log.filter(l=>l.res==='ok').map(l=>l.ms);
 return{total,correct,incorrect:total-correct-unanswered,unanswered,accuracy,score,durationMs,avgMs:answered.length?answered.reduce((a,l)=>a+l.ms,0)/answered.length:0,fastestCorrectMs:oks.length?Math.min(...oks):null,byCategory:cats,byDifficulty:toBuckets(tally(log,qs,q=>q.difficulty)),...ins,
  vsPrevious:p&&p.n>0&&total>0?{accuracyDelta:accuracy-p.ok/p.n,scoreDelta:score-p.score}:null}}
