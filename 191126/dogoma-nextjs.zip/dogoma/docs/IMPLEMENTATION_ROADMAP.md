# Implementation roadmap (both briefs consolidated)
Overlaps merged: guest play, PWA install, leaderboard integrity, learning links and Supabase readiness appear in both briefs and are planned once.
| Phase | Scope | Status |
|---|---|---|
| 0. Verify | `npm install`, `typecheck`, `build`, fix compile errors; run `docs/DEVICE_TEST_PLAN.md` on phones and desktop | BLOCKING, not done |
| 1. Experience (this pass) | Minimal feedback; results analytics and learn CTAs; bottom nav and sidebar; Learn, Daily, Leaderboard, Profile routes with honest empty states; install card, iOS steps, desktop QR; repository interfaces; env validation; points ledger, migration and ranking logic; daily and notification preference logic | Built; UI unverified |
| 2. Accounts and Supabase | Auth (email, Google), profiles, run migrations, Supabase adapters behind the existing interfaces, guest migration via an idempotent claim function, point transactions, server-verified sessions, official leaderboards | Future (needs backend) |
| 3. Admin | Protected admin shell, question/category/player/learning management, analytics. Must be server-authorised | Future (needs auth) |
| 4. Engagement | Registration prompts with frequency limits, daily content, web push (VAPID, scheduler, delivery log), achievements, learning progress and bookmarks, daily challenges | Future |
| 5. Quality | Playwright e2e at phone and desktop sizes, ESLint config, Lighthouse, accessibility audit | Future |
Dependencies: 3 and the registration prompts need 2; push needs 2 and a scheduler; official ranking needs server verification.
