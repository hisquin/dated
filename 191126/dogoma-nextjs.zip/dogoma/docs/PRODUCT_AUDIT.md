# Product audit
Method: every file in the Next.js project was read or searched on this pass (35 source files, 5 test files, 7 migrations). Statuses: COMPLETE, PARTIAL, MISSING, BROKEN, UNVERIFIED (exists, cannot be verified here). "Before" is the state at the start of this pass; "After" is the state at the end. **Nothing could be run in a browser, and `npm install`, `typecheck`, `lint` and `build` could not run (no network).** Pure logic is covered by Node tests; React components and Next.js wiring are UNVERIFIED.
## A. Player experience
| Feature | Before | After | Evidence |
|---|---|---|---|
| Guest play, no registration wall | COMPLETE | UNVERIFIED | Single route `/`; history in localStorage; never browser-tested |
| Home dashboard with categories, stats, links to Learn/Leaderboard/Profile | PARTIAL (play setup and stats only) | PARTIAL | Nav added; no daily-challenge card, no quiz "rules before start" screen |
| Category browsing, difficulty explanation, rules before start | PARTIAL (topic chips; difficulty not explained) | PARTIAL | Unchanged |
| Minimal answer feedback | BROKEN against brief (verbose text, 8s countdown) | UNVERIFIED | Rewritten: accent/red states, shake, "+pts" chip, 1.4s auto-advance, screen-reader text only. Not seen in a browser |
| Results analytics | BROKEN against brief (question list) | UNVERIFIED | Dashboard with topic/difficulty breakdown and learn CTAs; the analytics maths is tested (`product.test.mjs`) |
| Registration, login, profile editing | MISSING | MISSING | Needs auth backend |
| Guest-to-account migration | MISSING | PARTIAL | Idempotent ledger logic tested; not wired (no accounts) |
| Registration prompts | MISSING | MISSING | Frequency logic not written; needs registration to point at |
## B. Admin
| Dashboard, question/category/player/learning management, reports | MISSING in the Next.js app (the old single-file prototype had a local editor; it was not ported) | MISSING | Cannot be secured without auth; a client-only "admin" would be fake. `AdminRepository` interface defined, no implementation |
## C. Gameplay and scoring
| Scoring, three timers, auto-submit, typo-tolerant matching | COMPLETE (tested) | COMPLETE (tested) | `session`, `sync`, `idb` tests |
| Session recovery, duplicate-submit protection | COMPLETE (tested) | COMPLETE (tested) | |
| Feedback interval | 8s/3s | 1.4s (config) | Deliberate change requested by the brief; scoring untouched |
| Skip question, practice, daily challenge | MISSING | MISSING | |
## D. Performance analytics
| Per-game analytics, strongest/weakest, insights, comparison with last attempt | MISSING | COMPLETE logic (tested), UI UNVERIFIED | Insights need >=2 answers in a topic (profile: 3); nothing is reported from thin data |
| Per-topic history across games | MISSING | PARTIAL | New games store per-topic tallies; older history has none |
## E. Learning
| Learn route, data model, repository, honest empty state, topic deep links from results, back to quizzes | MISSING | PARTIAL / UNVERIFIED | No content exists (`learning.json` is empty by design). Bookmarks and progress not built |
## F. Mobile and desktop
| Bottom nav on phones, sidebar on desktop, safe areas, 48px targets | PARTIAL (responsive only) | UNVERIFIED | CSS only; never rendered. Desktop dashboards and richer layouts not built |
## G. PWA and offline
| Manifest, worker, offline page, versioned caches, update prompt | COMPLETE (worker tested) | same | |
| Offline questions, outbox, Background Sync | COMPLETE (tested with fakes) | same | Real browser UNVERIFIED |
| Install experience | PARTIAL (button, iOS tip) | PARTIAL / UNVERIFIED | State machine tested; card, iOS steps, desktop QR added. QR uses the `qrcode` package (not installed here) |
## H. Data architecture and Supabase readiness
| Repository boundaries | PARTIAL (one interface; UI imported the Supabase adapter) | PARTIAL | Interfaces for all repositories; local adapters for learning/daily; Supabase client now loaded only when configured and validated (`env.ts`); sessions/player/results adapters still call stores directly |
| Env validation, `.env.example` | MISSING | COMPLETE (tested) | Refuses service-role keys in public variables |
## I. Security
| Verified-score separation, RLS review, score constraints | COMPLETE (static) | same | SQL never executed |
| Points ledger, idempotency keys | MISSING | COMPLETE logic (tested), unwired | |
| Server-side score verification | MISSING | MISSING | Needs backend |
| Answers exposed to the client | KNOWN RISK | KNOWN RISK | |
## J. Testing and readiness
| Node tests (idb, session, sync, pwa, product) | COMPLETE | COMPLETE: all five files pass | |
| Typecheck, lint, build, browser/e2e | NEVER RUN | NEVER RUN | No network; ESLint not configured |
**Verdict: not production-ready.** Blocking: first compile, real-device tests, accounts and server verification, admin.
