# Supabase integration (NOT integrated yet)
The app runs on local JSON and browser storage. With no Supabase variables set it never loads the Supabase client. Present migrations `supabase/migrations/…0100–0700` already cover content, sessions, roles, storage and RLS (never executed). See `SUPABASE_SETUP.md` and `SECURITY_REVIEW.md`.
## Swap points (one adapter per interface in `src/services/repositories.ts`)
Question (exists: `content.ts`), Learning and Daily (`local.ts`), Player, Results, GameSession (stores in `src/lib/store.ts`), Admin (no local version by design).
## Entities still to design
`point_transactions(key unique, player_id, session_id, points, created_at)`; `leaderboard` views (weekly, monthly, all-time, official = verified only, over `point_transactions`); `achievements`, `player_achievements`; `learning_subjects`, `learning_topics`, `learning_articles` (status, sources), `learning_progress`, `bookmarks`; `daily_knowledge` (date, title, body, category, sources, learn_topic, quiz_category); `notification_preferences` (enabled, time, timezone); `push_subscriptions` (endpoint, keys, player_id, revoked_at); `notification_deliveries`.
## Authoritative scoring
Replace client-reported sessions: the server issues a session with its question list and start time, accepts answers with timestamps, recomputes score using the same rules as `core/scoring.ts`, rejects late or repeated answers, then writes the session as `verified` and one `point_transactions` row keyed by the session id. Leaderboards read verified rows only (`official_sessions` view already enforces this).
## Guest migration
After sign-in call an idempotent function with the guest's session ids. Ids already present are ignored; results for sessions the server never issued stay unverified and earn no leaderboard points. Report migrated, duplicate and skipped counts to the player (the client logic is in `core/points.ts`).
## Accounts, push, config
Email and Google auth, expired-session handling in sync (already treated as "sign in again", not as failure). Push needs VAPID keys, a worker `push`/`notificationclick` handler, a daily scheduler honouring each player's timezone, and delivery records. Variables: see `.env.example`; keys other than the anon/publishable key never go in the browser.
