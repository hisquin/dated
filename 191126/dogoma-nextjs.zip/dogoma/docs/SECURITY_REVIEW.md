# Security review of migrations and RLS (static review; SQL not executed against a database)
| Check | Result |
|---|---|
| Clients cannot mark scores verified | Insert policy requires `verified=false`. **Bug found:** `sessions update own` let a signed-in player update their own row (score, verified). Fixed in `20260101000700` by dropping the policy and revoking UPDATE/DELETE. |
| Players cannot modify others' records | Update/delete on sessions now impossible for clients; reads are limited to `player_id=auth.uid()`; guest rows are unreadable. |
| Duplicate submissions | Session id is the primary key; a repeat insert fails with 23505 and the client treats it as synced. |
| Unverified scores in leaderboards | `official_sessions` view returns only `verified` rows and no client path can set it. Leaderboards must read that view only. Not testable until leaderboards exist. |
| Implausible scores | Check constraint: `correct<=attempted`, `score<=attempted*120`, `ended_at>=started_at` (120 = highest per-question maximum; update it if `CFG.max` changes). |
| Admin operations | Policies call `can_manage()`, `can_write_content()`, `is_super()`; question status rules are enforced by trigger. Reviewed; not executed. |
| **Bug found:** public `sources` read | Exposed all sources, including notes of unpublished work. Now limited to sources cited by a visible question. Notes remain readable by anyone who can see that source: do not store private notes there. |
## Open risks
Anyone with the anon key can insert unlimited sessions (no rate limit; use Supabase limits or an Edge Function). Published answers are readable by clients. Client scores are unverified until a server-side verifier exists. Seed SQL, triggers and policies have never run on Postgres.
