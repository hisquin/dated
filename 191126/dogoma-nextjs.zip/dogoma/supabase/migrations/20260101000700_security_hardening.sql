-- Review fixes. Previously a signed-in player could UPDATE their own session (score, verified). Clients may now only insert.
drop policy if exists "sessions update own" on public.game_sessions;
revoke update, delete on public.game_sessions from anon, authenticated;
do $$ begin alter table public.game_sessions add constraint game_sessions_integrity check (correct<=attempted and score<=attempted*120 and (ended_at is null or ended_at>=started_at)); exception when duplicate_object then null; end $$;
-- Official leaderboards must read this view only: it can contain verified sessions, and no client path can create one.
create or replace view public.official_sessions as select id,player_id,mode,score,attempted,correct,ended_at,category_id from public.game_sessions where verified;
revoke all on public.official_sessions from public; grant select on public.official_sessions to anon, authenticated;
-- Public sources: only those cited by a question the caller can already see (RLS on question_sources limits that to published questions).
drop policy if exists "sources read" on public.sources;
create policy "sources read" on public.sources for select using (public.is_staff() or exists(select 1 from public.question_sources qs where qs.source_id=sources.id));
