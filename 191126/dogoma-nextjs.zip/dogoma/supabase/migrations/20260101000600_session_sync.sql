-- Offline sync: sessions arrive from the browser and are never trusted. Only server-verified sessions may feed leaderboards.
alter table public.game_sessions add column if not exists offline boolean not null default false, add column if not exists verified boolean not null default false, add column if not exists app_version text;
drop policy if exists "sessions insert" on public.game_sessions;
create policy "sessions insert" on public.game_sessions for insert to anon, authenticated with check (verified=false and ((player_id is null and guest_id is not null) or player_id=auth.uid()));
