# Dogoma Question Bank — 1,000 Questions

## Files
- `dogoma_question_bank_1000.json`: combined 1,000-question import file.
- `rwanda_questions.json`: 800 Rwanda-focused questions (80%).
- `africa_general_questions.json`: 150 Africa-wide questions (15%), not assigned to one country.
- `african_country_questions.json`: 50 useful country-specific African questions (5%).
- `SOURCES.md`: source register.

## Compatibility with the supplied Dogoma ZIP
The files follow the question object structure in `src/data/seed.json`. They use the five category slugs seeded by the supplied Dogoma SQL migration: `geography`, `places`, `history`, `culture`, and `pan-african`. IDs follow the database code pattern `AA-AAA-0000` (for example `RW-GEO-0001`). The question `type` values are supported by Dogoma: `multiple_choice`, `true_false`, `fill_blank`, and `short_answer`.

Each object includes `id`, `scope`, `countries`, `category`, `subcategory`, `difficulty`, `type`, `question`, `explanation`, `correct_answer`, and `sources`, plus `options` for multiple-choice items and `accepted_answers` for typed items.

## Distribution
- Rwanda: 800 / 1,000 (80%)
- Africa-wide: 150 / 1,000 (15%)
- African country-specific: 50 / 1,000 (5%)

## Source policy and editorial caution
Each question carries source titles and URLs in its `sources` array. Rwanda census population questions explicitly identify the 2022 Population and Housing Census and are not current population estimates. Main source families include the Government of Rwanda, the 2023 Constitution, NISR, UNESCO World Heritage Centre, the African Union, the East African Community and Encyclopaedia Britannica.

This is a source-attributed first-pass content batch, not a substitute for editorial review before publishing. Several facts are tested in multiple answer formats to exercise the app’s supported question types; this creates some repetition of underlying knowledge even though question wording and interaction formats differ. Review question wording, answer normalisation, source URLs and factual claims before production import.
