# Source register

- Government of Rwanda, About Rwanda: https://www.gov.rw/about
- Government of Rwanda, Government overview: https://www.gov.rw/overview
- National Institute of Statistics of Rwanda, Population size and characteristics (2022 census): https://statistics.gov.rw/statistical-publications/population-size-and-population-characteristics
- NISR, Statistical Yearbook 2024: https://statistics.gov.rw/sites/default/files/documents/2025-02/Statistical_Year_Book_2024.pdf
- Constitution of the Republic of Rwanda (2023): https://www.nec.gov.rw/fileadmin/user_upload/NEC/Publications/Electoral_Acts/Constitutuion_of_the_Republic_of_Rwanda-2023.pdf
- UNESCO World Heritage Centre, Rwanda: https://whc.unesco.org/en/statesparties/rw/
- UNESCO World Heritage Centre, Nyungwe National Park: https://whc.unesco.org/en/list/1697/
- African Union, About the AU: https://au.int/en/overview
- African Union, Member States: https://www.au.int/en/AU_Member_States
- African Union, Agenda 2063: https://www.au.int/en/agenda2063/overview
- Encyclopaedia Britannica, Africa: https://www.britannica.com/place/Africa
- East African Community, History: https://www.eac.int/overview-of-eac/history-of-eac
